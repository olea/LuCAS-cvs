/*
 * FindFile.java
 *
 * Created on 4 de agosto de 2001, 12:23
 */

package com.echiceros.io;

import java.util.*;
import java.io.*;
import com.echiceros.regexp.Matcher;

/**
 * Permite localizar archivos utilizando regexp. Lo hace de forma
 * asincrona, lanzando eventos al finalizar.
 * @author  jv
 * @version 
 */
public class FindFile 
implements Runnable, java.io.Serializable {
  /** Filtro utilizado para localizar archivos. */
  FileFilter filter;
  /** Listeners registrados. */
  Vector listeners;
  /** Path desde el que se realizar� la b�squeda. */
  String rootPath;
  /** La b�squeda sera ejecutada concurrentemente con este thread. */
  Thread runner;
    
  /** Creates new FindFile.
   *  @params path Carpeta desde la que se iniciar� la b�squeda.
   *  @params pattern Patron reg-exp que marcara si un archivo
   *          es aceptado.
   */
  public FindFile(String rootPath, String pattern)
  throws org.apache.oro.text.regex.MalformedPatternException {
      this.filter = new REFileFilter(pattern);
      this.rootPath = rootPath.replace('\\', '/');
      if (this.rootPath.endsWith("/") == false) {
          this.rootPath = this.rootPath + "/";
      }
      this.listeners = new Vector();
  }
  
  /** Inicia la b�squeda. */
  public void start() {
     runner = new Thread(this);
     runner.start();
  }
  
  /** Detiene la b�squeda. */
  public void stop() {     
    this.runner = null;
     postStop();
  }
  
  /** Retorna true si la b�squeda est� encendida. */
  public boolean isAlive() {
     return ((this.runner != null) && (runner.isAlive()));
  }
  
  public void run() {
    File root;
    
    postStart();
    root = new File(this.rootPath);
    this.find(root);
    if (runner != null) {
      postStop();
    }
  }

   /** Realiza la b�squeda recusiva mientras no se haya invocado stop(). */
   protected  void find(File root)  {
     File[] files;
     int idx;

     // Obtenemos los archivos
     if (root == null) {
       files = File.listRoots();
     }
     else {
       files = root.listFiles(filter);
     }

     if (files != null) {
       this.postFiles(files);
       this.findMore(files);
     }
   }
   
   /** Realiza una llamada recursiva con el fin de investigar en
    *  las subcarpetas.
    */
   protected void findMore(File[] files) {
     for (int i=0; i < files.length; i++) {
       if (files[i].isDirectory() == true) {
         this.find(files[i]);
       }
     }
   }
   
   /** Postea eventos para todos los ficheros encontrados (deben
    *  cumplir el patr�n). 
    */
   protected void postFiles(File[] filesAndFolders) {
     Vector files;
     FindFileEvent evt;
     FindFileListener ls;
     
     files = new Vector();
     for (int i=0; i < filesAndFolders.length; i++) {
       if (filesAndFolders[i].isDirectory() == false) {
         files.addElement(filesAndFolders[i]);
       }
     }

     if (files.size() > 0) {
         evt = new FindFileEvent(files);
         for (int i=0; i < this.listeners.size(); i++) {
           ls = (FindFileListener) listeners.elementAt(i);
           ls.matchPerformed(evt);
         }
     }
   }
   
   /** Postea eventos de inicio de b�squeda.
    */
   protected void postStart() {
     FindFileEvent evt;
     FindFileListener ls;
     
     evt = new FindFileEvent();
     for (int i=0; i < this.listeners.size(); i++) {
       ls = (FindFileListener) listeners.elementAt(i);
       ls.matchStarted();
     }
   }
   
   /** Postea eventos de fin de b�squeda.
    */
   protected void postStop() {
     FindFileEvent evt;
     FindFileListener ls;
     
     evt = new FindFileEvent();
     for (int i=0; i < this.listeners.size(); i++) {
       ls = (FindFileListener) listeners.elementAt(i);
       ls.matchStoped();
     }
   }

   /** Agrega un listener. */
   public void addListener(FindFileListener ls) {
     listeners.addElement(ls);
   }
   
   

   /** Filtro de ficheros que deja pasar solo carpetas y aquellos
    *  archivos que cumplen con la regexp indicada como patr�n. 
    */
   class REFileFilter implements java.io.FileFilter {
       Matcher matcher;
       
       /** Crea un filtro.
        *  @params pattern El patr�n regexp que utilizaremos
        *          como filtro.
        */
       public REFileFilter(String pattern) 
       throws org.apache.oro.text.regex.MalformedPatternException {
         this.matcher = new Matcher(pattern);
       }
       
       public boolean accept(java.io.File file) {
           boolean res;
           
           if (file.isDirectory() == true) {
             res = true;
           }
           else if (matcher.match(file.getName()) == true) {
             res = true;
           }
           else {
             res = false;
           }
           
           return res;
       }
   }   

   /** Encapsula la info de un evento de busqueda. */
   public static class FindFileEvent {
      Vector files;
      
      public FindFileEvent() {
        this.files = null;
      }

      public FindFileEvent(Vector files) {
        this.files = files;
      }
      
      public Vector getFiles() {
        return this.files;
      }          
   }
   
    public interface FindFileListener {
       /** Ejecutado cada vez que se localiza un grupo de archivos
        *  que cumplen el patron.
        */
       public void matchPerformed(FindFileEvent evt);
       
       /** Ejecutado cuando se inicia el servicio de busqueda. */
       public void matchStarted();
       
       /** Ejecutado al finalizarse el servicio de b�squeda. */      
       public void matchStoped();
    }
    
    static class TestFFListener implements FindFileListener {
       int count = 0;
        public void matchStarted() {
            System.out.println("B�squeda iniciada.");
        }
        
        /** Ejecutado al finalizarse el servicio de b�squeda.  */
        public void matchStoped() {
            System.out.println("B�squeda finalizada.");
        }
        
        /** Ejecutado cada vez que se localiza un grupo de archivos
         * que cumplen el patron.
         */
        public void matchPerformed(FindFileEvent evt) {
            File f;
            
            System.out.println("*****************************************");
            for (int i=0; i < evt.getFiles().size(); i++) {
              f = (File) evt.getFiles().elementAt(i);
              count = count + 1;
              System.out.println(count + "\t" + f.getAbsolutePath());
            }
        }        
    }
    
    public static void main(String[] args) {
      FindFile finder;
      
      try { 
          finder = new FindFile("c:/", "(\\.jp(e)*g$)|(\\.gif$)");
          finder.addListener(new TestFFListener());
          finder.start();
      }
      catch (org.apache.oro.text.regex.MalformedPatternException e) {
          System.out.println(e);
      }
    }
   
}
