/*
 * CacheTag.java
 *
 * Created on 30 de octubre de 2001, 10:09
 */

package com.echiceros.www.customtags;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.echiceros.system.pooling.*;

/**
 * Esta clase implementa un tag capaz de almacenar en en memoria
 * su body, recuper�ndolo posteriormente de la misma en lugar de
 * tener que volver a procesarlo. Resulta extremadamente �til,
 * una vez solucionados problemas de flush.
 *
 * @author  jv
 * @version 
 */
public class CacheTag extends javax.servlet.jsp.tagext.BodyTagSupport {

    /** Por defecto, 10 minutos en la cach� como m�nimo. */
    static  int DEFAULT_SECONDS = 10 * 60;
    
    Cache cache;
    /** M�nima cantidad de segundos que permanecera en cach� el 
     *  contenido.
     */
    int seconds;
    
    /** Existen dos valores v�lidos: session y application. 
     *  Si fijamos application (valor por defecto) el cach� 
     *  queda activo para toda la aplicaci�n (un usuario basta
     *  para que el contenido se almacene en cach�). En caso
     *  de utilizar el valor session cada usuario tendr� una
     *  cach� individualizada. En este �ltimo caso resulta
     *  muy importante fijar valores razonables al par�metro
     *  de seconds.
     */
    String scope = null;
    
    /** Creates new CacheTag */
    public CacheTag() {
        cache = Cache.createCache("CacheTag", Cache.UNLIMITED);
        seconds = -1;
    }

    public int doStartTag() throws JspException {
        int action;
        String resourceName;
        HttpServletRequest request;
        String body;
        CacheElement cacheElement;
        
        request = (HttpServletRequest) pageContext.getRequest();
        resourceName = HttpUtils.getRequestURL(request).toString();
        if (this.getScope().equals("session") == true) {
            resourceName = resourceName + "#" + request.getSession().getId();
        }
        
        cacheElement= (CacheElement) this.cache.get(resourceName, false);
        if (cacheElement == null) {
            action = this.EVAL_BODY_TAG;
        }
        else {
            action = SKIP_BODY;
            try {
                body = (String) cacheElement.getElement();
                pageContext.getOut().write(body);
            }
            catch (java.io.IOException e) {
                throw new JspException (getClass().getName() + ": " + e);
            }
        }
        
        return action;
    }
    
    public int doAfterBody() throws javax.servlet.jsp.JspException {
        String resourceName;
        HttpServletRequest request;
        CacheElement cacheElement;
        String body;
        
        request = (HttpServletRequest) pageContext.getRequest();
        resourceName = HttpUtils.getRequestURL(request).toString();
        if (this.getScope().equals("session") == true) {
            resourceName = resourceName + "#" + request.getSession().getId();
        }
        body = this.getBodyContent().getString();
        cacheElement  = new CacheElement(resourceName, body, getSeconds());
        cache.put(cacheElement);
        try {
            body = (String) cacheElement.getElement();
            getPreviousOut().write(body);
        }
        catch (java.io.IOException e) {
            throw new JspException (getClass().getName() + ": " + e);
        }
        
        return EVAL_PAGE;
    }
    
    /** Getter for property seconds.
     * @return Value of property seconds.
     */
    public int getSeconds() {
        int res;
        
        if (this.seconds != -1) {
            res = this.seconds;
        }
        else {
            res = DEFAULT_SECONDS;
        }
        
        return res;
    }
    
    /** Setter for property seconds.
     * @param seconds New value of property seconds.
     */
    public void setSeconds(int seconds) {
        this.seconds = seconds;
    }
    
    /** Getter for property scope.
     * @return Value of property scope.
     */
    public String getScope() {
        return (this.scope==null) ? "application" : this.scope;
    }
    
    /** Setter for property scope.
     * @param scope New value of property scope.
     */
    public void setScope(String scope) {
        if (scope.equals("application") || scope.equals("session")) {
            this.scope = scope;
        }
        else {
            throw new IllegalArgumentException(
                getClass().getName() + ": " + scope + " is not a valid scope value.");
        }
    }
    
}
