/*
 * FormProcessorServlet.java
 *
 * Created on 15 de septiembre de 2002, 12:23
 */

package com.echiceros.www.formproc;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.log4j.*;
import org.python.core.*;

import com.echiceros.lang.*;
/**
 *
 * @author  jv
 * @version
 */
public class FormProcessorServlet extends HttpServlet {
    
    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        BasicConfigurator.configure(new org.apache.log4j.ConsoleAppender());
        com.echiceros.system.ConfigEngine.getInstance().setProperty("python/home", "d:/dev/jython");
    }
    
    /** Destroys the servlet.
     */
    public void destroy() {
        
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        String spath = (String)request.getAttribute(
                                    "javax.servlet.include.servlet_path");
        if (spath == null) {
            spath = ((HttpServletRequest) request).getServletPath();
            if (spath == null || spath.length() == 0) {
                // Servlet 2.1 puts the path of an extension-matched
                // servlet in PathInfo.
                spath = ((HttpServletRequest) request).getPathInfo();
            }
        }
        String rpath = getServletContext().getRealPath(spath);

        executeScript(rpath, request, response);
        
        response.getOutputStream().close();
    }
    
    protected void executeScript(String path,
                                 HttpServletRequest request, 
                                 HttpServletResponse response)
    throws ServletException, IOException {
        OutputStream out;
        PyObject[] args;
        PyObject pyObject;
        String info;
        String methodName;
        
        Logger.getInstance(getClass()).debug("Obteniendo objeto.");
        out = response.getOutputStream();
        pyObject = JythonInstantiator.getDefault().getPyObject(path, out);
        
        if (request.getParameter("formPrivateInfo") != null) {
            info = request.getParameter("formPrivateInfo");
            methodName = StringTools.extract(info, "METHOD::", ";").trim();
        } else {
            methodName = "form_onSubmit";
        }
        
        Logger.getInstance(getClass()).debug("Invocando " + methodName + ".");
        args = new PyObject[]  { Py.java2py(request), Py.java2py(response)};
                         
        pyObject.invoke(methodName.intern(), args);
    }
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
}
