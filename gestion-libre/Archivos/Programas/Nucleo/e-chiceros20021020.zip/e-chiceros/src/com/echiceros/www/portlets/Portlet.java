/*
 * Portlet.java
 *
 * Created on 9 de julio de 2001, 0:30
 */
package com.echiceros.www.portlets;

import java.util.*;
import java.io.*;
import java.net.*;
import org.apache.log4j.*;
import com.echiceros.lang.StringTools;

/**
 *
 *  Modeliza el concepto de portlet: obtiene el contenido de un documento
 *  xml y permite acceder a sus tres componentes fundamentales: 
 *  title, top y complete. La actual implementaci�n trata de ser 
 *  lo m�s eficiente posible.
 *
 *  El formato del documento deber� incluir un elemento title (del que
 *  se obtendr� el t�tulo del portlet) y otro portletbody (del que se extraer�
 *  el top). Por lo tanto, un documento html puede ser tratado como un
 *  portlet.
 *
 * @author  jv
 * @version 1.0
 */
public class Portlet extends java.lang.Object implements java.io.Serializable {
    
    /** Path del documento que se convertir� en portlet. */
    String sourcePath;
    /** Conexi�n al recurso. No es obligatorio definirla,
     *  pero permite obtener el mismo del servidor, es decir,
     *  procesarlo.
     */
    URLConnection con;
    /** Cu�ntos caracteres deben conformar el top. */
    int topMaxLength;
    
    /** T�tulo del portlet. */
    String title;
    /** Top del portlet. */
    String top;
    
    
    /** Fecha en la que se cre� el archivo del portlet. */
    GregorianCalendar date;
    
    /** Creates new Portlet.
     *
     *  @param sourcePath el path del documento xml que contendr� el portlet.     
     *  @param topLength cu�ntos caracteres deben conformar el top como m�ximo.
     */
    public Portlet(String sourcePath, int topMaxLength) {
        this(null, sourcePath, topMaxLength);
    }
    
    /** Creates new Portlet.
     *
     *  @param con la conexi�n al recurso.
     *  @sourcePath path absoluto al mismo.     
     *  @param topLength cu�ntos caracteres deben conformar el top como m�ximo.
     */
    public Portlet(URLConnection con, String sourcePath, int topMaxLength) {
        this.con = con;
        this.topMaxLength = topMaxLength;
        this.sourcePath = sourcePath;
        Category.getInstance(getClass().getName()).info(
            "Creando Portlet (sourcePath=" + sourcePath +").");
        read();
    }
    
    /** Retorna la fecha del recurso. */
    protected GregorianCalendar getLastModifiedDate() {
        GregorianCalendar date;
        File file;
        Date time;
        
        date = new GregorianCalendar();
        if (this.sourcePath != null) {
          file = new File(this.sourcePath);
          time = new Date(file.lastModified());
          date.setTime(time);
        }
        else if (this.con != null) {
          time = new Date(con.getDate());
          if (time.getTime() == 0) {
              date.setTime(new Date());
          }
          else {
              date.setTime(time);
          }
        }
        Category.getInstance(getClass().getName()).info(
            "Fecha del recurso: " + date.getTime() + ".");
        return date;
    }
    
    /** Retorna el stream del recurso. */
    protected BufferedReader getReader() throws IOException {
        BufferedReader in = null;
               
        if (this.con != null) {
          Category.getInstance(getClass().getName()).info(
              "Reader creado desde conexi�n.");
          in = new BufferedReader(
                  new InputStreamReader(
                    this.con.getInputStream()));
        }
        else if (this.sourcePath != null) {
          in = new BufferedReader(new FileReader(this.sourcePath));
          Category.getInstance(getClass().getName()).info(
              "Reader creado desde archivo.");
        }
        
        return in;
    }
    
    /** Recupera justo hasta el top. Iinicializa top y title.
     *  Esta rutina es algo larga, pero resulta dif�cil de dividir
     *  sin caer en la pedanter�a.
     */
    protected void read() {
        StringBuffer doc;
        StringBuffer top;
        BufferedReader in = null;
        String line;
        int titleLoc;
        int titleLength;
        int topLoc;
        int titleEnd, bodyEnd;
        int tag0, tag1;
       
        try {
            Category.getInstance(getClass().getName()).info(
                "Leyendo Portlet (sourcePath=" + sourcePath +").");
            /* Primero obtenemos la fecha del portlet. */
            this.date = this.getLastModifiedDate();
            /* Ahora leemos el t�tulo y el top. */
            doc = new StringBuffer();
            in = getReader();
            titleLoc = -1;
            titleLength = -1;
            topLoc = -1;
            top = null;
            Category.getInstance(getClass().getName()).debug(
                "Iniciada lectura del portlet.");
            do{
                line = in.readLine();
                if (line != null) {
                    doc.append(line);
                    /* Actualizamos el titulo. */
                    if ((titleLoc == -1) && (line.indexOf("<title>") != -1)) {
                        titleLoc = doc.length() - line.length() + 
                                   line.indexOf("<title>") + "<title>".length();
                    }
                    if ((titleLoc != -1) && (line.indexOf("</title>") != -1)) {
                        titleEnd = doc.length() - line.length() + 
                                   line.indexOf("</title>");
                        titleLength = titleEnd - titleLoc;
                        Category.getInstance(getClass().getName()).info(
                            "Extraido t�tulo.");
                    }
                    /* Actualizamos el top. */
                    if ((topLoc == -1) && (line.indexOf("<portletbody") != -1)) {
                        bodyEnd = line.indexOf('>', line.indexOf("<portletbody"));
                        topLoc = doc.length() - line.length() + bodyEnd+1;
                        top = new StringBuffer();
                    }                    
                    /* Eliminamos los tags que encontremos...*/
                    if (top != null) {
                        top.append(line);
                        do {
                            tag0 = StringTools.lastIndexOf(top, '<');
                            tag1 = StringTools.lastIndexOf(top, '>');
                            if (tag1 > tag0) {
                                top = new StringBuffer(
                                        top.substring(0, tag0) +
                                        top.substring(tag1+1).trim() + " ");
                            }
                        } while (tag1 > tag0);
                    }
                }
            } while ((line != null) && 
                     ((top == null) || (top.length() < this.topMaxLength)));
            Category.getInstance(getClass().getName()).debug(
                "Extraido top. Finalizada lectura del portlet.");
            /* Cortamos el posible sobrante de la �ltima l�nea. */
            if (top.length() > this.topMaxLength) {
                top.setLength(this.topMaxLength);
            }
            /* Cortamos hasta la palabra anterior y a�adimos ... */
            while ((top.length()>this.topMaxLength/2) &&
                   (top.charAt(top.length()-1) != ' ')) 
            {   top.setLength(top.length()-1);
            }
            top.setLength(top.length()-1);
            top.append("...");
            /* Obtenemos el t�tulo y el top. */
            this.title = doc.substring(titleLoc, titleLoc+titleLength);
            this.top   = top.toString();
            Category.getInstance(getClass().getName()).info(
                "Portlet creado. Title = " + title + ".");
        }
        catch (IOException e) {             
            this.title = "Portlet " + this.sourcePath + ": " + e;
            this.top = "";
            Category.getInstance(getClass().getName()).warn(
                "Error en la lectura del portlet : " + e + ".");
        }
        finally{            
            if (in != null) {
                try {
                  in.close();
                }
                catch(IOException e){
                }
            }
        }
    }
    
    /** Recupera el t�tulo del portlet. Si es necesario, lee el mismo
     *  del documento.
     */
    public String getTitle() { 
        return title;
    }
    
    /** Recupera los primeros caracteres del body del portlet. Si es
     *  necesario lee los mismos.
     */
    public String getTop() {
        return top;
    }
    
    /** Retorna la fecha, formateada como aaaammdd. */
    public int getDate() {
      String res;
      java.text.SimpleDateFormat fr;
      
      fr = new java.text.SimpleDateFormat("yyyyMMdd");
      res = fr.format(this.date.getTime());
      
      return Integer.parseInt(res);
    }
    
    /** Retorna la url a la que esta asociado este portlet. */
    public String getURL() {
      return con.getURL().toExternalForm().replace('\\', '/');
    }
    
    /** Retorna el html necesario para presentar el portlet. 
     *  En la carpeta de test puedes localizar un ejemplo completo
     *  con definici�n de estilos.
     */
    public String getHtml() {
        StringBuffer res;
        
        res = new StringBuffer();
                
        res.append("<div class='portletBox'>\n");
        res.append("  <div>\n");
        res.append("    <table width='100%' border='0'\n");
        res.append("           cellpadding='0' cellspacing='0'>\n");
        res.append("      <tbody class='portletTitle'>\n");
        res.append("      <tr>\n");
        res.append("        <td>\n");
        res.append(this.getTitle());
        res.append("        </td>\n");
        res.append("        <td align='right' style='font-size:smaller;'>\n");
        res.append(String.valueOf(this.getDate())+"\n");
        res.append("        </td>\n");
        res.append("        </tr>\n");
        res.append("      </tbody>\n");
        res.append("    </table>\n");
        res.append("  </div>\n");
        res.append("  <div class='portletBody'>\n");
        res.append(this.getTop()+"\n");
        res.append("    <A href='");
        res.append((con==null) ? 
                   this.sourcePath : this.con.getURL().toExternalForm());
        res.append("'>");
        res.append("      >>> ");
        res.append("    </A>\n");
        res.append("  </div>\n");
        res.append("</div>\n");
        
        return res.toString();
    }
    
    /** Elimina los recursos almacenados por este portlet. */
    public void finalize() {
        this.sourcePath = null;
        this.con = null;
        this.title = null;
        this.top = null;
    }
    
    /** Un comparador por t�tulo. */ 
    public static class TitleComparator implements java.util.Comparator {
        public int compare(Object obj1, Object obj2) {
            Portlet p1;
            Portlet p2;
            
            p1 = (Portlet) obj1;
            p2 = (Portlet) obj2;
            
            return p1.getTitle().compareTo(p2.getTitle());
        }
    }
    
    /** Un comparador por fechas. */ 
    public static class DateComparator implements java.util.Comparator {
        public int compare(Object obj1, Object obj2) {
            int res;
            
            Portlet p1;
            Portlet p2;
            
            p1 = (Portlet) obj1;
            p2 = (Portlet) obj2;
            
            if (p1.getDate() == p2.getDate()) { res = 0; }
            else if (p1.getDate() < p2.getDate()) { res = -1; }
            else { res = +1; }
            
            return res;
        }
    }
    
    /** Implementaci�n r�pida pero funcional. Compara portlets por
     *  los criterios seleccionados.
     */
    public static class  PortletComparator implements java.util.Comparator {
         /** Ning�n orden en especial. */
        public static final int SORTBY_NOTHING = -1;
        /** Ordenados alfab�ticamente por t�tulo. */
        public static final int SORTBY_TITLE_ASC = 1;
        /** Ordenados alfab�ticamente por t�tulo. */
        public static final int SORTBY_TITLE_DESC = 2;
        /** Ordenados por fecha. */
        public static final int SORTBY_DATE_ASC = 3;
        /** Ordenados por fecha. */
        public static final int SORTBY_DATE_DESC = 4;
        
        /** Criterio elegido. */
        int crit;
        
        public PortletComparator(int crit) {
            this.crit = crit;
        }
        
        public int compare(java.lang.Object obj, java.lang.Object obj1) {
            int res;
            Portlet portlet1;
            Portlet portlet2;
            
            portlet1 = (Portlet) obj;
            portlet2 = (Portlet) obj1;
            
            res = 0;
            if (crit == SORTBY_DATE_ASC) {
                if (portlet1.getDate() < portlet2.getDate()) { res = -1;  }
                else if (portlet2.getDate() > portlet2.getDate()) { res = +1; }
            }
            else if (crit == SORTBY_DATE_DESC) {
                if (portlet1.getDate() < portlet2.getDate()) { res = +1;  }
                else if (portlet2.getDate() > portlet2.getDate()) { res = -1; }
            }
            else if (crit == SORTBY_TITLE_ASC) {
                res = portlet1.getTitle().compareTo(portlet2.getTitle());
            }
            else if (crit == SORTBY_TITLE_DESC) {
                res = portlet1.getTitle().compareTo(portlet2.getTitle()) * (-1);
            }
            return res;
        }
        
        public boolean equals(java.lang.Object obj) {
           return true;
        }
        
    }
    
    
    /** Retorna el t�tulo del portlet. */
    public String toString() {
      return this.title;
    }
     
    public static void main(String[] args) {
        Portlet portlet;
        
        portlet = new Portlet("c:/tomcat3/webapps/"+
                              "examples/jsp/index.html", 150);        
        System.out.println("01234567890123456789**********************");
        System.out.println(portlet.getTitle());
        System.out.println("******************************************");
        System.out.println(portlet.getTop());
        System.out.println("01234567890123456789**********************");
        System.out.println(portlet.getDate());
    }
}

// [PENDIENTE]: recargar cuando la fecha del archivo cambia.