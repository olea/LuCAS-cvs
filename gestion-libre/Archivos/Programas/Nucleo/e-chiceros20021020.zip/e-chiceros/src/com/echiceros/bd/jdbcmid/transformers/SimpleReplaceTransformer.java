/*
 * ReplaceTransformer.java
 *
 * Created on 30 de junio de 2002, 16:13
 */

package com.echiceros.bd.jdbcmid.transformers;

import org.apache.log4j.*;

/**
 * Modifica la sentencia intercambiando las apariciones de un patron
 * por otro. Ignora las diferencias entre may�sculas y min�sculas.
 *
 * @author  jv
 */
public class SimpleReplaceTransformer implements SQLTransformation {
    String from;
    String to;
    
    /** Creates a new instance of ReplaceTransformer */
    public SimpleReplaceTransformer(String from, String to) {
        this.from = from;
        this.to = to;
    }
       
    public String transformSql(String sql) {
        return com.echiceros.lang.StringTools.replaceIgnoreCase(sql, from, to);
    }
    
}
