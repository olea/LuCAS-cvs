/*
 * TrsCreateTransactionEngine.java
 *
 * Created on 23 de noviembre de 2001, 12:00
 */

package com.echiceros.bd.trs;


import org.apache.log4j.*;
import com.echiceros.io.*;
import com.echiceros.bd.*;

/**
 * Permite instanciar servidores y activarlos.
 * 
 * En la definici�n se indicar� el nombre de la clase del servidor
 * (que debe extender BasicServer) y el archivo del que leer�
 * su configuraci�n.
 *
 *    <data>
 *      <classname>
 *         com.echiceros.system.ConfigServer
 *      </classname>
 *      <configpath>
 *        c:/tomcat3/webapps/poscom/fca005/WEB-INF/poscom.xml
 *      </configpath>       
 *    </data>
 *
 * @author  jv
 * @version 1.0
 */
public class TrsCreateServer extends TrsAdapter {

    /** Creates new TrsCreateTransactionEngine*/
    public TrsCreateServer() {
        super();
    }

    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        BasicServer server;
        String configPath;
        String className;
        
        try {
            className = getParam("classname");
            configPath = getParam("configpath");
            Category.getInstance(getClass()).debug(
                 "Instanciando " + className + "." );
            server = (BasicServer) Class.forName(className).newInstance();
            server.loadConfig(configPath);
            server.setStatus(true);
        }
        catch (ClassNotFoundException e) {
            Category.getInstance(getClass()).warn(e.getMessage());
        }
        catch (IllegalAccessException e) {
            Category.getInstance(getClass()).warn(e.getMessage());
        }
        catch (InstantiationException e) {
            Category.getInstance(getClass()).warn(e.getMessage());
        }
    }
    
}
