package com.echiceros.io;

import java.io.*;
import java.net.*;
import org.apache.log4j.*;
import com.echiceros.system.*;

/** 
 *
 *  Servidor b�sico sobre el que se puede implementar
 *  cualquier aplicaci�n que necesite atender peticiones
 *  v�a socket.
 *
 */
public abstract class BasicServer implements Runnable { 
   /** Puerto por defecto. Es fundamental fijarlo si utilizamos el
    *  constructor sin par�metros.
    */
   int port = Integer.MIN_VALUE;
    
   /** El servicio se lanza en un thread paralelo (invocaci�n asincrona). */
   protected Thread runner = null;  
   /** Configuraci�n. */
   protected ConfigEngine config = null;
    
   /** Crea la instancia pero NO lanza el servicio. 
    */
   public BasicServer() {
     super();
     this.config = new ConfigEngine();
   }
   
   /* Crea la instancia pero NO lanza el servicio.
    * @param configFilePath par�metro con el path de la configuraci�n
    *        del servidor.
    */
   public BasicServer(String configFilePath) {
     this();
     loadConfig(configFilePath);
   }
   
   /** Carga la configuraci�n a partir del archivo indicado. */
   public void loadConfig(String path) {
//    Category.getInstance(getClass()).info("instanciado ("+path+").");
      this.config.loadFromFile(path);
   }
   
   /** Retorna el ConfigEngine utilizado por este server. */
   public ConfigEngine getConfigEngine() {
       return config;
   }
   
   /** Fija el puerto de conexi�n. */
   public void setPort(int port) {
       this.port = port;
   }
   
   /** Activa o desactiva el servicio. Si ya lo estaba, no
    * cambia el estado.
    * @param activate Indica el estado en el que debe terminar el server
    * (activado o desactivado).
    */
   public void setStatus(boolean activate) {
       if (activate == true) {
           if (runner == null) {
              Category.getInstance(getClass()).info("lanzado.");
              runner = new Thread(this);
              runner.start();
           }
       }
       else {
           Category.getInstance(getClass()).info("detenido.");
           runner = null;
       }
   }
    
   /** Abre el socket para aceptar conexiones, las espera y
    * crea servicios para tratarlas. Se ejecuta en un thread
    * propio.
    */   
   public void run() {
       ServerSocket server;
       Socket sck;
       
       try {
           if (port == Integer.MIN_VALUE) {
               port = this.config.getIntProperty("port");
           }
           Category.getInstance(getClass()).info("puerto " + port + ".");
           server = new ServerSocket(port);
           server.setSoTimeout(1000*30);
           while (runner != null) {
               try {
                   sck = server.accept();
                   newService(sck);
               }
               catch (InterruptedIOException e) {
                   //   Category.getInstance(getClass()).info(e.getMessage());
               }
           }
           server.close();
       }
       catch (IOException e) {
           Category.getInstance(getClass()).warn(e); 
       }
   }
   
   /** Deber�a procesar la conexi�n que se indica como par�metro.
    *  puede utilizar como base la clase BasicServer.Service.
    */
   protected abstract void newService(Socket sck);
   
   /** Implementa la clase encargada de gestionar una conexi�n. */
   public static abstract class Service implements Runnable {
       protected Socket sck;
       protected Thread runner;
       
       /** Trata un nuevo servicio.
        * @param sck El socket que ha abierto la conexi�n.
        */       
       public Service(Socket sck) {
           this.sck = sck;
           this.runner = new Thread(this);
           runner.start();
       }
       
       /** Ejecuta la transacci�n indicada desde el socket.
        * Se ejecuta en un nuevo thread para permitir la concurrencia.
        */       
       public abstract void run();

   }
   
   
   public static void main(String[] args) throws Exception {     
   }
   
}