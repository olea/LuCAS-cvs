/*
 * TrsCreateDataSourceCache.java
 *
 * Created on 6 de noviembre de 2001, 18:32
 */

package com.echiceros.bd.trs;


import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.system.pooling.*;

/**
 * Comprueba si la cach� cuyo nombre indicamos existe o no. En caso
 * negativo la crea y a�ade las conexiones a bases de datos que indiquemos
 * seg�n la url correspondiente.
 * 
 * La definition tiene el siguiente formato:
 *
 *    <data>
 *      <name>mainDataSource</name>
 *      <limit>20</limit>
 *      <class>org.gjt.mm.mysql.Driver</class>
 *      <url>
 *        jdbc:mysql://127.0.0.1/vincere?user=trsengine&amp;password=trs3ng1n3&amp;autoReconnect=true
 *      </url>
 *    </data>
 *
 * @author  jv
 * @version 1.0
 */
public class TrsCreateDataSourceCache extends TrsAdapter {

    /** Creates new TrsCreateDataSourceCache */
    public TrsCreateDataSourceCache() {
        super();
        Category.getInstance(getClass().getName()).debug (
           "Instanciada.");
    }

    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        Cache cache;
        String driverClassName;
        String url;
        String cacheName;
        int limit;
        Connection con;
        
        try {
            driverClassName = super.definition.getChildTextTrim("class");
            url = super.definition.getChildTextTrim("url");
            cacheName = super.definition.getChildTextTrim("name");
            limit = Integer.parseInt(definition.getChildTextTrim("limit"));
            Category.getInstance(getClass().getName()).debug (
               "driver: " + driverClassName + ", " +
               "cache: " + cacheName + ", " +
               "limit: " + limit + ", " +
               "url: " + url + ".");
            Class.forName(driverClassName).newInstance();
            Category.getInstance(getClass().getName()).debug (
               "Driver cargado.");
            cache = Cache.createCache(cacheName, limit);
            cache.addCacheDestroyer(new ConnectionCacheDestroyer());
            Category.getInstance(getClass().getName()).debug (
               "Cach� creada.");
            for (int i=0; i < limit; i++) {
                con = DriverManager.getConnection(url);
                cache.put(con);
            }
            Category.getInstance(getClass().getName()).debug (
               "Elementos (" + limit + ") instanciados. Todo ok.");
            
        }
        catch (ClassNotFoundException e) {
            throw new TrsException(getClass().getName() + ": " + e);
        }
        catch (IllegalAccessException e) {
            throw new TrsException(getClass().getName() + ": " + e);
        }
        catch (InstantiationException e) {
            throw new TrsException(getClass().getName() + ": " + e);
        }
        catch (SQLException e) {
            throw new TrsException(getClass().getName() + ": " + e);
        }
    }
    
    
}
