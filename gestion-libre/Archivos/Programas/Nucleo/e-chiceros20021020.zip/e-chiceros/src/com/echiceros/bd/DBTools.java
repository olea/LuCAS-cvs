/*
 * DBTools.java
 *
 * Created on 10 de enero de 2002, 10:09
 */

package com.echiceros.bd;

/**
 * Diversas utilidades para tratar con bases de datos.
 *
 * @author  jv
 */
public class DBTools {

    /** Realiza el escape de un valor para evitar que tenga caracteres
     *  que puedan interferir en una sql.
     *
     *        '       -->     ''
     */
    public static String escape(String value) {
        StringBuffer res;
        char c;
        
        res = new StringBuffer();
        for (int i=0; i < value.length(); i++) {
            c = value.charAt(i);
            if (c == '\'') {
                res.append("''");
            } else {
                res.append(c);
            }
        }
        
        return res.toString();
    }

}
