/*
 * XMLTools.java
 *
 * Created on 31 de enero de 2002, 15:17
 */

package com.echiceros.xml;

import java.util.*;
import org.jdom.*;
import org.apache.log4j.*;

/**
 * Diversas utilidades desarrolladas para trabajar sobre xml.
 *
 * @author  jv
 * @version
 */
public class XMLTools {


    /** En muchas ocasiones el documento xml posee una lista de
     *  nodos del mismo nombre que asocian parejas de valores, como
     *  por ejemplo
     *
     *   <data>
     *     <element key="wop" value="wowowop!"/>
     *     <element key="wip" value="wikiwiki!"/>
     *   </data>
     *
     *  Normalmente deseamos recuperar el valor de un elemento concreto
     *  de forma r�pida y eficiente. Este m�todo transforma un documento
     *  como el anterior en una hashtable indexada por el segundo par�metro:
     *
     *      hash = children2hash(data, "element", "key", "value");     
     *      hash.get("wop") ---> wowowop
     *
     *  @param root Element que contiene los componentes de la hash.
     *  @param elementName nombre de los elementos contenidos.
     *  @param keyName Nombre del atributo que indica la clave.
     *  @param valueName Nombre del atributo que indica el valor.
     */
     public static Hashtable children2hash(Element root, String elementName,
                                           String keyName, String valueName) {
        Hashtable elements;
        Iterator iter;
        Element anElement;
        
        elements = new Hashtable();
        iter = root.getChildren(elementName).iterator();
        while (iter.hasNext() == true) {
            anElement = (Element) iter.next();
            elements.put(anElement.getAttributeValue(keyName),
                              anElement.getAttributeValue(valueName));
        }
        
        return elements;
     }
    
     /** 
      *  Convierte un resultset en un documento xml. La estructura NO
      *  est� bien formada: retorna una enumeraci�n de los campos
      *  del rs con el nombre como name y el valor como content.
      *
      *  La implementaci�n se basa en ResultSetMetadata.getColumnName(...),
      *  por lo que resulta fundamental que dicho m�todo funcione 
      *  correctamente.
      *
      *  @param rs fuente de datos.
      *  @returns una cadena con los elementos, por ejemplo, 
      *           <nombre>javi</nombre><nacim>1976</nacim>.
      *           null si ha fracasado la recuperaci�n.
      */
     public static String rs2xml(java.sql.ResultSet rs) {
         StringBuffer res = null;
         java.sql.ResultSetMetaData meta;
         String name, value;
         
         try {
             res = new StringBuffer();
             meta = rs.getMetaData();
             for (int i=1; i <= meta.getColumnCount(); i++) {
                 name = meta.getColumnName(i);
                 value = rs.getString(i);
                 res.append("<" + name + ">");
                 res.append("  <![CDATA[" + value +"]]>");
                 res.append("</" + name + ">");
             }
         }
         catch (java.sql.SQLException e) {
             res = null;
             Category.getInstance("com.echiceros.xml.XMLTools").warn(e.getMessage());
         }
         
         return (res == null) ? null : res.toString();
     }

     
}
