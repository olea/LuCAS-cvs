/*
 * TrsXML.java
 *
 * Created on 7 de octubre de 2001, 20:55
 */

package com.echiceros.bd.trs;

import com.echiceros.bd.TransactionEngine;

/**
 * M�todos comunes a todas las transacciones basadas en xml
 * que desarrollaremos.
 * 
 * @author  jv
 * @version 3.0
 */
public interface Trs {

    /** Nombr� de la cach� que hace el pooling de conexiones. */
    public static final String 
      DEFAULT_CONNECTION_CACHE_NAME = "demoDataSource";
    
    
    /** Fija la informaci�n que la transacci�n podr� utilizar. */
    void setDefinition(org.jdom.Element data);
    /** Fija la informaci�n que la transacci�n podr� utilizar. */
    void setDefinition(String xml);
    /** Fija el canal utilizado para retornar informaci�n al invocador. */
    void setOut(java.io.PrintStream out);
    /** Ejecuta la transacci�n. */
    void execute() throws TrsException;
}

