/*
 * ConditionExists.java
 *
 * Created on 14 de febrero de 2002, 12:20
 */

package com.echiceros.www.customtags.flowcontrol;

import javax.servlet.http.*;

/**
 * Eval�a si en el alcance indicado por el par�metro "scope" existe
 * la variable cuyo nombre se indica. Los valores aceptados son
 * parameter (par�metro de request), request (atributo del request) y
 * session (atributo de sesi�n).
 *
 * Pueden especificarse varios separ�ndolos por comas.
 *
 * Los par�metros debe envaluarse antes que el body y por lo tanto
 * deben estar inclu�dos en el tag como atributo params.
 *
 *    <gen:processor 
 *             className="com.echiceros.www.customtags.flowcontrol.ConditionExists"
 *             params="<info>
 *                       <name>user.key</name>
 *                       <scope>session</scope>
 *                       <value>false</value>
 *                    </info>">
 *     ...
 *    </gen:processor>
 *
 * @author  jv
 */
public class ConditionExists extends ConditionProcessor {

    /** Creates a new instance of ConditionExists */
    public ConditionExists() {
        super();
    }

    protected boolean eval() {
        boolean res;
        String name;
        String scope;
        
        name = this.getXmlParam("xml", "name");
        scope = this.getXmlParam("xml", "scope");
        
        if ((scope.indexOf("parameter") != -1) && 
            (getRequest().getParameter(name) != null)) {
                res = true;
        } else if ((scope.indexOf("request") != -1) && 
                   (getRequest().getAttribute(name) != null)) {
                res = true;  
        } else if ((scope.indexOf("session") != -1) && 
                   (getRequest().getSession().getAttribute(name) != null)) {
                res = true;
        } else {
                res = false;
        }
        
        return res;
    }
    
}
