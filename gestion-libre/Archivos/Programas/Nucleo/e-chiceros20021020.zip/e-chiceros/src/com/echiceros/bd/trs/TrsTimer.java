/*
 * TrsTimer.java
 *
 * Created on 16 de mayo de 2002, 18:56
 */

package com.echiceros.bd.trs;

import java.util.*;
import java.io.*;
import org.apache.log4j.*;
import com.echiceros.io.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 *
 * Implementa una transacci�n que cada un determinado periodo
 * de tiempo lanzar� otra. La definici�n esperada es la 
 * siguiente:
 *
 *     <data>
 *        <name><!-- Transacci�n a invocar --></name>
 *        <data> 
 *            <!-- Info de la transacci�n invocada-->
 *        </data>
 *        <interval>60*1000</interval>
 *     </data>
 *
 * cada interval milisegundos ejecutar� la transacci�n cuyo
 * nombre se indica pas�ndole el data inclu�do en la definici�n.
 * La primera transacci�n se ejecutar� justo despu�s de instanciarse
 * TrsTimer. 
 *
 * El bucle se repetir� mientras el atributo status valga true.
 * En la actual implementaci�n esto significa que se repetira
 * indefinidamente, pero es posible redefinir la clase para
 * evitarlo.
 *
 * NOTA: cada vuelta del bucle crea una nueva instancia de la
 *       transacci�n a ejecutar.
 *
 * @author  jv
 */
public class TrsTimer 
extends com.echiceros.bd.trs.TrsAdapter 
implements Runnable {

    /** true ssi est� ejecut�ndose el bucle. */
    boolean status;
    /** Si una tarea produce un error se almacenara aqui. */
    Exception error;
    /** Thread del bucle. */
    Thread runner;

    
    /** Creates a new instance of TrsTimer */
    public TrsTimer() {
        super();
        this.status = false;
        this.error = null;
    }


    /** Ejecuta la transacci�n.   */
    public void execute() throws TrsException {
        this.status = true;
        runner = new Thread(this);
        runner.start();
    }
    
    /** Invocado al finalizar cada vuelta de bucle. Carne 
     *  de redefinici�n.
     *
     *  @param xmlResponse respuesta de la transacci�n ejecutada.
     */
    protected void processResponse(String xmlResponse) {
    }
    
    
    public void run() {
        Trs trs;
        StringWriter out;


        try {
            while (this.status == true) {
                Category.getInstance(getClass()).debug("Tick!");
                out = new StringWriter();
                trs = (Trs) Class.forName(getParam("name")).newInstance();
                trs.setDefinition(definition.getChild("data"));
                trs.setOut(new PrintStream(new OutputWriterStream(out)));
                trs.execute();
                this.processResponse(out.getBuffer().toString());
                runner.sleep(Long.parseLong(getParam("interval")));
            }
        }
        catch (InterruptedException e) {
            Category.getInstance(getClass()).warn(e.getMessage());
        }
        catch (TrsException e) {
            error = e;
            Category.getInstance(getClass()).warn(e.getMessage());
        }
        catch (ClassNotFoundException e) {
            error = e;
            Category.getInstance(getClass()).warn(e.getMessage());
        }
        catch (IllegalAccessException e) {
            error = e;
            Category.getInstance(getClass()).warn(e.getMessage());
        }
        catch (InstantiationException e) {
            error = e;
            Category.getInstance(getClass()).warn(e.getMessage());
        }
    }
    
    
    /**
    * @param args the command line arguments
    */
    public static void main (String args[]) throws Exception {
        TrsTimer trs;
        String xml;
        
        xml =
         "     <data>" + 
         "        <name>com.echiceros.bd.trs.TrsConfigLog4j</name>" + 
         "        <data> " + 
         "           <configPath>d:/userinfo/tomcat3/webapps/fca005/web-inf/log4jconfig.xml</configPath>" + 
         "        </data>" + 
         "        <interval>5000</interval>" + 
         "     </data>";
        
        trs = new TrsTimer();
        trs.setDefinition(xml);
        trs.setOut(System.out);
        trs.execute();
        
    }
}
