/*
 * AxeNumeric.java
 *
 * Created on 6 de febrero de 2002, 12:34
 */

package com.echiceros.graphics.chart;

import java.util.*;
import java.text.*;
import com.echiceros.lang.*;

/**
 * Un eje de coordenadas num�rico. 
 *
 * @author  jv
 */
public class AxeNumeric extends Axe{

    /** Valor m�nimo del eje. */
    private double min;
    
    /** Valor m�ximo del eje. */
    private double max;
    
    /** Cada cu�ntos valores deben presentarse las etiquetas. */
    private double step; 
    
    
    /** Creates a new instance of AxeNumeric */
    public AxeNumeric(String name, double min, double max, double step) {
        super(name);
        setMin(min);
        setMax(max);
        setStep(step);
    }

    /** Retorna el factor correspondiente al punto indicado.
     * @param El punto a situar. Debe ser un valor num�rico: Integer, Double...
     * @returns Un n�mero del 0 al 1 indicando a qu�
     *          distancia del eje debe situarse el punto.
     */
    public float getPointDistance(Object point) {
        float res;
        double primPoint;
        
        primPoint = Double.parseDouble(point.toString());        
        res = (float) ((primPoint-this.min) / (getMax() - getMin()));
        
        return res;
    }
    
    /** Retorna una hashtable con la distancia a la que se debe
     *  dibujar cada punto de la escala (key: punto, value: distancia).
     *  El punto se almacena como un string con dos decimales.
     */
    public java.util.Hashtable getLabelsDistances() {
        Hashtable res;
        DecimalFormat format;
        double current;
        float distance;
        
        res = new Hashtable();
        format = new DecimalFormat("#,##0.00");
        current = getMin();
        while (current <= getMax()) {
            distance = this.getPointDistance(new Double(current));
            res.put(format.format(current), new Float(distance));
            current = current + getStep();
        }
        Runtime.getRuntime().gc();
        
        return res;
    }


    /** Getter for property min.
     * @return Value of property min.
     */
    public double getMin() {
        return this.min;
    }
    
    /** Setter for property min.
     * @param min New value of property min.
     */
    public void setMin(double min) {
        this.min = min;
    }
    
    /** Getter for property max.
     * @return Value of property max.
     */
    public double getMax() {
        return this.max;
    }
    
    /** Setter for property max.
     * @param max New value of property max.
     */
    public void setMax(double max) {
        this.max = max;
    }
    
    /** Getter for property step.
     * @return Value of property step.
     */
    public double getStep() {
        return this.step;
    }
    
    /** Setter for property step.
     * @param step New value of property step.
     */
    public void setStep(double step) {
        this.step = step;
    }
    
    /** Retorna el ordinal (valor num�rico) correspondiente a un
     *  determinado punto sobre el eje. 
     *  En este caso se limita a convertir el valor a double.
     *  @param point El punto sobre el eje. Normalmente ser� la
     *               componente de un punto sobre el mismo.
     */
    public double getOrdinalValue(Object obj) {
        double res;
        
        res = Double.parseDouble(obj.toString());
        
        return res;
    }
    
    /** Retorna el valor del punto indicado como un label susceptible
     *  de ser presentado como texto en pantalla. En este caso 
     *  retorna el valor num�rico del objeto con dos decimales.
     */
    public String getLabelValue(Object obj) {
        String text;
        DecimalFormat format;
        
        format = new DecimalFormat("#,##0.00");        
        text = format.format(this.getOrdinalValue(obj));
        
        return text;
    }
    
    /** Retorna la distancia que existe entre los dos puntos m�s
     * cercanos de la enumeraci�n indicada.
     * @param points Los puntos que queremos comprobar.
     * @returns la distancia l�gica.
     */
    public double getMinDistance(List points) {
        double minDist;
        Enumeration enum;
        
        enum = this.getOrderedPoints(points);
        minDist = calcMinDist(enum);
        minDist = this.getPointDistance(new Double(minDist)) - 
                  this.getPointDistance("0");
        
        return minDist;
    }

}
