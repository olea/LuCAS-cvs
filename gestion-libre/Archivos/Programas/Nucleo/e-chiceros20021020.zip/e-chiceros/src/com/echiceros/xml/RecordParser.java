package com.echiceros.xml;

import java.sql.*;
import java.util.*;
import org.jdom.*;
import org.jdom.input.SAXBuilder;

/** Esta clase resulta tremendamente eficiente a la hora de convertir
 *  un documento xml en una estructura de datos f�cilmente tratable.
 *  
 *  Actualmente est� especialmente dise�ada para procesar xml con
 *  una estructura de records y fields (como la del ejemplo que
 *  aparece en el m�todo main).
 *
 *  this.tables est� indexado por nombre de tabla y contiene un
 *  vector con todos los registros que deben ser actualizados en
 *  esa tabla.
 *
 *  Cada entrada del vector es una hashtable con parejas
 *  <nombre de campo, valor del campo>.
 *
 *  Cada registro pasa a ser un hashtable del vector de records
 *  y cada columna se guarda como una pareja <nombre,valor> en
 *  estas hash.
 *
 *  Por convenio, deberia indicarse a continuaci�n del nombre
 *  de la tabla el pool en la que se encuentra, encerrado entre
 *  parentesis.
 *
 *  [PENDIENTE] Ser�a intersante sustituir la fuente de xml por
 *              un stream.
 */
public class RecordParser {
    Element root;
    /** Almacena vectores con los elements que contienen registros.
     *  cada vector est� indexado por el nombre de la tabla de los
     *  registros que contiene.
     */
    Hashtable tables;
    /** Tabla que se utilizar� por defecto si no se especifica
     *  en el record.
     */
    String defaultTableName;
    /** Nombre del pool que se utilizar� por defecto si se especifica 
     *  como elemento bajo el rootElement. 
     */
    String cache;
    
    protected RecordParser() {
        tables = new Hashtable();
        defaultTableName = "";
        cache = null;
    }
    
    public RecordParser(String xml) {
        this();
        Document doc;
        SAXBuilder builder;
        
        try {
            builder = new SAXBuilder();
            doc = builder.build(new java.io.StringReader(xml));
            root = doc.getRootElement();
        }
        catch (JDOMException e) {
            throw new IllegalArgumentException(getClass().getName() + " " + e);
        }
    }
    
    public RecordParser(Document doc) {
        this();
        this.root = doc.getRootElement();
    }
    
    public RecordParser(Element rootElement) {
        this();
        this.root = rootElement;
    }
    
    public void setDefaultTableName(String tableName) {
        this.defaultTableName = tableName;
    }
    
    /** Localiza los records y delega el procesamiento de los fields. */
    public void execute() {
        if (this.root.getChildText("cache") != null) {
          this.cache = root.getChildText("cache");
        }
        executeOverRecord(root);
    }
    
    protected void executeOverRecord(Element elem) {
        List list;
        Element current;
        
        current = elem;
        do {
            list = current.getChildren("record");
            for (int i=0; i < list.size(); i++)  {
                current = (Element) list.get(i);
                addRecord(current);
                executeOverRecord(current);
            }
        } while (list.size() > 0);
    }
    
    protected void addRecord(Element record) {
        String tableName;
        String poolName;
        Vector table;
        
        tableName = record.getAttributeValue("table");
        if (tableName == null) { 
            tableName = this.defaultTableName;
        }
        table = (Vector) this.tables.get(tableName.toUpperCase());
        if (table == null) {
            table = new Vector();
            tables.put(tableName.toUpperCase(), table);
        }
        table.addElement(record);
    }
    
    /** Retorna el nombre de la cach� por defecto. */
    public String getDefaultCacheName() {
      return this.cache;
    }
    
    /** Retorna los nombres de las tablas con registros. */
    public Enumeration getTables() {
        return tables.keys();
    }
    
    /** Retorna el n�mero de registros parseado para la tabla indicada. */
    public int getRecordCount(String tableName) {
        Vector table;
        
        table = (Vector) this.tables.get(tableName.toUpperCase());
        
        return (table == null) ? 0 : table.size();
    }
    
    /** Retorna Elements de cada Field encontrado en el registro. */
    public Enumeration getFields(String tableName, int recordIdx) {
        Vector table;
        Element record;
        List list;
        
        table = (Vector) tables.get(tableName.toUpperCase());
        record = (Element) table.elementAt(recordIdx);
       
        list = record.getChildren("field");
        return Collections.enumeration(list);
    }
    
    /** Retorna un Hashtable con los valores de los campos de un
     *  registro indexados por nombre de registro.
     */
    public Hashtable getFieldsValues(String tableName, int recordIdx) {
        Hashtable res;
        Vector table;
        Element record;
        Element field;
        List list;
        
        table = (Vector) tables.get(tableName.toUpperCase());
        record = (Element) table.elementAt(recordIdx);
       
        list = record.getChildren("field");
        res = new Hashtable();
        for (int i=0; i < list.size(); i++) {
            field = (Element) list.get(i);
            res.put(field.getAttributeValue("name"), 
                    field.getAttributeValue("value"));
        }
        
        return res;
    }
        
    
    public String toString() {
        StringBuffer res;
        Enumeration tableEnum;
        Vector records;
        Enumeration fields;
        String tableName;
        Element currentField;
        String fieldName;
        String fieldValue;
        
        res = new StringBuffer();
        tableEnum = tables.keys();
        while (tableEnum.hasMoreElements() == true) {
          tableName = (String) tableEnum.nextElement();
          res.append("<<" + tableName + ">> [");
          records = (Vector) tables.get(tableName.toUpperCase());
          for (int i=0; i < records.size(); i++) {
              fields = this.getFields(tableName, i);
              while (fields.hasMoreElements() == true) {
                currentField = (Element) fields.nextElement();
                fieldName = currentField.getAttributeValue("name");
                fieldValue = currentField.getAttributeValue("value");
                res.append("(" + fieldName + " = " + fieldValue + "), ");
              }
              if (res.length() != 0) {
                res.setLength(res.length()-2);
              }
              res.append(" : ");
          }
          res.setLength(res.length()-3);
          res.append("] ");
        }
        res.setLength(res.length()-1);
        return res.toString();
    }
    
    public static void main(String[] args) {
        RecordParser conversor;
        String xml;
        
        xml = "<data>  " + 
              "  <record table=\"wop\" pool=\"mainpool\">" + 
              "    <field name=\"RADICAL\" value=\"1\" />" + 
              "    <field name=\"CLIENT\" value=\"2\" />" + 
              "    <field name=\"CENTRE\" value=\"3\" />" + 
              "    <field name=\"GESTOR\" value=\"4\" />" + 
              "    <field name=\"VOLUM\" value=\"5\" />" + 
              "  </record>" + 
              "  <record>" + 
              "    <field name=\"RADICAL\" value=\"6\" />" + 
              "    <field name=\"CLIENT\" value=\"7\" />" + 
              "    <field name=\"CENTRE\" value=\"8\" />" + 
              "    <field name=\"GESTOR\" value=\"9\" />" + 
              "    <field name=\"VOLUM\" value=\"10\" />" + 
              "  </record>" + 
              "  <record table=\"wop\" pool=\"mainpool\">" + 
              "    <field name=\"RADICAL\" value=\"11\" />" + 
              "    <field name=\"CLIENT\" value=\"12\" />" + 
              "    <field name=\"CENTRE\" value=\"13\" />" + 
              "    <field name=\"GESTOR\" value=\"14\" />" + 
              "    <field name=\"VOLUM\" value=\"15\" />" + 
              "  </record>" + 
              "</data>";
        conversor = new RecordParser(xml);
        conversor.execute();
        System.out.println(conversor);
    }
}