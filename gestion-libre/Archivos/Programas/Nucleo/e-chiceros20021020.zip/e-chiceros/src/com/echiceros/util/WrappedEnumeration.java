/*
 * WrappedEnumeration.java
 *
 * Created on 8 de febrero de 2002, 11:43
 */

package com.echiceros.util;

import java.util.*;

/**
 * Permite convertir un iterador en una Enumeration.
 * �til para utilizar Collections sobre par�metros Enumeration.
 * @author  jv
 */
public class WrappedEnumeration implements Enumeration {
    Iterator iter;
    
    /** Creates a new instance of WrappedEnumeration */
    public WrappedEnumeration(Iterator iter) {
        this.iter = iter;
    }

    public boolean hasMoreElements() {
        return iter.hasNext();
    }
    
    public Object nextElement() {
        return iter.next();
    }
    
}
