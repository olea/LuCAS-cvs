/*
 * TagStreamProcessor.java
 *
 * Created on 14 de febrero de 2002, 12:26
 */

package com.echiceros.www.customtags;

import javax.servlet.http.*;
import com.echiceros.io.StreamProcessor;

/**
 * Un processor con acceso al request y que permite la cancelaci�n
 * de la evaluaci�n del body. Especialmente dise�ado para su uso
 * con tags.
 *
 * @author  jv
 */
public abstract class TagStreamProcessor extends StreamProcessor {
    HttpServletRequest request;
    
    /** Creates a new instance of TagStreamProcessor */
    public TagStreamProcessor() {
        super();
    }
    
    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }
    
    public HttpServletRequest getRequest() {
        return this.request;
    }
    
    public abstract boolean cancelBodyEvaluation();

}
