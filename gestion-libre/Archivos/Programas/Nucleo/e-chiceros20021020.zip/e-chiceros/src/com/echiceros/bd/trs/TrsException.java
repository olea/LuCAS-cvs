/*
 * TrsException.java
 *
 * Created on 7 de octubre de 2001, 20:57
 */

package com.echiceros.bd.trs;

/**
 * Error al ejecutar una transacci�n.
 *
 * @author  jv
 * @version  1.0
 */
public class TrsException extends RuntimeException {

    /** Creates new TrsException */
    public TrsException() {
        super();
    }
    
    public TrsException(String message) {
        super(message);
    }

}
