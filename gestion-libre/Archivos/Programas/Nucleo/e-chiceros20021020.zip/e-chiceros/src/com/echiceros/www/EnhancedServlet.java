/*
 * EnhancedServlet.java
 *
 * Created on 28 de noviembre de 2001, 12:36
 */
 
package com.echiceros.www;           

import javax.servlet.*;
import javax.servlet.http.*;
import com.echiceros.system.pooling.*;

/** 
 * Un servlet con los m�todos get y post redireccionados al process.
 * En realidad lo he terminado creando para poder utilizar crear
 * servlets que sen invocables de una forma sencilla desde el
 * TransactionServlet, encaden�ndolos entre ellos sin necesidad
 * de tener que registrarlos en web.xml. En realidad, se trata
 * del template que viene con netbeans con el acceso al m�todo
 * de proceso abierto a public y una cach� de instancias.
 * Las consideraciones de multithreading deben mantenerse. 
 *
 * @author  jv
 * @version 1
 */
public abstract class EnhancedServlet extends HttpServlet {
   
    /** Retorna una instancia al EnhancedServlet indicado. Por supuesto,
     *  no es obligatorio utilizar este m�todo para crear las instancias.
     *  @param className Nombre de la clase del enhanced servlet.
     *  @returns La instancia requerida.
     */
    public static EnhancedServlet getInstance(String className) {
        Cache cache;
        EnhancedServlet servlet;
        
        cache = Cache.getDefaultCache().createCache("EnhancedServlets");
        servlet = (EnhancedServlet) cache.get(className, false);
        if (servlet == null) {
            try {
                servlet = (EnhancedServlet) Class.forName(className).newInstance();
                cache.put(className, servlet);
            }
            catch (ClassNotFoundException e) {
                throw new IllegalArgumentException( 
                  "EnhancedServlet.getInstance(...):" + e);
            }
            catch (IllegalAccessException e) {
                throw new IllegalArgumentException(
                  "EnhancedServlet.getInstance(...):" + e);
            }
            catch (InstantiationException e) {
                throw new IllegalArgumentException(
                  "EnhancedServlet.getInstance(...):" + e);
            }
        }
        
        return servlet;
    }
        
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    public void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
    } 

    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }

}
