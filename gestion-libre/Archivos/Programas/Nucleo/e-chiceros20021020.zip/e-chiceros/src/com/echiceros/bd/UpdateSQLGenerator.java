/*
 * UpdateSQLGenerator.java
 *
 * Created on 10 de enero de 2002, 10:05
 */

package com.echiceros.bd;

import java.util.*;
import java.sql.*;
import org.jdom.*;
import org.apache.log4j.*;
import com.echiceros.system.pooling.*;
import com.echiceros.bd.*;

/**
 * Esta fabulosa clase permite crear sentencias de actualizaci�n sql 
 * (inserts y updates) de forma completamente autom�tica. Para funcionar
 * correctamente solo precisa inicializarse con el nombre de la tabla que
 * se pretende actualizar. Ella misma es capaz de localizar la cach�
 * que contiene las conexiones a la base de datos que posee la tabla y
 * de generar la consulta teniendo en cuenta las claves primarias.
 *
 * @author  jv
 * @version 1.0
 */
public class UpdateSQLGenerator {
    /** Cach� de donde extraer las conexiones. */
    Cache cache;
    /** Conexi�n en uso. */
    Connection con;
    /** Metainformaci�n de la tabla. */
    MetaData meta;
    /** Claves primarias de esa tabla. Se ir�n eliminando
     *  conforme se asigne un valor a cada una de ellas. Si al
     *  hacer el close() todavia quedan elementos en el vector se
     *  lanzar� una SQLException.
     */
    Vector pks;

    /** Campos que componen el insert */
    StringBuffer sqlInsert1;
    /** Valores de los campos del insert. */
    StringBuffer sqlInsert2;
    /** Asignaciones del update. */
    StringBuffer sqlUpdate1;
    /** condiciones del where del update. */
    StringBuffer sqlUpdate2;
    String table;

    /** Crea una nueva instancia.
     *  @param table la tabla que deseamos actualizar. 
     */
    public UpdateSQLGenerator(String table) {

        this.table = table;
        this.cache = CacheFinder.getInstance().getCacheWithTable(table);
        if (this.cache == null) {
            Category.getInstance(getClass()).warn(
              "No se ha encontrado la cach� de " + table + ".");
        }
        this.con = (Connection) cache.get(true);
        this.meta = MetaData.getInstance(con, table);
        this.setPks(table);

        this.sqlInsert1 = new StringBuffer();
        this.sqlInsert2 = new StringBuffer();
        this.sqlUpdate1 = new StringBuffer();
        this.sqlUpdate2 = new StringBuffer();
    }

    /** Carga this.pks con las claves primarias. */
    protected void setPks(String table) {
        Vector pks;
        Enumeration enum;
        String pk;

        pks = new Vector();
        enum = meta.getPrimaryKeyNames();
        while (enum.hasMoreElements() == true) {
            pk = (String) enum.nextElement();
            pks.addElement(pk);
        }

        this.pks = pks;
    }

    /** A�ade a los distintos buffers las porciones sql correspondientes.
     *  @param column Columna a a�adir.
     *  @param value  Value a fijar.
     */
    public void addValue(String column, String value) 
    throws SQLException {        
        this.addValue(column, value, null);
    }
    
    /** A�ade a los distintos buffers las porciones sql correspondientes.
     *  @param column Columna a a�adir.
     *  @param value  Value a fijar.
     *  @param oldValue Utilizado para asegurarnos de que no intentamos
     *         modificar  una clave primaria. Si su valor es distinto de
     *         null y column es clave primaria lanzar� una SQLException en
     *         el caso de que value sea distinto de oldvalue.
     */
    public void addValue(String column, String value, String oldValue) 
    throws SQLException { 
        MetaData.ColumnMetaData cmeta;

        column = column.toUpperCase();
        cmeta = meta.getColumnMetaData(column);
        if (cmeta == null) {
            this.close();
            throw new SQLException(getClass().getName() + ": " + 
                       "Column " + column + " does not exists.");
        }
        if ((cmeta.isAlfa() == false) && (value.length() == 0)) {
            Category.getInstance(getClass()).debug(
              "Valor ignorado (num�rico vac�o): " + column + ".");
        }
        else {
            if ((oldValue != null) && (oldValue.equals(value) == false) &&
                (this.pks.contains(column) == true)) 
            {  this.close();
               throw new SQLException (getClass().getName() + ": " +
                           "Primary Keys cannot be modified (" + column + ").");
            }
            sqlInsert1.append(column + ", ");

            // Si es alfanum�rica a�adimos las comillas simples.
            // perd�n por usar el par�metro ;)
            value = DBTools.escape(value);
            if (cmeta.isAlfa() == true) {
                value = "'" + value + "'";
            }
            sqlInsert2.append(value + ", ");
            sqlUpdate1.append ("" + column + " = " + value +", ");
            // Si es clave primaria actualizamos sqlUpdate2
            if (this.pks.contains(column) == true) {
                sqlUpdate2.append("( " + column + " = " + value + ") AND ");
                pks.removeElement(column);
            }            
        }
    }

    public String getInsert() throws SQLException {
        String res;

        close();
        res = "INSERT INTO " + table + 
              "   (" + sqlInsert1.toString() + ") " +
              "VALUES (" + sqlInsert2.toString() + ")";


        return res;
    }

    public String getUpdate()  throws SQLException  {
        String res;

        close();
        res = "UPDATE " + table + " " + 
              " SET " + sqlUpdate1.toString() + " "  +
              "WHERE " +sqlUpdate2.toString();


        return res;
    }

    public void close() throws SQLException {
        if (this.con != null) {
            cache.put(con);
            this.cache = null;
            this.con = null;
            // Si todav�a no se han asignado todas las pks, fallar.
            if (pks.size() > 0) {
                throw new SQLException(this.getClass().getName() + ": " + 
                            "Primary keys not specified (" + pks + ").");
            }

            if (sqlInsert1.length() != 0) {
                sqlInsert1.setLength(sqlInsert1.length()-2);
            }
            if (sqlInsert2.length() != 0) {
                sqlInsert2.setLength(sqlInsert2.length()-2);
            }
            if (sqlUpdate1.length() != 0) {
                sqlUpdate1.setLength(sqlUpdate1.length()-2);
            }
            if (sqlUpdate2.length() != 0) {
                sqlUpdate2.setLength(sqlUpdate2.length()-4);
            }
        }
    }
    
    /** @returns la tabla del generator. */
    public String getTable() {
        return this.table;
    }
    
    /** Retorna una instancia completamente inicializada a partir
     *  de un elemento xml. El formato del documento es un elemento
     *  por cada columna, con el nombre de la misma como name del
     *  elemento y el valor como texto. Si se produce alg�n error
     *  retornar� una instancia nula.
     *
     *  @param table Tabla a actualizar.
     *  @param root Elemento que contiene las columnas/valores.
     */
    public static UpdateSQLGenerator getInstance(String table, Element root) {
        UpdateSQLGenerator gen;
        Iterator childs;
        Element current;
        
        gen = new UpdateSQLGenerator(table);
        try {
            childs = root.getChildren().iterator();
            while (childs.hasNext() == true) {
                current = (Element) childs.next();
                gen.addValue(current.getName(), current.getTextTrim());
            }
            gen.close();
        }
        catch (SQLException e) {
            Category.getInstance("com.echiceros.bd.UpdateSQLGenerator").warn(e);
            gen = null;
        }
        
        return gen;
    }
    
    public static void main(String[] args) throws Exception {
        Connection con;
        Cache cache;
        UpdateSQLGenerator gen;
        
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        con = DriverManager.getConnection("jdbc:odbc:fca005-0");
        cache = Cache.createCache("dataSource", 5);
        cache.put(con);
        gen = new UpdateSQLGenerator("fca005");
        gen.addValue("fcraci", "1", "1");
        gen.addValue("fcdtev", "20010831");
        gen.addValue("fccent", "20800");
        gen.addValue("fcgera", "wop'wop");
        
        System.out.println(gen.getInsert());
        System.out.println(gen.getUpdate());
        
        System.exit(0);
    }
}
