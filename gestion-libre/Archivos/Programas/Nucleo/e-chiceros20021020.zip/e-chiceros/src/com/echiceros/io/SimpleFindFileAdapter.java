/*
 * SimpleFindFileAdapter.java
 *
 * Created on 12 de diciembre de 2001, 19:28
 */

package com.echiceros.io;

import java.util.*;
import java.io.*;

/**
 * Un sencillo finder que retorna en un array los nombres de los ficheros
 * cuyo path coincide con el patr�n indicado.
 *
 * @author  jv
 */
public class SimpleFindFileAdapter implements FindFile.FindFileListener {
    Vector result;
    FindFile finder;
    boolean finished;
    
    /** Creates new SimpleFindFileAdapter */
    public SimpleFindFileAdapter(String folderPath, String pattern) 
    throws IllegalArgumentException {
        result = new Vector();
        try {
            finder = new FindFile(folderPath, pattern);
            finder.addListener(this);
            finished = false;
            finder.start();
            while (finished == false) {
                try { Thread.sleep(500); }
                catch (InterruptedException e) {}
            }
        }
        catch (org.apache.oro.text.regex.MalformedPatternException e) {
            throw new IllegalArgumentException(getClass().getName() + ": " + e);
        }
    }

    /** Retorna un array de strings con el path absoluto de los
     *  ficheros encontrados.
     */
    public String[] getPaths() {
        return (String[]) result.toArray(new String[0]);
    }
    
    /** Ejecutado cuando se inicia el servicio de busqueda.  */
    public void matchStarted() {
    }
    
    /** Ejecutado al finalizarse el servicio de b�squeda.  */
    public void matchStoped() {
        this.finished = true;
    }
    
    /** Ejecutado cada vez que se localiza un grupo de archivos
     * que cumplen el patron.
     */
    public void matchPerformed(FindFile.FindFileEvent evt) {
        Vector files;
        File current;
        
        files = evt.getFiles();
        for (int i=0; i < files.size(); i++) {
            current = (File) files.elementAt(i);
            this.result.addElement(current.getAbsolutePath());
        }
    }
    
    public static void main(String[] args) throws Exception {
        SimpleFindFileAdapter finder;
        String[] res;
        
        finder = new SimpleFindFileAdapter("c:/tomcat3", "s*as");
        res = finder.getPaths();
        
        for (int i=0; i < res.length; i++) {
            System.out.println(res[i]);
        }
    }
}
