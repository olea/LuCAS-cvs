/*
 * MySQLSelectGenerator.java
 *
 * Created on 25 de agosto de 2002, 17:47
 */

package com.echiceros.bd.generator;

/**
 *
 * @author  jv
 */
public class SQLSelectGenerator_SQLServer extends SQLSelectGenerator {
    
    /** Creates a new instance of MySQLSelectGenerator */
    public SQLSelectGenerator_SQLServer() {
        super();
    }
    
    public String getSentence() {
        StringBuffer sentence;
        
        sentence = new StringBuffer(super.getSentence());
        
        if (this.howMany != -1) {
            sentence.delete(0, "SELECT ".length());
            sentence.insert(0, "SELECT TOP " + howMany);
        }
        
        return sentence.toString();
    }
    
}
