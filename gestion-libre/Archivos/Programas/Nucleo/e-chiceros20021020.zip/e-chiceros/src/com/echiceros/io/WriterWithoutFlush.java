/*
 * WriterWithoutFlush.java
 *
 * Created on 30 de octubre de 2001, 15:13
 */

package com.echiceros.io;

import java.io.*;

/**
 *
 * Un envolvente para cualquier writer que evita la utilizaci�n de
 * flush. �til para desarrollar taglibs dada la imposibilidad de 
 * ejecutar esta operaci�n desde un bodytag.
 *
 * @author  jv
 * @version 1.0
 */
public class WriterWithoutFlush extends java.io.Writer {

    Writer writerImp;
    
    /** Creates new WriterWithoutFlush */
    public WriterWithoutFlush(Writer writer) {
        this.writerImp = writer;
    }

    public void close() throws java.io.IOException {
        writerImp.close();
    }
    
    public void flush() throws java.io.IOException {
    }
    
    public void write(char[] values) throws java.io.IOException {
        writerImp.write(values);
    }
    
    public void write(int param) throws java.io.IOException {
        writerImp.write(param);
    }
    
    public void write(java.lang.String str) throws java.io.IOException {
        writerImp.write(str);
    }
    
    public void write(char[] values, int param, int param2) throws java.io.IOException {
        writerImp.write(values,param,param2);
    }
    
    public void write(java.lang.String str, int param, int param2) throws java.io.IOException {
        writerImp.write(str,param,param2);
    }
    
}
