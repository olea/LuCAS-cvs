package com.echiceros.bd;

import java.util.*;
import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.system.pooling.*;

/** Esta clase implementa un pool de conexiones a una base de datos.
 *  En realidad, actualmente se trata solo de un esqueleto.
 *  Est� espec�ficamente pensada para trabajar con drivers de tipo I,
 *  por lo que precisa una serie de datasources en el odbc. Estos
 *  datasources deben llamarse todos igual, excepto en el �ltimo
 *  d�gito que empezar� por un 0 y acabar� por ODBCConnPool.CON_NUMBER-1.
 */ 
public class ODBCConnPool  extends Cache implements Cacheable {
  public static final int CON_NUMBER = 3;

  /** Identificador de la cach�. */
  String id;
  /** url de la conexi�n, exceptuando el �ltimo d�gito. **/
  String url;
  /** usuario autorizado. */
  String user;
  /** password del usuario. */
  String password;
  /** Utilizado por getUrl() para balancear las conexiones entre 
   *  los odbc.
   */
  public int currentODBC;

  /** Crea un nuevo pool a la url especificada. Lo almacena
   *  en la lista de pools para poder recuperarlo a partir
   *  del identificador.
   */
  public ODBCConnPool(String id, String driverName, 
                      String url, String user, String password,
                      int limit) 
  throws SQLException { 
      super(id, limit);
      this.id = id;
      this.url = url;
      this.user = user;
      this.password = password;
      this.currentODBC = 0;
      
      Category.getInstance(getClass()).debug("ODBCConnPool: Inicializando.");
      registerDriver(driverName);
      ensureConnections();
      super.getDefaultCache().put(id, this);
  }

  /** Registra el driver SQL. */
  protected void registerDriver(String className) throws SQLException {     
    try {
      Class.forName(className).newInstance();
    }
    catch (Exception e) {
      Category.getInstance(getClass()).warn(e.getMessage());
      throw new SQLException ("ODBCConnPool.registerDriver: " + e);
    }
  }

  /** Se asegura de que en el pool al menos existan CON_NUMBER. */
  protected void ensureConnections() {
     Connection con = null;
     String url = null;

     try {
       Category.getInstance(getClass()).debug("Creando conexiones.");
       while (super.getSize() < super.getLimit()) {
         url = this.getUrl();
         con = DriverManager.getConnection(url, this.user, this.password);
         super.put(con);
       }
       Category.getInstance(getClass()).debug(super.getSize() + " conexiones creadas.");
     }
     catch (SQLException e) {
       Category.getInstance(getClass()).warn(e.getMessage());
       throw new NoSuchElementException(url + " ["+e+"]");
     }
  }

  protected String getUrl() {
    String res;

    res = this.url + this.currentODBC;
    currentODBC = (currentODBC+1) % this.CON_NUMBER;

    return res;
  }

   public synchronized Connection adquire()   { 
     return (Connection) super.get(true);
   }

   /** Libera la conexi�n indicada, volvi�ndola a pasar al pool de 
       conexiones dormidas.
    */
   public synchronized void release(Connection con) {
     try {
       if (getSize() >= CON_NUMBER) {
         if ((con != null) && (con.isClosed() == false)) { 
           Category.getInstance(getClass()).debug("ODBCConnPool: Cerrando conexi�n.");
           con.close();
         }
       }
       else {
         Category.getInstance(getClass()).debug("ODBCConnPool: Empoolando conexi�n.");
         super.put(con);
       }
     }
     catch (SQLException e) {}
   }  

   public static ODBCConnPool getODBCConnPool(String id) {
      ODBCConnPool pool;
    
      pool = (ODBCConnPool) Cache.getCache(id);
     
      return pool;
   }

   /** True si el objeto ya no es �til y en lugar de ser retornado
    * debe eliminarse.
    */
   public boolean hasExpired() {
       return false;
   }
   
   /** Retorna el identificador del objeto, es decir un nombre por
    * el que ser� conocido.
    */
   public Object getIdentifier() {
       return this.id;
   }
   
   /** Ejecutado al ser eliminado de la cach�.  */
   public void destroy() {
       Connection con;
       
       while (super.getSize() > 0) {
           try {
               con = this.adquire();
               con.close();
           }
           catch (SQLException e) {
           }
       }
   }
   
}