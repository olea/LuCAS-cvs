/*
 * ConfigEngineStarterServlet.java
 *
 * Created on 21 de noviembre de 2001, 19:17
 */
 
package com.echiceros.system;           

import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.*;

/** 
 * Lanza el ConfigEngine en la web-app. Deber�a definirse
 * con un load-on-startup de 1.
 *
 * Utiliza el par�metro de inicio <i>configPath</i> para cargar
 * el archivo de configuraci�n. Deber�a ser la ruta relativa
 * con respecto a la carpeta de la aplicaci�n del archivo
 * de configuraci�n (por ejemplo, /WEB-INF/appconf.xml).
 *
 * @author  jv
 * @version 
 */
public class ConfigEngineStarterServlet extends HttpServlet {
   
    /** Initializes the servlet.
    */  
    public void init(ServletConfig config) throws ServletException {
        String filePath;
        String appRoot;
        
        super.init(config);   
        try {
            appRoot = config.getServletContext().getRealPath("/").replace('\\', '/');
            if (appRoot.endsWith("/") == true) {
                appRoot = appRoot.substring(0,appRoot.length()-1);
            }
            filePath = config.getInitParameter("configPath");
            Category.getInstance(getClass().getName()).info("filePath: " + filePath + ".");
            new com.echiceros.system.ConfigEngine(appRoot + filePath);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    /** Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Lanza el ConfigEngine.";
    }

}
