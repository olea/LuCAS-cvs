/*
 * SelectSQLGenerator.java
 *
 * Created on 24 de agosto de 2002, 16:43
 */

package com.echiceros.bd.generator;


import java.util.*;
import com.echiceros.lang.*;

/**
 * Esta clase permite generar de forma autom�tica sentencias
 * select. Para ello basta con especificar qu� campos
 * deseamos recuperar y qu� condiciones deben cumplirse.
 *
 * Escapea los caracteres no validos de manera autom�tica.
 *
 * Si se dispone de la metainformaci�n adecuada realiza
 * por s� misma el join de las tablas.
 *
 * Permite especificar de manera independiente del dialecto
 * sql algunos par�metros adicionales, como por ejemplo 
 * la limitaci�n del n�mero de registros a recuperar.
 *
 * [PENDIENTE] Escapear las condiciones.
 * [PENDIENTE] Fijar limits/tops.
 * [PENDIENTE] groups by, order by, having.
 * [PENDIENTE] joins autom�ticas.
 *
 * @author  jv
 */
public class SQLSelectGenerator {
    
    /** Campos a recuperar en la select. */
    protected Vector fields;
    
    /** Tablas de las que recuperar la informacion. */
    protected Vector tables;
    
    /** Condici�n (posiblemente compuesta) del where. */
    protected Condition condition;
    
    /** Secuencia de ordenamiento. */
    protected String orderBy;
    
    /** Cu�ntos registros se desean recuperar. */
    protected int howMany;
    
    /** Creates a new instance of SelectSQLGenerator */
    public SQLSelectGenerator() {
        super();
        
        this.fields = new Vector();
        this.tables = new Vector();
        this.condition = null;
        this.orderBy = null;
        this.howMany = -1;   // Todos los registros
    }
    
    /** Indexed setter for property fields.
     * @param fieldName nombre del campo a a�adir. Si se utiliza
     *        la sintaxis table.field autom�ticamente la tabla
     *        quedar� a�adida.
     */
    public void addField(String fieldName) {
        FieldName fName;
        FieldName otherFieldName;
        int pos;
        
        fName = new FieldName(fieldName);
        if (fName.getTable() != null) {
            this.addTable(fName.getTable());
        }
        
        pos = this.fields.indexOf(fName);
        if (pos == -1) {
            this.fields.addElement(fName);
        } else {
            otherFieldName = (FieldName) this.fields.elementAt(pos);
            if (otherFieldName.getTable() == null) {
               this.fields.setElementAt(fName, pos);
            }
        }
    }
    
    public void addFields(String fieldNames) {
        String[] fields;
        
        fields = StringTools.split(fieldNames, new String[]{" ", ","});
        for (int i=0; i < fields.length; i++) {
            this.addField(fields[i]);
        }
    }
    
    /** A�ade una tabla a la select si no lo estaba previamente. 
     *  Si el nombre de la tabla contiene un espacio se considera
     *  que la segunda parte es el alias de la misma.
     */
    public void addTable(String tableName) {
        int pos;
        TableName tName;
        TableName otherTableName;
        
        tName = new TableName(tableName);
        pos = tables.indexOf(tName);
        if (pos != -1) {
            otherTableName = (TableName) this.tables.elementAt(pos);
            if (otherTableName.getAlias() == null) {
               this.tables.setElementAt(tName, pos);
            }
        } else {
            this.tables.addElement(tName);
        }
    }
    
    public void addTables(String tablesNames) {
        String[] tables;
        
        tables = StringTools.split(tablesNames, new String[]{","});
        for (int i=0; i < tables.length; i++) {
            this.addTable(tables[i]);
        }
    }
    
    public void setCondition(Condition condition) {
        this.condition = condition;
    }
    
    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }
    
    public void setHowMany(int howMany) {
        this.howMany = howMany;
    }
    
    public String getSentence() {
        StringBuffer sentence;
        FieldName fName;
        TableName tName;
        
        sentence = new StringBuffer();
        
        sentence.append("SELECT ");
        for (int i=0; i < this.fields.size(); i++) {
            fName = (FieldName) fields.elementAt(i);
            sentence.append(fName.getFullName());
            sentence.append(", ");
        }
        sentence.setLength(sentence.length()-2);        
        
        sentence.append(" FROM ");
        for (int i=0; i < this.tables.size(); i++) {
            tName = (TableName) tables.elementAt(i);
            sentence.append(tName.getFullName());
            sentence.append(", ");
        }
        sentence.setLength(sentence.length()-2);
        
        if (this.condition != null) {
            sentence.append(" WHERE ");
            sentence.append(this.condition.getSentence());
        }
        
        if (this.orderBy != null) {
            sentence.append(" ORDER BY " + this.orderBy);
        }
        
        return sentence.toString();
    }
    
    public String toString() {
        return "SelectSQLGenerator (" + this.getSentence() + ")";
    }
    
    static class FieldName {
        String table;
        
        String name;
        
        public FieldName(String name) {
            int pos;
            
            pos = name.indexOf('.');
            if (pos == -1) {
                this.table = null;
                this.name = name.toLowerCase().trim();
            } else {
                this.table = name.substring(0, pos).toLowerCase().trim();
                this.name = name.substring(pos+1).toLowerCase().trim();
            }            
        }
        
        public FieldName(String table, String name) {
            this.table = table.toLowerCase().trim();
            this.name = name.toLowerCase().trim();
        }
        
        public String getTable() {
            return this.table;
        }
        
        public String getName() {
            return this.name;
        }
        
        public String getFullName() {
            String fullName;
            
            if (this.getTable() == null) {
                fullName = this.name;
            } else {
                fullName = this.getTable() + "." + this.getName();
            }
            
            return fullName;
        }
        
        public String toString() {
            return "FieldName (" + this.getFullName() + ")";
        }
        
        public boolean equals(Object obj) {
            boolean isEqual;
            FieldName other;
            
            other = (FieldName) obj;
            
            if (this.getName().equals(other.getName()) == false) {
                isEqual = false;
            } else if ((this.getTable() == null) || (other.getTable() == null)) {
                isEqual = true;
            } else {
                isEqual = this.getTable().equals(other.getTable());
            }
            
            return isEqual;
        }
    }
    
    static class TableName {
        
        /** Holds value of property name. */
        private String name;
        
        /** Holds value of property alias. */
        private String alias;
        
        public TableName(String name) {
            int pos;
            
            pos = name.indexOf(" ");
            if (pos == -1) {
                this.setName(name);
                this.setAlias(null);
            } else {
                this.setName(name.substring(0, pos));
                this.setAlias(name.substring(pos+1));
            }
        }
        
        public TableName(String name, String alias) {
            this.setName(name);
            this.setAlias(alias);
        }
        
        /** Getter for property name.
         * @return Value of property name.
         */
        public String getName() {
            return this.name;
        }
        
        /** Setter for property name.
         * @param name New value of property name.
         */
        public void setName(String name) {
            this.name = (name == null) ? null : name.toLowerCase().trim();
        }
        
        /** Getter for property alias.
         * @return Value of property alias.
         */
        public String getAlias() {
            return this.alias;
        }
        
        /** Setter for property alias.
         * @param alias New value of property alias.
         */
        public void setAlias(String alias) {
            this.alias = (alias == null) ? null : alias.toLowerCase().trim();
        }
        
        public String getFullName() {
            String res;
            
            res = this.getName();
            if (this.getAlias() != null) {
                res = res + " " + this.getAlias();
            }
            
            return res;
        }
        
        public String toString() {
            return "TableName (" + this.getFullName() + ")";
        }
        
        public boolean equals(Object obj) {
            boolean isEqual;
            TableName other;
            
            other = (TableName) obj;
            
            if (this.getName().equals(other.getName()) == false) {
                isEqual = false;  // Los nombres son distintos
            } else if ((this.getAlias() == null) && (other.getAlias() == null)) {
                isEqual = true;   // Nombres iguales y alias nulos
            } else if ((this.getAlias() != null) && (other.getAlias() == null)) {
                isEqual = true;   // Nombres iguals y uno de los alias nulos
            } else if ((this.getAlias() == null) && (other.getAlias() != null)) {
                isEqual = true;   // Nombres iguals y uno de los alias nulos
            } else if (this.getAlias().equals(other.getAlias()) == true) {
                isEqual = true;   // Nombres y alias iguales
            } else {
                isEqual = false;  // Nombres iguales y alias diferentes
            }
            
            return isEqual;
        }
        
    }
    
    static class Condition {
        Condition left;
        Condition right;
        String operator;
        
        String value;
        
        public Condition(String value) {
            this((Condition) null, (String) null, (Condition) null);
            this.value = value;
        }
        
        public Condition(String leftValue, String operator, Condition right) {
            this(new Condition(leftValue), operator, right);
        }
        
        public Condition(Condition left, String operator, String rightValue) {
            this(left, operator, new Condition(rightValue));
        }
        
        public Condition(String leftValue, String operator, String rightValue) {
            this(new Condition(leftValue), operator, new Condition(rightValue));
        }
        
        public Condition(Condition left, String operator, Condition right) {
            this.left = left;
            this.operator = operator;
            this.right = right;
            this.value = null;
        }
        
        public StringBuffer appendSentence(StringBuffer str) {
            if (this.value != null) {
                str.append(" " + this.value + " ");
            } else {
                str.append("(");
                this.left.appendSentence(str);
                str.append(" " + this.operator + " ");
                this.right.appendSentence(str);
                str.append(")");
            }
            
            return str;
        }
        
        public String getSentence() {
            StringBuffer str;
            
            str = new StringBuffer();
            str = this.appendSentence(str);
            
            return str.toString();
        }
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SQLSelectGenerator gen;
        Condition condition;
        
        gen = new SQLSelectGenerator();        
        // campo nuevo. la tabla se a�ade autom�ticamente
        gen.addField("gppftec.nif");
        // lo volvemos a a�adir. ser� ignorado.
        gen.addField("nif");
        // a�adimos un par de campos
        gen.addField("nombre");                         
        gen.addField("apellidos");
        // a�adimos varios campos de una vez
        gen.addFields("direccion, telefono, simpatia");
        // a�adimos una tabla existente (no se repetir�)
        gen.addTable("gppftec");
        // a�adimos varias tablas
        gen.addTables("account, orders");
        // a�adimos la misma tabla con una alias (ser� substitu�da)
        gen.addTable("gppftec ourTecs");
        // a�adimos la misma tabla per con otro alias (dos apariciones)
        gen.addTable("gppftec otherTecs");
        // a�adimos una tabla existente (ser� ignorada en favor del alias)
        gen.addTable("gppftec");
        
        condition = new Condition(
                        new Condition("cargo", "=", "'Almirante'"),
                        "OR",
                        new Condition(
                            new Condition("simpatia", ">", "5"),
                            "AND",
                            new Condition(
                                new Condition("direccion", "IS NOT", "NULL"),
                                "OR",
                                new Condition("telefono", "IS NOT", "NULL"))));
        
        gen.setOrderBy("nombre, apellidos");
        gen.setCondition(condition); 
        
        System.out.println(gen.getSentence());
        System.exit(0);
    }
    
}

