/*
 * TrsConfigLog4j.java
 *
 * Created on 2 de enero de 2002, 00:45
 */

package com.echiceros.bd.trs;


import org.apache.log4j.*;
import org.apache.log4j.xml.*;


/**
 * Lanza el proceso de configuraci�n de Log4j: appenders, layouts...
 * 
 * La definition tiene el siguiente formato:
 *
 *    <data>
 *      <configPath>d:/userinfo/tomcat3/webapps/vincere/web-inf/log4j.ini</configPath>
 *    </data>
 *
 * @author  jv
 * @version 1.0
 */
public class TrsConfigLog4j extends TrsAdapter {

    /** Creates new TrsCreateDataSourceCache */
    public TrsConfigLog4j() {
        super();
    }

    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        String configPath;
        
        configPath = super.definition.getChildTextTrim("configPath");
        DOMConfigurator.configure(configPath);
    }

}
