/*
 * XSLServlet.java
 *
 * Created on 28 de agosto de 2001, 19:30
 */
 
package com.echiceros.www.xsl;           

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import org.apache.log4j.*;
import com.echiceros.www.*;
import com.echiceros.www.tools.*;
/** 
 * Uno de los mecanismos m�s c�modos y transparentes que existen
 * para aplicar xsl a documentos est�ticos consiste en asociar una
 * determinada extensi�n (en nuestro caso, xtp) a un servlet que
 * se encargar� de leer del propio documento el nombre de la xsl
 * a aplicar y de ejecutar la transformaci�n.
 *
 * Si no se proporcionan par�metros al servlet, obtiene el xml
 * a procesar mediante un request.getServletPath(). 
 *
 * Es posible indicar qu� recurso deseamos procesar mediante el
 * par�metro xmlPath.
 *
 * Es posible sobreescribir la xsl a aplicar mediante el par�metro
 * xslPath.
 *
 * Podemos fijar xslPath a <code>deactivated</code> si no deseamos
 * aplicar una xsl.
 *
 * NUEVO: Tanto el xml como la xsl se recuperan mediante http 
 * conservando todos los par�metros de la actual request.
 *
 *
 * @author  jv
 * @version 1.1
 */
public class XSLServlet extends HttpServlet {
   
    /** Initializes the servlet.
    */  
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

    }

    /** Destroys the servlet.
    */  
    public void destroy() {

    }

    /** Abre el archivo a transformar y recupera el path de la xsl
     *  que deseamos aplicar.
     */
    protected Params checkParameters(HttpServletRequest request)
    throws IllegalArgumentException { 
      Params params;
      String xmlPath = null;
      String xslPath = null;
      
      try { 
        params = new Params();
        
        xmlPath = request.getParameter("xmlPath");
        if (xmlPath == null) {
          xmlPath = request.getServletPath();
        }
        if (xmlPath.startsWith("/") == true) {
            xmlPath = ServletTools.getAppURL(request) + xmlPath;
        }
        
        params.xmlSource = new BufferedReader( 
                             new InputStreamReader(
                              this.openStream(xmlPath, request)));

        
        xslPath = request.getParameter("xslPath");
        if (xslPath.startsWith("/") == true) {
            xslPath = ServletTools.getAppURL(request) + xslPath;
        }
        params.xslSource = new BufferedReader( 
                             new InputStreamReader(
                              this.openStream(xslPath, request)));

      }
      catch (IOException e) {
          throw new IllegalArgumentException(
            "XSLServlet.checkParameters(): (" + xmlPath +") - " + e);
      }
      
      return params;
    }

    /** Abre un stream para recuperar la recurso a partir de la url indicada.
     *  A�ade todos los atributos del request.
     *
     *  @param sourceURL url (absoluta, absoluta a app o relativa) a recuperar.
     *  @param request request de la petici�n.
     *
     *  @return Un stream con el recurso accedido.
     */
    protected InputStream openStream(String sourceURL, HttpServletRequest request) 
    throws IOException {
        URLNormalizer norm;
        String urlSpec;
        URL url;
        String path;
        InputStream in;
        Enumeration enum;
        String paramName;
        String paramValue;

        Category.getInstance(getClass().getName()).debug(
           "sourceURL: " + sourceURL);
        // Convertimos la url en absoluta...
        if (sourceURL.startsWith("http://") == true) {
            urlSpec = sourceURL;
            Category.getInstance(getClass().getName()).debug(
               "Obtenida url absoluta: " + urlSpec);
        }
        else if (sourceURL.startsWith("/") == true) {
            urlSpec = ServletTools.getAppURL(request) + sourceURL;
            Category.getInstance(getClass().getName()).debug(
               "Obtenida url absoluta a la aplicaci�n: " + urlSpec);
        }
        else {
            urlSpec = ServletTools.getRequestFolder(request) + sourceURL;
            Category.getInstance(getClass().getName()).debug(
               "Obtenida relativa: " + urlSpec);
        }
        norm = new URLNormalizer(urlSpec, "");
        // A�adimos los par�metros del request
        enum = request.getParameterNames();
        while (enum.hasMoreElements() == true) {
            paramName = (String) enum.nextElement();
            paramValue= request.getParameter(paramName);
            norm.addParam(paramName, paramValue);
        }
        norm.addParam("URLBase", urlSpec);
        Category.getInstance(getClass().getName()).info(
            "Accediendo a URL " + urlSpec + ".");
        urlSpec = norm.getURL();
        url = new URL(urlSpec);
        in = new BufferedInputStream(url.openConnection().getInputStream());
        Category.getInstance(getClass().getName()).info(
            "Accedida con �xito.");
        
        return in;
    }
        
    /** Aplica la xsl al xml. 
     *  @param out el canal de salida de la transformaci�n.
     *  @param xmlReader reader del que obtener el xml.
     *  @param xslReader reader del que obtener la xsl.
     */
    protected void applyXSL(Writer out,
                            BufferedReader xmlReader, 
                            BufferedReader xslReader) 
    throws ServletException {
       TransformerFactory tFactory;
       Transformer transformer;
       
       try {
           tFactory = TransformerFactory.newInstance();
           transformer = tFactory.newTransformer(new StreamSource(xslReader));

           transformer.transform
                (new StreamSource(xmlReader), 
                 new StreamResult(out));

       }
       catch (TransformerConfigurationException e) {
           throw new ServletException("XSLApplyTag.applyXSL(): " + e.getMessage());
       }
       catch (TransformerException e) {
           throw new ServletException("XSLApplyTag.applyXSL(): " + e.getMessage());
       }
    }
    
    /** Vuelca sin transformar el xml. */
    protected void dumpXML(PrintWriter out, BufferedReader in) 
    throws IOException {
        String line;
        
        do {
            line = in.readLine();
            if (line != null) {
              out.println(line);
            }
        } while (line != null);
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        Params params;
        java.io.PrintWriter out;
        
        Category.getInstance(getClass().getName()).info(
          "Iniciando procesamiento."
        );
        out = response.getWriter();
        response.setContentType("text/html");
        // En realidad abre el archivo a transformar.
        // tambi�n averigua el path de la xsl que necesitamos aplicar.
        params = checkParameters(request);
        
        if (params.xslSource != null) {
            this.applyXSL(out, params.xmlSource, params.xslSource);
            params.xslSource.close(); 
        }
        else {
            this.dumpXML(out, params.xmlSource);
        }
        params.xmlSource.close();
        
        Category.getInstance(getClass().getName()).info(
          "Finalizando procesamiento."
        );
    } 

    

    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Permite aplicar una xsl al documento tratado.";
    }

    /** Una forma comoda de almacenar los par�metros. */
    class Params {
        BufferedReader xmlSource = null;
        BufferedReader xslSource = null;
    }
}
