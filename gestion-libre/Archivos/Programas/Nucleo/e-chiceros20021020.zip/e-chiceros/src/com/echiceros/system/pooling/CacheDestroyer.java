/*
 * CacheDestroyer.java
 *
 * Created on 14 de agosto de 2002, 14:35
 */

package com.echiceros.system.pooling;

/**
 *
 * @author  jv
 */

public interface CacheDestroyer {
    public void destroy(Cache cache);
}

