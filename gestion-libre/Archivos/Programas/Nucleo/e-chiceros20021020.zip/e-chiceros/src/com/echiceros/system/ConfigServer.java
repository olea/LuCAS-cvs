/*
 * ConfigServer.java
 *
 * Created on 16 de marzo de 2002, 22:06
 */

package com.echiceros.system;

import java.util.*;
import java.io.*;
import java.net.*;
import org.apache.log4j.*;
import com.echiceros.io.*;

/**
 * Mantiene un conjunto de conexiones capaces de interaccionar con 
 * las propiedades almacenadas en el ConfigEngine, tanto para leer
 * como para escribir informaci�n. Para optimizar la velocidad de
 * respuesta la conexi�n no se cerrar� a cada petici�n.
 *
 * Comandos disponibles: 
 *
 * READ xpath        
 * READ /webapps/vincere/users/ciberado/ip
 *
 *      Recupera un valor de la configuracion, retorn�ndolo por
 *      el canal de salida. La primera l�nea indicar� la longitud
 *      en caracteres de la respuesta, que vendr� a continuaci�n
 *      tal y como esta almacenada. Si no existe la propiedad, 
 *      retornar� 0 como longitud y nada como valor.
 *
 * REMOVE xpath
 * REMOVE /webapps/vincere/users/ciberado
 * 
 *      Elimina un nodo y todos sus hijos. No responde.
 *
 * STORE xpath length
 * STORE /webapps/vincere/users/ciberado/ip 11
 * 192.168.1.1
 *
 *      Almacena el valor indicado. No responde. El segundo par�metro
 *      (length) indica la longitud del valor a es escribir en caracteres.
 *      A continuaci�n se leer�n tantos bytes como indique y se almacenar�n
 *      como valor.
 *
 *
 * [PENDIENTE] �Merece la pena implementar un mecanismo de eventos?
 * [PENDIENTE] �Necesitaremos almacenar informaci�n binaria?
 *
 * @see com.echiceros.www.servlets.RemoteSession
 *
 * @author  jv
 */
public class ConfigServer extends com.echiceros.io.BasicServer {

    /** Creates a new instance of ConfigServer */
    public ConfigServer() {
        super();
    }

    public ConfigServer(String configPath) {
        super(configPath);
    }
    
    /** Deber�a procesar la conexi�n que se indica como par�metro.
     * puede utilizar como base la clase BasicServer.Service.
     */
    protected void newService(Socket sck) {
        new Service(sck);
    }
    
    class Service extends BasicServer.Service {
        
       public Service(Socket sck) {
           super(sck);
       }
       
       public void run() {
           DataInputStream in = null;
           PrintStream out = null;
           String response;
           boolean running;
           
           try {
               Category.getInstance(this.getClass().getName()).info("Nueva petici�n.");
               in = new DataInputStream(sck.getInputStream());
               out = new PrintStream(sck.getOutputStream());
               
               do {
                   running = this.processRequest(in, out);
               } while (running == true);
           }
           catch (IOException e) {
             Category.getInstance(this.getClass().getName()).warn(e); 
           }
           finally {
               Category.getInstance(this.getClass().getName()).debug(
                    "Comunicaci�n cortada." ); 
               if (sck != null) {
                   try { sck.close(); } 
                   catch (IOException e) {
                       Category.getInstance(this.getClass().getName()).warn(e); 
                   }
               }
           }
       }
    
        /** Bloquea en espera de una instrucci�n y la procesa. Admite los
         *  comandos READ, STORE y REMOVE tal y como se explicacan en la doc de la
         *  clase.
         *  @returns false si el stream de entrada ha finalizado.
         */
        protected boolean processRequest(DataInputStream in, PrintStream out) 
        throws IOException {
            String command;
            String xpath;
            String length;
            byte[] buf;
            String line;

            line = in.readLine(); // l�nea con el comando y par�metros
            if ((line != null) && (line.indexOf(' ') != -1)) {
                command = line.substring(0, line.indexOf(' ')).toUpperCase();
                xpath = line.substring(command.length()+1);
                if (command.equals("STORE") == true) {
                    length = line.substring(line.lastIndexOf(' ')+1);
                    xpath = xpath.substring(0, xpath.lastIndexOf(" "));
                    buf = new byte[Integer.parseInt(length)];
                    in.read(buf, 0, buf.length);
                    processSTORE(out, xpath, new String(buf));
                } else if (command.equals("READ") == true) {
                    processREAD(out, xpath);
                } else if (command.equals("REMOVE") == true) {
                    processREMOVE(out, xpath);
                }
            }    
             
            return (line != null);
        }
        
        /** Procesa el comando READ. */
        protected void processREAD(PrintStream out, String xpath) 
        throws IOException {
            String value;
            
            Category.getInstance(this.getClass()).debug("READ " + xpath + ".");
            value = config.getProperty(xpath);
            if (value != null) { 
                out.println(value.length());
                out.write(value.getBytes());
            } else {
                out.println("0");
            }
            out.flush();
        }
        
        /** Procesa el comando REMOVE. */
        protected void processREMOVE(PrintStream out, String xpath) 
        throws IOException {            
            Category.getInstance(this.getClass()).debug("REMOVE " + xpath + ".");
            config.removeProperties(xpath);
        }
        
        /** Procesa el comando STORE. */
        protected void processSTORE(PrintStream out, String xpath, String value) 
        throws IOException {
            Category.getInstance(this.getClass()).debug(
                "STORE " + xpath + "( " + value + ") .");
            config.setProperty(xpath, value);
        }
    }
    
    public static void main(String[] args) throws Exception {
        ConfigServer server;
        com.echiceros.bd.trs.TrsConfigLog4j trs;
        String xml;

        xml =
         "    <data> " +
         "      <configPath>d:/userinfo/tomcat3/webapps/vincere/web-inf/log4jconfig.xml</configPath> " +
         "    </data>";
        trs = new com.echiceros.bd.trs.TrsConfigLog4j();
        trs.setDefinition(xml);
        trs.execute();
        
        System.out.println("Inicializando.");
        server = new ConfigServer();
        System.out.println("Activando.");
        server.setPort(9998);
        server.setStatus(true);
    }
}
