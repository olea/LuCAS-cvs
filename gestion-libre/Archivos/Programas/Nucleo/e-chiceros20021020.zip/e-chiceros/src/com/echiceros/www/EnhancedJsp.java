package com.echiceros.www;
 
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.echiceros.system.*;

public abstract class EnhancedJsp implements HttpJspPage, Servlet {
    
  protected ServletConfig  config;
  
  public String  getServletInfo() { return "Enhanced jsp structure."; }
  public ServletConfig  getServletConfig () {  return  this.config; }
  
  public void jspInit() {}
  public void jspDestroy() {}
  
  public void  init(ServletConfig config) throws ServletException
  {
    this.config = config;  
    jspInit();
  }
  
  public void destroy () { jspDestroy(); }
  
  public void  service(ServletRequest request, ServletResponse response) 
  throws ServletException, java.io.IOException
  { HttpServletRequest httpRequest;
    
    httpRequest = (HttpServletRequest) request;
    
    _jspService ((HttpServletRequest) request, (HttpServletResponse) response);
  }
  
  protected static String getRSessionURL(HttpServletRequest request) {
      String res;
      String appName;
      String url;
      ConfigEngine config;

      config = getConfigEngine(request);
      url = config.getProperty("url");
      
      appName = com.echiceros.www.tools.ServletTools.getAppName(request);      
      res = url + "/webapps/" + appName + "/rsessions/" + getSessionId(request);
      
      return res;
  }
  
  protected static String normalizeXPath(HttpServletRequest request,  
                                      String user, String originalXPath) {
      String res;
      String appName;
      
      if (originalXPath.startsWith("/") == false) {
          appName = com.echiceros.www.tools.ServletTools.getAppName(request);      
          res = "/webapps/" + appName + "/rsessions/" + user + "/" + originalXPath;
      } else {
          res = originalXPath;
      }
      
      return res;
  }
 
  protected static ConfigEngine getConfigEngine(HttpServletRequest request) {
      ConfigEngine config;
      String appName;
      
      appName = com.echiceros.www.tools.ServletTools.getAppName(request);      
      config = ConfigEngine.getInstance("/webapps/" + appName + "/rsessions");
      
      return config;
  }  
  
  protected static ConfigClient getConfigClient(HttpServletRequest request) {
      ConfigEngine config;
      ConfigClient configClient;
      String url;

      config = getConfigEngine(request);
      url = config.getProperty("url");

      configClient = ConfigClient.getInstance(url);
      
      return configClient;
  }
  
  /** Trata de localizar el identificador de las sessi�n primero a partir
   *  del request (getParameter() y luego getRequestSessionId()) 
   *  y si fracasa a partir de la cookie que lo almacena.
   *
   *  @returns el identificador de session o null si no lo ha conseguido.
   */
   protected static String getSessionId(HttpServletRequest request) {
      String id; 
      Cookie[] cookies;
      int idx;
      
      id = request.getParameter("JSESSIONID");
      if (id == null) {
          id = request.getRequestedSessionId();
          if (id == null) {
              cookies = request.getCookies();
              idx = 0; 
              while ((idx < cookies.length) 
                  && (cookies[idx].getName().equals("JSESSIONID") == false)) {
                  idx = idx + 1;
              }
              if (idx <= cookies.length) {
                  id = cookies[idx].getValue();
              } 
          }
      }
      
      return id;
  }
  
  public static String getRemoteAttr(HttpServletRequest request, String xpath) {
      ConfigClient client;
      String id;
      String normalizedXPath;
      String result;
      
      id = getSessionId(request);
      normalizedXPath = normalizeXPath(request, id, xpath);
      client = getConfigClient(request);
      result = client.getProperty(normalizedXPath);
      if (result == null) {
          result = (String) request.getSession().getAttribute(xpath);
      }
      ConfigClient.freeInstance(client);
      
      return result;
  }
  
  public static void setRemoteAttr(HttpServletRequest request, 
                               String xpath, String value) {
      ConfigClient client;                                   
      String id;
      String normalizedXPath;
      
      id = getSessionId(request);
      normalizedXPath = normalizeXPath(request, id, xpath);
      client = getConfigClient(request);
      client.setProperty(normalizedXPath, value);
      ConfigClient.freeInstance(client);
  }
   
  public static void removeRemoteAttr(HttpServletRequest request, String xpath) {
      ConfigClient client;
      String id;
      String normalizedXPath;
      
      id = getSessionId(request);
      normalizedXPath = normalizeXPath(request, id, xpath);
      client = getConfigClient(request);
      client.removeProperty(normalizedXPath);
      ConfigClient.freeInstance(client);
  }
  
}
