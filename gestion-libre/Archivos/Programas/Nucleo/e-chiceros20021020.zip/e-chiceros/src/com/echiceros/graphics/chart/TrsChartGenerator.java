/*
 * ChartGenerator.java
 *
 * Created on 6 de febrero de 2002, 12:09
 */

package com.echiceros.graphics.chart;

import java.util.*;
import org.jdom.*;
import net.jmge.gif.Gif89Encoder;
import com.echiceros.bd.trs.*;

/**
 *
 * Cr�ditos para J. M. G. Elliott por su magn�fico paquete de tratamiento
 * de gifs.
 *
 * Dada una definici�n xml del gr�fico a generar
 * crear� una imagen con el mismo.
 *
 *     <chart style="Bar" labels="true" width="400" height="400">
 *        <axe name="a�o" type="alpha" direction="z">
 *           <values>2001, 2002</values>
 *        </axe>
 *        <axe name="mes" type="alpha" direction="x">
 *           <values>Enero, Febrero, Marzo, Abril, Mayo, Junio</values>
 *        </axe>
 *        <axe name="valor" type="numeric" direction="y">
 *           <min>0</min>
 *           <max>50</max>
 *           <step>10</step>
 *        </axe>
 *
 *        <point>Enero, 10, 2001</point>
 *        <point>Febrero, 50, 2001</point>
 *        <point>Mayo, 40, 2001</point>
 *        <point>Enero, 30, 2002</point>
 *        <point>Marzo, 10, 2002</point>
 *
 *     </chart>
 *
 * @author  jv
 */
public class TrsChartGenerator extends com.echiceros.bd.trs.TrsAdapter {

    ImageChart chart;
    
    /** Creates a new instance of ChartGenerator */
    public TrsChartGenerator() {
        super();
    }

    protected void createChart() {
        String width, height;
        
        width = definition.getChild("chart").getAttributeValue("width");
        height = definition.getChild("chart").getAttributeValue("height");
        this.chart = new ImageChart();
        this.chart.setWidth(Integer.parseInt(width));
        this.chart.setHeight(Integer.parseInt(height));
    }
    
    protected void createAxes() {
        List xmlAxes;
        
        xmlAxes = definition.getChild("chart").getChildren("axe");
        if (xmlAxes.size() > 0) {
            createExplicitAxes(xmlAxes.iterator());
        } else {
            createImplicitAxes();
        }
    }
    
    /** Crea los ejes a partir de la definici�n de los mismos. */
    protected void createExplicitAxes(Iterator axes) {
        Element current;
        String name;
        int direction;
        
        while (axes.hasNext() == true) {
            current = (Element) axes.next();
            name = current.getAttributeValue("name");
            if (current.getAttributeValue("direction").charAt(0) == 'x') {
                direction = Axe.X;
            } else if (current.getAttributeValue("direction").charAt(0) == 'y') {
                direction = Axe.Y;
            } else if (current.getAttributeValue("direction").charAt(0) == 'z') {
                direction = Axe.Z;
            } else {
                direction = -1;
            }
            if (current.getAttributeValue("type").equals("numeric")) {
                createNumericAxe(name, direction, current);
            }
            else if (current.getAttributeValue("type").equals("alpha")) {
                createAlphaAxe(name, direction, current);
            }
        }
    }
    
    /** Adivina los ejes de coordenadas a utilizar a partir de los puntos. 
     *  NOTA: utiliza chart.getPoints(), por lo que debe invocarse despu�s
     *        de this.setPoints().
     */
    protected void createImplicitAxes() {
        ChartPoint[] points;

        points = chart.getPoints();
        createImplicitAxe(points, Axe.X);
        createImplicitAxe(points, Axe.Y);
        if (points[0].getZ().toString().length() > 0) {
            createImplicitAxe(points, Axe.Z);
        }
    }
    
    /** Crea el eje de coordenadas indicado a partir de la info impl�cita. 
     *
     *  @param int direction X, Y o Z.
     */
    protected void createImplicitAxe(ChartPoint[] points, int direction) {
        String currentValue;
        boolean alpha;
        int idx;
        
        currentValue = points[0].get(direction).toString();
        
        alpha = false;
        try { Double.parseDouble(currentValue); }
        catch (NumberFormatException e) { alpha = true; }
         
        if (alpha == true) {
            this.createImplicitAlphaAxe(points, direction);
        } else {
            this.createImplicitNumericAxe(points, direction);
        }
    }
    
    /** Crea un eje alfanum�rico a partir de la lista de puntos indicada. 
     *  Para conseguirlo recupera los valores del eje indicado. Mantiene
     *  el orden en el que se indican.
     */
    protected void createImplicitAlphaAxe(ChartPoint[] points, int direction) {
        Vector values;
        
        // Crea un vector con las diferentes coordenadas alphanum�ricas
        values = new Vector();
        for (int i=0; i < points.length; i++) {
            values.removeElement(points[i].get(direction));
            values.addElement(points[i].get(direction));
        }
        
        chart.setAxeAlpha("", direction, values.toArray());
    }

    /** Crea un eje num�rico a partir de la lista de puntos indicada. 
     */
    protected void createImplicitNumericAxe(ChartPoint[] points, int direction) {
        double min, max, step;
        double current;
        
        min = Double.MAX_VALUE;
        max = Double.MIN_VALUE;
        for (int i=0; i < points.length; i++) {
            current = Double.parseDouble(points[i].get(direction).toString());
            if (current < min) {
                min = current;
            }
            if (current > max) {
                max = current;
            }
        }
        min = (min > 0) ? 0 : min;
        step = (max - min) / 5;
        step = (step <= 0.001) ? 1 : step;
        
        chart.setAxeNumeric("", direction, min, max, step);        
    }
    
    protected void createAlphaAxe(String name, int direction, Element current) {
        StringTokenizer tkValues;
        Vector values;
        
        tkValues = new StringTokenizer(current.getChildTextTrim("values"), ", ");
        values = new Vector();
        while (tkValues.hasMoreTokens() == true) {
            values.addElement(tkValues.nextToken());
        }
        chart.setAxeAlpha(name, direction, values.toArray());
    }
    
    protected void createNumericAxe(String name, int direction, Element current) {
        double min, max, step;
        
        min  = Double.parseDouble(current.getChildTextTrim("min"));
        max  = Double.parseDouble(current.getChildTextTrim("max"));
        step = Double.parseDouble(current.getChildTextTrim("step"));
        chart.setAxeNumeric(name, direction, min, max, step);
    }
    
    protected void setPoints() {
        Iterator points;
        Element current;
        StringTokenizer tk;
        String x,y,z;
        Comparable xx, yy, zz;
        
        points = definition.getChild("chart").getChildren("point").iterator();
        while (points.hasNext() == true) {
            current = (Element) points.next();
            tk = new StringTokenizer(current.getTextTrim(), ",");
            x = tk.nextToken().trim();
            y = tk.nextToken().trim();
            z = (tk.hasMoreTokens() == true) ? tk.nextToken().trim() : "";

            try { xx  = new Double(Double.parseDouble(x)); }
            catch (NumberFormatException e) { xx = x; }
            try { yy  = new Double(Double.parseDouble(y)); }
            catch (NumberFormatException e) { yy = y; }
            try { zz  = new Double(Double.parseDouble(z)); }
            catch (NumberFormatException e) { zz = z; }

            chart.addPoint(xx, yy, zz);
        }
    }
    
    protected void setPlotter() {
        Element chartElem;
        String type;
        Plotter plotter;
        boolean values;
        
        chartElem = definition.getChild("chart");
        type = chartElem.getAttributeValue("style");
        values = chartElem.getAttributeValue("labels").equalsIgnoreCase("true");
        if (type.equalsIgnoreCase("bar") == true) {
            plotter = new PlotterBar(values);
        } else if (type.equalsIgnoreCase("line") == true) {
            plotter = new PlotterLine(values);
        } else {
            plotter = new PlotterPoint(values);
        }
        
        chart.setPlotter(plotter);
    }
    
    protected void writeGif() throws TrsException {
        Gif89Encoder gifenc;
     
        try {
            gifenc = new Gif89Encoder();
            gifenc.addFrame(chart.getImage());
            gifenc.setComments("Escrito con E-CHICEROS. www.e-chiceros.com.");
            gifenc.setLoopCount(1);
            gifenc.encode(out);
        }
        catch (java.io.IOException e) {
            throw new TrsException(getClass().getName() + ": " + e.getMessage());
        }
    }
    
    /** Ejecuta la transacci�n.   */
    public void execute() throws TrsException {
        this.createChart();
        this.setPoints();
        this.createAxes();
        this.setPlotter();
        this.chart.createImage();
        this.writeGif();
    }
    
    public static void main(String[] args) throws Exception {
        TrsChartGenerator trs;
        String xml;
        java.io.FileOutputStream out;
        /*
        xml = 
             "<chart style=\"bar\" labels=\"true\" width=\"400\" height=\"250\">"+
             "   <point>Enero, 100, (2001)</point>"+
             "   <point>Febrero, 50, (2002)</point>"+
             "   <point>Febrero, 20, (2001)</point>"+
             "   <point>Marzo, 0, (2002)</point>"+
             "   <point>Mayo, 0, (2001)</point>"+
             "</chart>";
        */
        xml = 
             "<chart style=\"bar\" labels=\"true\" width=\"400\" height=\"250\">"+
             "   <point>Enero, 100</point>"+
             "   <point>Febrero, 20</point>"+
             "   <point>Marzo, 10</point>"+
             "   <point>Mayo, 0</point>"+
             "</chart>";
        
        out = new java.io.FileOutputStream("d:/wop.gif");
        trs = new TrsChartGenerator();
        trs.setDefinition(xml);
        trs.setOut(new java.io.PrintStream(out));
        trs.execute();
        out.close();
    }
    
}
