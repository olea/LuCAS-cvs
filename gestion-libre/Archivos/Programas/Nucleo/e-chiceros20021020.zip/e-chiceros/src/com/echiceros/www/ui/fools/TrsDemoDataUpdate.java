/*
 * TrsDemoDataUpdate.java
 *
 * Created on 11 de enero de 2002, 13:06
 */

package com.echiceros.www.ui.fools;

import com.echiceros.bd.trs.TrsXMLUpdate;

/**
 *
 * Testea la actualizaci�n de datos
 *
 * @author  jv
 */
public class TrsDemoDataUpdate extends TrsXMLUpdate {

    /** Creates a new instance of TrsDemoDataUpdate */
    public TrsDemoDataUpdate() {
        super();
        this.setDefaultTableName("fca005");
        this.setDefaultCacheName("mainDataSource");
        this.addMapping("radical", "fca005.fcraci");
        this.addMapping("fecha", "fca005.fcdtev");
        this.addMapping("cliente", "fca005.fcnomc");
    }

}
