/*
 * TextConsumer.java
 *
 * Created on 3 de agosto de 2001, 16:48
 */

package com.echiceros.regexp;

import java.util.*;

import org.apache.oro.text.regex.*;

/**
 * Se alimenta de cadenas de texto, les aplica una b�squeda regexp
 * y ejecuta el m�todo matching de los listeners correspondientes.
 * Funciona en su propio thread, por lo que no interrumpe el flujo
 * de la aplicaci�n.
 *
 * @author  jv
 * @version 
 */
public class TextConsumer implements Runnable, java.io.Serializable {
    /** Mantiene el thread del consumidor. Null indicar� que deben
     *  liberarse los recursos.
     */
    Thread runner;
    /** Listeners interesados en recibir el evento de matching. */
    Vector listeners;
    /** Textos que nos han pedido analizar. */
    Vector texts;
    /** Matcher utilizado para aplicar el patr�n. */
    Matcher matcher;
    
    /** Creates new TextConsumer */
    public TextConsumer(String pattern) throws MalformedPatternException {
        matcher = new Matcher(pattern);
        this.listeners = new Vector();
        this.texts = new Vector();
        runner = new Thread(this);
        runner.start();
    }
    
    /** Agrega un nuevo listener. */
    public void addREListener(REListener ls) {
      listeners.addElement(ls);
    }
    
    /** Agrega un nuevo elemento para su matching. */
    public void putText(String text) {
      this.texts.addElement(text);
      notifyAll();
    }
    
    /** Espera a que existan textos disponibles y los procesa. */
    public void run() {
        while (runner != null) {
          while ((runner != null) && (texts.size() == 0)) {
              try { wait(5000); }
              catch (InterruptedException e) {}
          }
          while (texts.size() > 0) {
              testMatching((String) texts.remove(0));
          }
        }
    }
    
    /** Procesa el texto indicado, lanzando si es necesario el
     *  evento a los listeners registrados. El m�todo encargado
     *  de responder al evento debe ser eficiente, porque se 
     *  ejecuta en principio en el mismo thread que el consumer.
     */
    protected void testMatching(String text) {
       MatchResult result;
       REListener ls;
       
       matcher.setText(text);
       result = matcher.next();
       if (result.groups() != 0) {
         for (int i=0; i < listeners.size(); i++) {
            ls = (REListener) this.listeners.elementAt(i);
            ls.matchPerformed(text, result);
         }
       }
    }
    
    public interface REListener {
        
       public void matchPerformed(String text, MatchResult result);
       
    }
    
}