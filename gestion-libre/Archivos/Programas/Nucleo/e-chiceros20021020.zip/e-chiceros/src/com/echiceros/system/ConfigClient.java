/*
 * ConfigClient.java
 *
 * Created on 18 de marzo de 2002, 12:44
 */

package com.echiceros.system;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.http.*;
import org.apache.log4j.*;
import com.echiceros.system.*;
import com.echiceros.system.pooling.*;

/**
 * Permite administrar de forma c�moda sesiones remotas basadas
 * en ConfigServer. 
 * 
 * Las instancias de esta clase se obtienen y liberan a trav�s
 * de sendos objetos est�ticos con el el objetivo de facilitar
 * su reutilizaci�n.
 *
 * [PENDIENTE] [PRIORITARIO] implementar dicha reutilizaci�n.
 *
 * @author  jv
 */
public class ConfigClient implements com.echiceros.system.pooling.Cacheable {
    /** Conexi�n con el servidor remoto. */
    Socket sck;
    /** PrintStream hacia el servidor. */
    PrintStream out;
    /** Reader desde el servidor. */
    DataInputStream in;
    /** Timestamp del �ltimo acceso registrado. */
    long lastAccessed;
    
    /** Creates a new instance of ConfigClient.
     *  
     *  @param url especifica la conexi�n a realizar (//host:port).
     *  @throws IOException si no ha podido conectarse al server.
     */
    protected ConfigClient(String url) throws IOException {
        String host;
        int port;
        
        host = url.substring(2, url.indexOf(':'));
        port = Integer.parseInt(url.substring(2 + host.length() + 1));
        
        this.connect(host, port);
    }
    
    /** Crea una nueva instancia del cliente.
     *  @param host ip de la m�quina que ejecuta el ConfigServer.
     *  @param port puerto del servicio ConfigServer.
     */
    protected ConfigClient(String host, int port) throws IOException {
        super();
        this.connect(host, port);
    }
    
    /** Conecta con el server. 
     *  @param host ip de la m�quina que ejecuta el ConfigServer.
     *  @param port puerto del servicio ConfigServer.
     */
    protected void connect(String host, int port) throws IOException {
        ConfigEngine config;
        
        Category.getInstance(getClass()).info(
           "Conectando a " + host + ":" + port + ".");
        this.sck = new Socket(host, port);
        this.in = new DataInputStream(sck.getInputStream());
        this.out= new PrintStream(sck.getOutputStream());
        this.lastAccessed = new Date().getTime();
    }

    /** Cierra la conexion. */
    public void close() {
        try {
           sck.close();
        }
        catch (IOException e) {
            Category.getInstance(getClass()).warn(e.getMessage());
        }
    }
        
    /** 
     * Almacena el valor de una propiedad. 
     */
    public void setProperty(String xpath, String value) {
        this.lastAccessed = new Date().getTime();
        out.println("STORE " + xpath + " " + value.length());
        out.print(value);
    }
    
    /** 
     * Recupera el valor una propiedad. 
     * @returns El valor de la propiedad o null ssi se ha producido error.
     */
    public String getProperty(String xpath) {
        String value;
        int length;
        byte[] buf;

        try { 
            this.lastAccessed = new Date().getTime();
            out.println("READ " + xpath);
            length = Integer.parseInt(in.readLine());
            if (length != 0) {
                buf = new byte[length];
                in.read(buf);
                value = new String(buf);
            } else {
                value = null;
            }
        }
        catch (IOException e) {
            value = null;
            Category.getInstance(getClass()).error(e.getMessage());
        }
        
        return (value==null) ? null : value;
    }
    
    /** 
     * Recupera el valor una propiedad como un entero.  
     * @returns El valor de la propiedad o MIN_VALUE ssi se ha producido error.
     */
    public int getIntProperty(String xpath) {
        String value;
        
        value = this.getProperty(xpath);
        
        return (value == null) ? Integer.MIN_VALUE : Integer.parseInt(value);
    }    
    
    /** 
     * Elimina las propiedades indicadas.
     */
    public void removeProperty(String xpath) {
        this.lastAccessed = new Date().getTime();
        out.println("REMOVE " + xpath);
        out.println("\r\n.");
    }

    /** �til para fijar una propiedad si no se desea mantener
     *  una conexi�n exclusiva permantente. 
     * 
     *  @param url nombre completo (//host:port/xpath) de la
     *         propiedad.
     *  @param value valor que queremos fijarle.
     *
     */
    public static void setPropertyByURL(String url, String value) {
        ConfigClient client;
        String xpath;
        int slashPos;

        client = getInstance(url);
        slashPos = (url.indexOf('/', 3) == -1) ? url.length() : url.indexOf('/', 3);
        xpath = url.substring(slashPos);
        
        client.setProperty(xpath, value);
        client.freeInstance(client);
    }
    
    
    /** �til para consultar una propiedad si no se desea mantener
     *  una conexi�n exclusiva permantente. 
     * 
     *  @param url nombre completo (//host:port/xpath) de la
     *         propiedad.
     *
     */
    public static String getPropertyByURL(String url) {
        String value;
        ConfigClient client;
        String xpath;
        int slashPos;

        client = getInstance(url);
        slashPos = (url.indexOf('/', 3) == -1) ? url.length() : url.indexOf('/', 3);
        xpath = url.substring(slashPos);
        
        value = client.getProperty(xpath);
        client.freeInstance(client);
        
        return value;
    }
    
    /** Retorna una instancia de ConfigClient.
     *
     *  @param url nombre completo (//host:port/xpath) al que conectar .
     */
    public static ConfigClient getInstance(String url) {
        ConfigClient client = null;
        String host = null;
        String port = null;
        String xpath;
        int slashPos;
        
        try {
            host = url.substring(2, url.indexOf(':'));
            slashPos = (url.indexOf('/', 3) == -1) ? 
                       url.length() : url.indexOf('/', 3);
            port = url.substring(url.indexOf(":") + 1, slashPos);

            client = new ConfigClient(host, Integer.parseInt(port));
        }
        catch (IOException e) {
            Category.getInstance("com.echiceros.www.servlets.ConfigClient").error(
              "Imposible crear sesi�n remota (" + host + ":" + port + "): " + 
              e.getMessage() + ".");
        }
        
        return client;
    }
    
    /** Indica la liberaci�n de un cliente. */
    public static void freeInstance(ConfigClient client) {
        client.close();
    }

    /** Coloca el client de nuevo en el pool. */
    public void free() {
        Cache cache;
        
        cache = Cache.createCache("ConfigClient");
        cache.put(this);        
    }
    
    /** True si el objeto ya no es �til y en lugar de ser retornado
     * debe eliminarse.
     */
    public boolean hasExpired() {
        return false;
    }
    
    /** Retorna el identificador del objeto, es decir un nombre por
     * el que ser� conocido.
     */
    public Object getIdentifier() {
        return this;
    }
    
    /** Ejecutado al ser eliminado de la cach�.  */
    public void destroy() {
        this.close();
    }
    
    public static void main(String[] args) throws Exception {
        ConfigClient session;
        String path;
        
        path = "d:/userinfo/tomcat3/webapps/vincere/web-inf/webserver.xml";

        System.out.println("Creando engine.");
        new ConfigEngine(path);
        System.out.println("Creando session.");
        session = new ConfigClient("/webapps/vincere/rsessions");
        System.out.println("Fijando wop.");
        session.setProperty("wop", "Hola Mundo!");
        System.out.println("Recuperando wop.");
        System.out.println("[" + session.getProperty("wop") + "]");
        System.out.println("Eliminando wop.");
        session.removeProperty("wop");
        System.out.println("Recuperando wop.");
        System.out.println("[" + session.getProperty("wop") + "]");
        System.exit(0);
    }
    
    
}
