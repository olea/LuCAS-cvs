/*
 * IdGenerator.java
 *
 * Created on 1 de abril de 2002, 17:00
 */

package com.echiceros.bd.trs.idgen;

/**
 *  Abstracci�n de las clases encargadas de generar identificadores �nicos.
 */
public interface IdGenerator {
    
     /** Retorna un identificador nuevo y �nico para la clave correspondiente. */
     String getIdentifier(String key);
}
