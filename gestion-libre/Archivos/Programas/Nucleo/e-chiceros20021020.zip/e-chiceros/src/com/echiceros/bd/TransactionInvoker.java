/*
 * TransactionInvoker.java
 *
 * Created on 23 de septiembre de 2002, 16:35
 */

package com.echiceros.bd;

import java.util.*;
import java.io.*;
import java.net.*;

import org.jdom.*;
import org.jdom.input.*;
import org.apache.log4j.*;

import com.echiceros.system.*;
import com.echiceros.bd.trs.TrsException;

/**
 *
 * Permite invocar transacciones program�ticamente de una
 * manera c�moda. L�gica es similar a la de TransactionServlet
 * pero sin los elementos propios de una conexi�n http.
 *
 *    TransactionInvoker inv;
 *    String xmlRes;
 *
 *    inv = new TransactionInvoker();
 *    inv.setName("java:com.echiceros.bd.trs.TrsCreateDataSourceCache");
 *    inv.addParam("name", "mainDataSource");
 *    inv.addParam("limit", 20);
 *    inv.addParam("class", "org.gjt.mm.mysql.Driver");
 *    inv.addParam("url", "jdbc:mysql://127.0.0.1/vincere");
 *    xmlRes = inv.execute();
 *
 * @author  jv
 */
public class TransactionInvoker {
    
    /** Nombre de la transacci�n a invocar. */
    String name;
    
    /** Par�metros de la invocaci�n. */
    Vector params;
    
    /** Resultado de la respuesta, si es xml. */
    Element results;
    
    /** Creates a new instance of TransactionInvoker */
    public TransactionInvoker() {
        super();
        
        this.params = new Vector();
    }
    
    /** Ejecuta la transacci�n en el Gestor correspondiente
     *  y retorna el resultado.
     */
    public String execute() throws TrsException {
        String xmlQuery;        
        String res;
        ConfigEngine configEngine;
        String host;
        int port;
        
        xmlQuery = this.createXmlQuery();
        configEngine = ConfigEngine.getInstance();
        
        host = configEngine.getProperty("transactionEngine/host");
        port = configEngine.getIntProperty("transactionEngine/port");
        
        Category.getInstance(getClass()).debug(
                     "TrsEngine >> host: " + host + ", port: " + port);
        
        res = executeImp(host, port, xmlQuery);
            
        return res;
    }
    
    protected String executeImp(String host, int port, String xmlQuery)
    throws TrsException {
        String res = null;
        StringBuffer read;
        Socket sck;
        DataInputStream in;
        PrintStream out;
        byte[] buffer;
        int len;
        
        try {
            sck = new Socket(host, port);
            in = new DataInputStream(sck.getInputStream());
            out = new PrintStream(sck.getOutputStream());
            out.println(xmlQuery);
            out.println("\n");
            out.flush();
            read = new StringBuffer();
            buffer = new byte[1024*2];
            do {
                len = in.read(buffer);
                if (len > 0)  {
                    read.append(new String(buffer, 0, len)); 
                    read.append("\n");
                }
            } while (len > 0);

            sck.close();
            res = read.toString();
            updateResults(res);
        } catch (IOException e) {
            Category.getInstance(getClass()).warn(e.getMessage());
            throw new TrsException(e.getMessage());
        }        
        
        return res.toString();
    }
    
    protected void updateResults(String xml) {
        Document doc;
        SAXBuilder builder;
        
        try {
            builder = new SAXBuilder();
            doc = builder.build(new StringReader(xml));
            this.results = doc.getRootElement();
        } catch(JDOMException e) {
            Category.getInstance(getClass()).debug(e.getMessage());
            // Ignorada debido a que la respuesta no tiene por qu�
            // ser xml.
        }
    }
    
    /** Retorna el contenido del primer child de this.results cuyo 
     *  nombre de elemento coincide con el del par�metro indicado
     *  o null si no existe.
     */
    public String getResultValue(String name) {
        String res;
        
        res = this.results.getChildTextTrim(name);
        
        return res;
    }
    
    /** Retorna todos los resultados con el nombre indicado
     *  en el par�metro.
     */
    public String[] getResultValues(String name) {
        Vector result;
        Iterator iter;
        Element current;
        
        result = new Vector();
        iter = this.results.getChildren(name).iterator();
        while (iter.hasNext() == true) {
            current = (Element) iter.next();
            result.addElement(current.getTextTrim());
        }
        
        return (String[]) (result.toArray(new String[0]));
    }
    
    /** @returns El elemento jdom con los resultados, si esta
     *           disponible. Este m�todo se deprecar� en el
     *           momento en el que a�adamos el soporte de xpath
     *           a jdom.
     */
    public Element getResultDefinition() {
        return this.results;
    }
    
    /** Genera la cadena xml necesaria para invocar la
     *  transacci�n.
     */
    protected String createXmlQuery() {
        StringBuffer query;
        Enumeration paramEnum;
        Param currentParam;
        
        query = new StringBuffer();
        query.append("<requestService>" + "\r\n");
        query.append("  <name>" + this.getName() + "</name>" +  "\r\n");
        query.append("     <data>" +  "\r\n");
        
        paramEnum = this.params.elements();
        while (paramEnum.hasMoreElements() == true) {
            currentParam = (Param) paramEnum.nextElement();
            query.append("<" + currentParam.getName() + ">" + 
                         "<![CDATA[" + 
                            currentParam.getValue() +
                         "]]>" +
                         "</" + currentParam.getName() + ">" + "\r\n");
        }
        
        query.append("     </data>" +  "\r\n");
        query.append("</requestService>" + "\r\n");
        
        return query.toString();
    }
    
    /** Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return this.name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /** A�ade un par�metro en el nombre y el valor indicados. */
    public void addParam(String name, int value) {
        this.addParam(name, String.valueOf(value));
    }
    
    /** A�ade un par�metro en el nombre y el valor indicados. */
    public void addParam(String name, double value) {
        this.addParam(name, String.valueOf(value));
    }
    
    /** A�ade un par�metro en el nombre y el valor indicados. */
    public void addParam(String name, String value) {
        Param param;
        
        param = new Param(name, value);
        this.params.addElement(param);
    }
    
    class Param extends Object {
        
        /** Holds value of property name. */
        private String name;
        
        /** Holds value of property value. */
        private String value;
        
        public Param() {
            super();
        }
        
        public Param(String name, String value) {
            super();
            this.setName(name);
            this.setValue(value);
        }
        
        /** Getter for property name.
         * @return Value of property name.
         *
         */
        public String getName() {
            return this.name;
        }
        
        /** Setter for property name.
         * @param name New value of property name.
         *
         */
        public void setName(String name) {
            this.name = name;
        }
        
        /** Getter for property value.
         * @return Value of property value.
         *
         */
        public String getValue() {
            return this.value;
        }
        
        /** Setter for property value.
         * @param value New value of property value.
         *
         */
        public void setValue(String value) {
            this.value = value;
        }
        
    }
    
    public static void main(String[] args) throws Exception {
         TransactionInvoker inv;
         String xmlRes;
     
         BasicConfigurator.configure();         
         
         ConfigEngine.getInstance().setProperty("transactionEngine/host", 
                                                "127.0.0.1");
         ConfigEngine.getInstance().setProperty("transactionEngine/port", 
                                                9000);
         
         inv = new TransactionInvoker();
         inv.setName("java:com.echiceros.bd.trs.TrsEcho");
         inv.addParam("message", "Hola Mundo Distribu�do!!");
         xmlRes = inv.execute();
         
         System.out.println(xmlRes);
    }
}
