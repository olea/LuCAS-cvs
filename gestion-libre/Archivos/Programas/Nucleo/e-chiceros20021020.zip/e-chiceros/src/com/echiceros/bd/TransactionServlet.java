/*
 * TransactionServlet.java
 *
 * Created on 7 de octubre de 2001, 18:47
 */
 
package com.echiceros.bd;           

import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.log4j.*;
import com.echiceros.lang.*;
import com.echiceros.system.ConfigEngine;
import com.echiceros.www.*;
import com.echiceros.www.tools.*;

/** 
 * Este servlet recibe como par�metro un documento xml del que obtendr�
 * la informaci�n necesaria para pedir la ejecuci�n de una transacci�n.
 *
 * Si se le indica una <i>destination</i> se proceder� a 
 * conectar con el motor de transacciones y redireccionar hacia
 * el valor del destination, guardando en el request el resultado
 * de la transacci�n como atributo transactionResponse. 
 *
 * En el caso de que no se indique <i>destination</i> el resultado
 * se enviar� por el canal de salida del servlet (�til si deseamos
 * realizar un include del mismo).
 *
 * La localizaci�n del transaction engine se realiza fijando el
 * valor de las variables transactionEngine.ip y transactionEngine.port
 * en el ConfigEngine.
 * 
 * El servlet espera un parametro xml con la siguiente informaci�n:
 *
 *   <requestService>
 *     <name>TestTransaction</name>
 *     <destination>showresults.jsp</destination>
 *     <mime>text/html</mime>
 *     <data>
 *        <username> <from-session name="username"/></username>
 *        <record table="customer">
 *           <field name="id" value="A3423K" />
 *           <field name="address" value="Rovellat 5" />
 *        </record>
 *        <record table="customer">
 *           <field name="id" value="3C42AK" />
 *           <field name="address" value="Alegr�a 3" />
 *        </record>
 *     </data>
 *   </requestService> 
 *
 *   El elemento name indica qu� transacci�n deseamos ejecutar.
 *
 *   Destination representa la url a la que se redireccionara el 
 *   servlet cuando haya finalizado la ejecuci�n. Recibir� como
 *   atributo del request el resultado de la transacci�n (en
 *   transactionResponse). Si no se especifica la respuesta de
 *   la transacci�n se volcar� directamente en el stream de
 *   salida del servlet.
 *
 *   El elemento mime indica qu� tipo de respuesta se enviara al browser.
 *   si no se especifica se toma por defecto text/html.
 *
 *   El elemento data contendr� la informaci�n que necesita la
 *   transacci�n para procesarse. En ocasiones ser� conveniente
 *   recuperar en el propio servlet la informaci�n para que no
 *   aparezca en el c�digo del cliente. En tales casos se puede
 *   especificar mediante un elemento <from-session/>.
 *
 *   Los par�metros transaction/host y transaction/port indican
 *   la localizaci�n exacta del transactionengine. se encontraran
 *   por debajo del contexto de configuraci�n que indique el par�metro
 *   configRoot del servlet.   
 *
 * @author  jv
 * @version 1.1
 */
public class TransactionServlet extends HttpServlet {
   
    /** Initializes the servlet.
    */  
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    /** Destroys the servlet.
    */  
    public void destroy() {

    }
    
    protected Params checkParameters(HttpServletRequest request) {
        Params params;
        
        params = new Params();
        if (request.getParameter("xml") == null) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " +  "xml is a mandatory parameter.");
        }
        params.xml = processRequestXML(request, request.getParameter("xml"));
        if (params.xml.indexOf("<name>") == -1) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " +  "element name is mandatory");
        }
        if (params.xml.indexOf("<data>") == -1) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " +  "element data is mandatory");
        }
        params.mime = this.getMimeType(params.xml);
        
        return params;
    }

    /** Transforma el par�metro de entrada. Actualmente sustituye los
     *  elementos <from-session.../> con sus valores reales.
     */
    protected String processRequestXML(HttpServletRequest request, String xml) {
        StringBuffer res;
        int pos0, posf;
        String fromSession;
        String name;
        
        res = new StringBuffer();
        posf = -1;
        do {
            pos0 = xml.indexOf("<from-session", posf+1);
            if (pos0 != -1) {
                res.append(xml.substring(posf+1, pos0));
                posf = xml.indexOf(">", pos0+1);
                fromSession = xml.substring(pos0, posf+1);
                name = StringTools.extract(fromSession, "name=\"", "\"");
                if (request.getSession().getAttribute(name) != null) {
                    res.append(request.getSession().getAttribute(name).toString());
                } else {
                    res.append(EnhancedJsp.getRemoteAttr(request, name));
                }
            }
        } while (pos0 != -1);
        res.append(xml.substring((posf==-1) ? 0 : posf+1));
        
        Category.getInstance(getClass()).debug(res.toString());
        return res.toString();
    }
    
    /** Extrae del par�metro proporcionado el valor del elemento mime.
     *  @param xml Documento con la informaci�n de invocaci�n del 
     *             servicio.
     *  @returns El valor del elemento mime o text/html si no se encuentra.
     */
    protected String getMimeType(String xml) {
        String res;
        
        if  ((xml.indexOf("<mime>") != -1) &&
             (xml.indexOf("<mime>") < xml.indexOf("<data>"))) {
            res = StringTools.extract(xml, "<mime>", "</mime>");
        } else {
            res = null;
        }
        
        Category.getInstance(getClass()).debug("MIME/TYPE: [" + res + "]");
        
        return (res==null) ? "text/html" : res;
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        Params params;
        String transactionResponse;
        String dispatchURL;
        PrintStream out;
       
        params = this.checkParameters(request);
        params = getDestinationURL(params, request);
        dispatchURL = params.destinationName;
        if (dispatchURL != null) {
            Category.getInstance(getClass()).debug(
              "Dispatch preparado: " + params.destinationName + ".");
            transactionResponse = executeTransaction(params.xml, null);
            request.setAttribute("transactionResponse", transactionResponse);
            this.dispatch(params, request, response);
        }        
        else {
            Category.getInstance(getClass()).debug("No se realizar� dispatch.");
            response.setContentType(params.mime);
            out = new PrintStream(response.getOutputStream());
            transactionResponse = executeTransaction(params.xml, out);
        }
        
    } 
    
    /** Ejecuta la transacci�n conectando con el Transaction Engine.
     *
     *  @param xml La informaci�n que recibir� el transaction engine
     *         y que coincide con el par�metro xml.
     *
     *  @param responseStream Si este argumento no es null se utilizar�
     *         como stream de salida para enviar el resultado de la
     *         transacci�n conforme este va llengando. En caso contrario
     *         contrario se almacenar� en un stringbuffer para retornarlo.
     *
     *  @returns si responseStream vale nulo retornar� la respuesta de la 
     *           transacci�n, en formato xml. En caso contrario devolver�
     *           una cadena vac�a.
     */
    protected String executeTransaction(String xml, PrintStream responseStream) 
    throws IOException {
        StringBuffer res = null;
        String configRoot;
        String host;
        int port;
        ConfigEngine configEngine;
        Socket sck;
        DataInputStream in;
        PrintStream out;
        byte[] buffer;
        int len;
        
        configRoot = super.getServletContext().getInitParameter("configRoot");
        configEngine = ConfigEngine.getInstance(configRoot);
        
        host = configEngine.getProperty("transactionEngine/host");
        port = configEngine.getIntProperty("transactionEngine/port");
        Category.getInstance(getClass()).debug(
          "ConfigRoot: " + configRoot + ", host: " + host + ", port: " + port);
        sck = new Socket(host, port);
        in = new DataInputStream(sck.getInputStream());
        out = new PrintStream(sck.getOutputStream());
        out.println(xml.trim());
        out.println("\n");
        out.flush();
        res = new StringBuffer();
        buffer = new byte[1024*2];
        do {
            len = in.read(buffer);
            if (len > 0)  {
                if (responseStream == null) {
                    res.append(new String(buffer, 0, len)); 
                    res.append("\n");
                }
                else {
                    responseStream.write(buffer, 0, len);
                }
            }
        } while (len > 0);

        sck.close();
            
        return res.toString();
    }
    
    /** Obtiene la url a la que debe redirigirse el servlet. Utiliza
     *  la indicada como elemento <destination>.
     *
     *  @params xml La informaci�n recibida. Debe contener el elemento
     *          que nos interesa.
     *  @returns la url de destino.
     */
    protected Params getDestinationURL(Params params, HttpServletRequest request) {
        String destination;
        String base;
        URLNormalizer norm;
        int pos;
        // Solo tendremos en cuenta un destination fuera del elemento <data>.
        if ((params.xml.indexOf("<destination>") > params.xml.indexOf("<data>")) &&
            (params.xml.indexOf("<destination>") < params.xml.indexOf("</data>")))
        { destination = null;
        } else {
          destination = StringTools.extract(params.xml, 
                                            "<destination>", "</destination>");
        }
        if (destination != null) {
            destination = destination.trim();
            pos = destination.indexOf(':');
            if (pos == -1) {
                params.destinationProtocol = "http";
                params.destinationName = destination;
            } else {
                params.destinationProtocol = destination.substring(0, pos);;
                if (destination.startsWith("http") == false) {
                   params.destinationName = destination.substring(pos+1);
                } else {
                   params.destinationName = destination;
                }
            }
            if (params.destinationProtocol.equals("http") == true) {
                // Si es relativo lo convertimos en absoluto.
                if ((params.destinationName.startsWith("/") == false) && 
                    (params.destinationName.startsWith("http:") == false)) {
                    base = request.getParameter("URLBase");
                    if (base == null) { 
                        base = "";
                    }
                    norm = new URLNormalizer(base, params.destinationName);
                    params.destinationName = norm.getURL();
                }
                // Si es absoluto lo recortamos...
                if (params.destinationName.startsWith("http:") == true) {
                    params.destinationName = 
                         params.destinationName.substring(
                            ServletTools.getAppURL(request).length());
                }
            }
        }
        Category.getInstance(getClass()).debug(
           "final destination: " + 
           "(" + params.destinationProtocol + ")" + 
           params.destinationName);
        
        return params;
    }

    /** Realiza la redirecci�n de acuerdo al par�metro especificado.
     *  Actualmente admite la especificaci�n de dos protocolos en el
     *  el par�metro (http: y servlet:). En el primero de los casos
     *  (que se toma por defecto si no se especifica) se proceder�
     *  al dispatch del servlet a la url indicada. En el segundo
     *  se obtendr� una instancia del EnhancedServlet cuyo nombre
     *  de clase se indica y se proceder� a su invocaci�n. De esta
     *  manera podemos encadenar servlets de una forma sencilla.
     */
    protected void dispatch(Params params, 
                            HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, java.io.IOException {
        if (params.destinationProtocol.equals("http") == true) {
            dispatchURL(params.destinationName, request, response);
        }
        else if (params.destinationProtocol.equals("servlet") == true) {
            dispatchServlet(params.destinationName, request, response);
        }
    }
    
    /** Redirecciona a la url indicada. */
    protected void dispatchURL(String dispatchURL,
                               HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, java.io.IOException {
        Category.getInstance(getClass()).debug(
           "Redireccionando (url): " + dispatchURL);
        getServletConfig().getServletContext().
           getRequestDispatcher(dispatchURL).forward(request,response);
    }
                       
    /** Obtiene el servlet indicado y env�a el procesamiento al mismo. */
    protected void dispatchServlet(String name, 
                              HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, java.io.IOException {
        EnhancedServlet servlet;
        
        servlet = EnhancedServlet.getInstance(name);
        Category.getInstance(getClass()).debug(
           "Redireccionando (servlet): " + name);
        servlet.processRequest(request, response);
    }
    
    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Permite la ejecuci�n de transacciones.";
    }

    class Params {
      String xml = null;
      String destinationName = null;
      String destinationProtocol = null;
      String mime;
    }

}
