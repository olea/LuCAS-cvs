/*
 * CacheElement.java
 *
 * Created on 30 de octubre de 2001, 10:24
 */

package com.echiceros.system.pooling;

import java.util.Date;

/**
 * Un envolvente de cualquier objeto para insertarlo de forma c�moda
 * en la cach�.
 *
 * @author  jv
 * @version 
 */
public class CacheElement implements com.echiceros.system.pooling.Cacheable {

    Object identifier;
    Object element;    
    long expirationDate;
    
    /** Creates new CacheElement 
     *  @param identifier Identificador del objeto.
     *  @param element El objeto a guardar en cach�.
     *  @param seconds cu�ntos segundos debe permanecer en ella como
     *         m�nimo.
     */
    public CacheElement(Object identifier, Object element, long seconds) {
        this.identifier = identifier;
        this.element = element;
        this.expirationDate = new Date().getTime() + seconds * 1000;
    }
    
    /** Retorna el elemento envuelto. */
    public Object getElement() {
        return this.element;
    }

    /** True si el objeto ya no es �til y en lugar de ser retornado
     * debe eliminarse.
     */
    public boolean hasExpired() {
        return (new Date().getTime() > this.expirationDate);
    }
    
    /** Retorna el identificador del objeto, es decir un nombre por
     * el que ser� conocido.
     */
    public Object getIdentifier() {
        return this.identifier;
    }
    
    /** Ejecutado al ser eliminado de la cach�.  */
    public void destroy() {
        this.identifier = null;
        this.element = null;
    }
    
    public String toString() {
        return getClass().getName() + " (" + element.toString() + ")";
    }
    
}
