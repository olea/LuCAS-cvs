/*
 * info.java
 *
 * Created on 2 de noviembre de 2001, 11:35
 */

package com.echiceros.www.customtags.info;

import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.echiceros.www.tools.ServletTools;

/**
 * Este tag env�a a la salida la informaci�n requerida. Permite
 * reducir el n�mero de expresiones incrustadas en las jsp.
 * Integrado en la tld general.
 *
 * Actualmente soporta las siguientes propiedades:
 *
 *   folder          URL (hasta nivel de carpeta) del recurso.
 *   appURL          URL de la aplicaci�n (primera carpeta bajo ra�z).
 *
 * @author  jv
 * @version 1
 */
public class ResourceInfoTag extends javax.servlet.jsp.tagext.TagSupport {

    /** Holds value of property property. */
    private String property;
    
    /** Creates new info */
    public ResourceInfoTag() {
    }

    public int doEndTag() throws JspException {
        String res;
        HttpServletRequest request;
        
        try {
            request = (HttpServletRequest) pageContext.getRequest();
            if (getProperty().equalsIgnoreCase("folder") == true) {
                res = ServletTools.getRequestFolder(request);
            } 
            else if (getProperty().equalsIgnoreCase("appURL") == true) {
                res = ServletTools.getAppURL(request);
            }
            else {
                res = getClass().getName() + ": Unknown property.";
            }
            pageContext.getOut().print(res);
        }
        catch (java.io.IOException e) {
            throw new JspException(
              getClass().getName() + ": " + e);
        }
        
        return SKIP_BODY;
    }
    
    /** Getter for property property.
     * @return Value of property property.
     */
    public String getProperty() {
        return property;
    }
    
    /** Setter for property property.
     * @param property New value of property property.
     */
    public void setProperty(String property) {
        this.property = property;
    }    
}
