/*
 * TrsDemoDataSource.java
 *
 * Created on 11 de enero de 2002, 13:01
 */

package com.echiceros.www.ui.fools;

import com.echiceros.www.ui.*;

/**
 * Permite testear TrsJsGridCreate.
 *
 * @author  jv
 */
public class TrsDemoDataSource extends TrsJsGridCreate.TrsDataSource {
        String definition = 
                  "<data>" + 
                  "  <query> "+ 
                  "  <![CDATA[ " +
                  "         SELECT fcraci, fcdtev, fcnomc " + 
                  "         FROM fca005 "+ 
                  "         WHERE fcdtev=20010131 " + 
                  "           AND fcraci < 50" + 
                  "  ]]> " +
                  "  </query>" +
                  "  <cache>" + "demoDataSource" + "</cache>" +
                  "</data>";
        
        public TrsDemoDataSource() {
            super();
            this.setDefinition(definition);
        }
        
        protected String[] getColumnHeaders() {
            return (new String[]{"RADICAL", "FECHA", "CLIENTE"});
        }        
    }
