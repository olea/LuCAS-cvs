/*
 * ConditionProcessor.java
 *
 * Created on 14 de febrero de 2002, 12:07
 */

package com.echiceros.www.customtags.flowcontrol;

import java.io.*;
import org.apache.log4j.*;
import com.echiceros.www.customtags.TagStreamProcessor;

/**
 * Si la condici�n especificada vale lo indicado por el par�metro <i>value</i>
 * act�a de forma transparente sobre el contenido. En caso contrario cancela 
 * la evaluaci�n del body. Resulta �til por ejemplo a la hora de a�adir un 
 * script a una p�gina jsp solo si se cumple un determinado criterio.
 *
 *    <gen:processor 
 *             className="com.echiceros.www.tags.flowcontrol.ConditionExists"
 *             params="<info>
 *                       <name>user.key</name>
 *                       <scope>session</scope>
 *                       <value>false</value>
 *                    </info>">
 *     ...
 *    </gen:processor>
 *
 * @author  jv
 */
public abstract class ConditionProcessor extends TagStreamProcessor {
    
    /** Creates a new instance of ConditionProcessor */
    public ConditionProcessor() {
        super();
    }

    public void transform() throws IOException {
        this.transformImp();
    }
    
    protected abstract boolean eval();
    
    /** Realiza el volcado de datos.
     */
    public void transformImp()  throws IOException {
        String line;
        int pos;
        BufferedReader reader;
        
        reader = new BufferedReader(this.in);
        do {
            line = reader.readLine();
            if (line != null) {
                out.write(line + "\n");
            }
        } while (line != null);               
    }
    
    public boolean cancelBodyEvaluation() {
        return (eval() != getCompValue());
    }
    
    protected boolean getCompValue() {
        boolean res;
        
        if (this.getXmlParam("xml", "value") != null) {
            res = this.getXmlParam("xml", "value").equalsIgnoreCase("true");
        } else {
            res = true;
        }
        
        Category.getInstance(getClass()).debug("Valor: " + res);
        
        return res;
    }
    
}
