/*
 * FormProcessor.java
 *
 * Created on 22 de septiembre de 2002, 20:20
 */

package com.echiceros.www.formproc;

/**
 * Esta clase ofrece una base sobre la que crear procesadores
 * de formularios (por ejemplo, mediante jython).
 *
 * B�sicamente se trata de una colecci�n de m�todos que
 * retornan strings con el c�digo necesario para influir
 * en el comportamiento del cliente. Por ejemplo pueden
 * utilizarse para activar/desactivar la se�al de "cargando"
 * o para modificar el valor de un campo de texto.
 * 
 *
 * @author  jv
 */
public class FormProcessor {
    
    /** Creates a new instance of FormProcessor */
    public FormProcessor() {
        super();
    }
    
    /** Utilizada para inicializar la cabecera de la 
     *  respuesta.
     */
    protected String init() {
        String res;
        
        res= "<html>" +
             "  <head>" + 
             "    <script language='javascript'>";
        
        return res;
    }
    
    /** Utilizada para finalizar la respuesta. 
     *  Actualmente desactiva el "Loading" y el lock de formulario.
     * [PENDIENTE]  �Tiene que hacer estos dos �ltimos pasos?
     */
    protected String done() {
        String res;
        res = 
              this.hideLoading() + 
              this.formUnlock() + 
              "    </script>" +
              "  </head>" + 
              "</html>";
        
        return res;
    }
    
    /** Desactivaci�n de la se�al de "Loading". 
     */
    protected String hideLoading() {
        return "parent.main.hideLoading();";
    }
    
    /** Activaci�n de la se�al de "cargando". 
     */
    protected String showLoading() {
        return "parent.main.showLoading();";
    }
    
    /** Bloquea todos los formularios situados en el frame
     *  principal.
     */
    protected String formLock() {
        return this.formLock(null);
    }
    
    /** Bloquea el acceso a los componentes de un formulario.
     */
    protected String formLock(String formName) {
        formName = (formName == null) ? "null" : "'" + formName + "'";
        
        return "parent.main.formLock(" + formName + ");";
    }
    
    /** Desbloquea todos los formularios situados en el frame
     *  principal.
     */
    protected String formUnlock() {
        return this.formUnlock(null);
    }
    
    /** Bloquea el acceso a los componentes de un formulario.
     */
    protected String formUnlock(String formName) {
        formName = (formName == null) ? "null" : "'" + formName + "'";
        
        return "parent.main.formUnlock(" + formName + ");";
    }
    
    
    /** Utilizada para modificar el valor de un campo. */
    protected String setFieldValue(String fieldName, String value) {
        return this.setFieldValue(null, fieldName, value);
    }
    
    /** Utilizada para modificar el valor de un campo. */
    protected String setFieldValue(String formName, 
                                   String fieldName, String value) {
        formName = (formName == null) ? "null" : "'" + formName + "'";
        fieldName = "'" + fieldName + "'";
        value = "'" + value + "'";
        
        return "parent.main.setFieldValue(" + 
                 formName + ", " + fieldName + ", " + value + ");";
    }
    
    /** Utilizada para agregar un valor a una lista. */
    protected String addSelectValue(String selectName, 
                                    String value, String text) {
        return this.addSelectValue(null, selectName, value, text);                                    
    }
    
    /** Utilizada para agregar un valor a una lista. */
    protected String addSelectValue(String formName, String selectName, 
                                    String value, String text) {
        formName = (formName == null) ? "null" : "'" + formName + "'";
        selectName = "'" + selectName + "'";
        value = "'" + value + "'";
        text = (text == null) ? "null" :  "'" + text + "'";
        
        return "parent.main.addSelectValue(" + 
                 formName + ", " + selectName + ", " + value + ", " + text + ");";
    }
    
    
    /** Utilizada para limpiar los valores de una lista. */
    protected String clearSelect(String selectName) {
        return this.clearSelect(null, selectName);
    }
    
    /** Utilizada para limpiar los valores de una lista. */
    protected String clearSelect(String formName, String selectName) {
        formName = (formName == null) ? "null" : "'" + formName + "'";
        selectName = "'" + selectName + "'";
        
        return "parent.main.clearSelect(" + formName + ", " + selectName  + ");";
    }
}
