/*
 * Plotter.java
 *
 * Created on 7 de febrero de 2002, 10:00
 */

package com.echiceros.graphics.chart;

import java.util.*;
import java.awt.*;
import java.awt.Graphics.*;

/**
 * Permite colocar sobre un lienzo los puntos indicados como argumentos.
 * Las subclases implementan cada una de ellas un estilo de dibujo.
 *
 * @author  jv
 */
public abstract class Plotter {
    /** Indica si deben dibujarse los labels en cada punto. */
    boolean drawLabels;
    /** Fuente utilizada para escribir la magnitud. */
    Font f = null;
    /** Fontmetrics de f. */
    FontMetrics fm;

    public Plotter() {
        this(false);
    }
    
    public Plotter(boolean drawLabels) {
        this.drawLabels = drawLabels;
    }

    
    /** Dibuja los puntos en un lienzo.
     *
     * @param Ejes de coordenadas. 
     * @param Puntos a dibujar. 
     * @param Lienzo. 
     * @param Tama�o de lienzo. 
     * @param M�rgenes del lienzo. 
     */
    public abstract void drawPoints(Graphics g, Dimension size, Insets insets, 
                                    Axe[] axes, ArrayList points);
    
    /** Dibuja la etiqueta que se indiquen como texto para el punto *fisico*
     *  del graphics indicado.
     */
    protected void drawLabel(Graphics graphics, int x, int y, String text) {
        this.drawLabel(graphics, new Point(x,y), text);
    }
    
    /** Dibuja la etiqueta que se indiquen como texto para el punto *fisico*
     *  del graphics indicado.
     */
    protected void drawLabel(Graphics graphics, Point fpoint, String text) {
        int textWidth;

        if (f == null) {
            f = new Font("Arial", Font.PLAIN, 10);
            fm = graphics.getFontMetrics(f);
        }
        
        textWidth = fm.stringWidth(text);
        graphics.drawString(text, fpoint.x- textWidth/2, fpoint.y-10);        
    }
    
    /** Retorna el punto f�sico (del graphics) en el que debe finalizar
     *  la marca. Es decir, mapea puntos l�gicos (de los ejes) al graphics.
     *  Ignora el eje z.
     */
    protected Point getPoint(Dimension size, Insets insets, 
                             Axe[] axes, ChartPoint cpoint) {
        double xd, yd;
        double x, y;
        
        xd = (size.getWidth() - insets.left - insets.right) *
               axes[Axe.X].getPointDistance(cpoint.getX());
//             axes[Axe.X].getPointDistance(new Double(ordx));
               axes[Axe.X].getPointDistance(cpoint.getY());
//        axes[Axe.X].getPointDistance(new Double(ordx));
        yd = (size.getHeight()- insets.top - insets.bottom) * 
             axes[Axe.Y].getPointDistance(cpoint.getY());
        x = insets.left + xd;
        y = size.getHeight() - insets.bottom - yd;
        
        return new Point((int) x, (int) y);
    }
    
    
    static final Color[] zColors = {
        new Color(102, 143, 193),
        new Color(163, 193, 102),
        new Color(186, 102, 193),
        new Color(193, 102, 125),
        new Color(193, 125, 102)
    };
    
    /** Retorna el color que debe utilizarse para escribir el punto. 
     *  @param axes    Los ejes sobre los que deber� situarse el punto.
     *  @param point   El punto.
     *  @param zIndex  Dentro de la lista de los diferentes valores de Z
     *                 en qu� posici�n se encuentra point.getZ().
     */
    protected Color getPointColor(Axe[] axes, ChartPoint point, int zIndex) {
        Color res;
        
        if (zIndex < zColors.length) {
            res = (zColors[zIndex]);
        } else {
            res = Color.red;
        }
        
        return res;
    }
         
    /** Retorna los valores diferentes encontrados en el eje de las Z,
     *  ordenados. (si no est� definido en los puntos estos tendr�n componente
     *  z de cero, y por lo tanto retornar� un elemento).
     */
    protected Vector calcDiffZValues(Iterator points) {
        Vector values;
        ChartPoint current;
        
        values = new Vector();
        while (points.hasNext() == true) {
            current = (ChartPoint) points.next();
            if (values.contains(current.getZ()) == false) {
                values.addElement(current.getZ());
            }
        }        
        Collections.sort(values);
        
        return values;
    }
}
