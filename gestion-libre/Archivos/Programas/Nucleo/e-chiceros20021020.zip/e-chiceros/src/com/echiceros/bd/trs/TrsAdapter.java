/*
 * TrsAdapter.java
 *
 * Created on 5 de noviembre de 2001, 9:13
 */

package com.echiceros.bd.trs;

import java.util.*;
import java.io.*;
import org.jdom.*;
import org.jdom.input.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 *
 * Ofrece una implementaci�n por defecto para la interface Trs.
 *
 * @author  jv
 * @version 1.1
 */
public abstract class TrsAdapter implements com.echiceros.bd.trs.Trs {

    /** Canal de salida. */
    protected PrintStream out;
    /** Definici�n (data) de la transacci�n. */
    protected org.jdom.Element definition;
    
    /** Creates new TrsEditProfile */
    public TrsAdapter() {
        super();
    }

    /** Fija el objeto que servir� como canal de salida. Deber�a
     * utilizarse para emitir cualquier resultado.
     * @param out El canal de salida que deber�a ser utilizado para enviar
     * cualquier resultado.
     */
    public void setOut(PrintStream out) {
        this.out = out;
    }
    
    /** Fija la informaci�n pertinente para la transacci�n.  Deber�a
     * contener al menos los elementos "cache" y "query" con
     * la cach� de la que recuperar la conexi�n y la query sql
     * a ejecutar.
     * @param xml Documento xml en el que se indican la cach� que
     * contiene la conexi�n a utilizar y la query a
     * ejecutar.
     */
    public void setDefinition(String xml) {
      SAXBuilder builder;
      Document doc;

      try {
          builder = new SAXBuilder();
          doc = builder.build(new java.io.StringReader(xml));
          this.setDefinition(doc.getRootElement());
      }
      catch (JDOMException e) {
          throw new IllegalArgumentException(
            getClass().getName() + ".setDefinition("+xml+"): " + e);
      }
    }
    
    /** Agrega informaci�n pertinente para la transacci�n.  Deber�a
     * contener al menos los elementos "cache" y "query" con
     * la cach� de la que recuperar la conexi�n y la query sql
     * a ejecutar.
     *
     * @param Si contiene un elemento "data" agrega todos sus childs
     *        a la definici�n. Si solo contiene un elemento y no se
     *        denomina "data", agrega solo dicho elemento.
     * query.
     */
    public void setDefinition(org.jdom.Element newDef) {
        Iterator elems;
        Element current;
        Element clone;
        
        if (this.definition == null) {
            this.definition = new Element("data");
        }
        if (newDef.getName().equals("data") == false) {
            addDefinitionElement(newDef, false);
        }
        else {
            elems = newDef.getChildren().iterator();
            while (elems.hasNext() == true) {
                current = (Element) elems.next();
                addDefinitionElement(current, false);
            }
        }        
    }
    
    /** Agrega un elemento a la definici�n. 
     *  @param elem, el elemento a agregar.
     *  @param replace, true ssi deseamos eliminar otros elementos con
     *                  el mismo nombre de la def.
     */
    protected void addDefinitionElement(Element elem, boolean replace) {
        Element clone;
        
        if ((replace == true) && (definition.getChildren(elem.getName()) != null)) {
            definition.removeChildren(elem.getName());
        }
        clone = (Element) elem.clone();
        this.definition.addContent(clone);
    }
    
    /** Crea/Modifica el valor de un determinado parametro (un hijo
     *  de la definition).
     *
     *  @param name Nombre del par�metro. si su valor es null eliminara
     *              el par�metro.
     *  @param value Valor a asignarle.
     */
    public void setParam(String name, String value) {
        Element param;
        
        if (value == null) {
            this.removeParam(name);
        } else {
            if (definition == null) {
                definition = new Element("definition");
            }
            param = this.definition.getChild(name);
            if (param == null) {
                param = new Element(name);
                definition.addContent(param);
            }
            param.setText(value);
        }
    }
    
    /** Elimina el par�metro indicado. */
    protected void removeParam(String name) {
        this.definition.removeChild(name);
    }
    
    /** @returns el valor un elemento child del root cuyo nombre
     *           es el indicado por el par�metro. Si no hay definici�n
     *           o no se encuentra el valor retorna null.
     */
    protected String getParam(String name) {
        String res;
        
        if (this.definition == null) {
            res = null;
        } else {
            res = this.definition.getChildTextTrim(name);
        }
        
        return res;
    }
    
    /** @returns los valores de los elementos child del root cuyo nombre
     *           es el indicado por el par�metro. */
    protected String[] getParamValues(String name) {
        String[] res;
        List values;
        Iterator iter;
        Element current;
        int idx;
        
        values = definition.getChildren(name);
        iter = values.iterator();
        res = new String[values.size()];
        idx = 0;
        while (iter.hasNext() == true) {
            current = (Element) iter.next();
            res[idx] = current.getTextTrim();
            idx = idx + 1;
        }
        
        return res;
    }
    
   
    /** Ejecuta la transacci�n.  */
    public abstract void execute() throws TrsException ;

    
    /** M�todo de conveniencia para escribir en el canal
     * de salida ignorando el tratamiento de las posibles
     * IOException.
     * @param msg Mensaje a escribir por el canal de salida.
     */
    public void write(String msg) {
        if (out != null) {
            out.print(msg);
        }
    }
    
    /** Permite relanzar una excepci�n de forma c�moda. */
    protected void rethrowException(Exception e) throws TrsException {
        Category.getInstance(getClass()).warn(e.getMessage());
        System.err.println(e.getMessage());
        throw new TrsException(e.getMessage());
    }
    
       public static void main(String[] args) throws Exception {
           java.sql.Connection con;
           
           Class.forName("org.gjt.mm.mysql.Driver").newInstance();
           con = java.sql.DriverManager.getConnection("jdbc:mysql://127.0.0.1/vincere?user=trsengine_vincer&amp;password=N3ur0m@nt3&amp;autoReconnect=true");
           System.out.println(con);
           
       }
       
}
