/*
 * TrsImportSQL.java
 *
 * Created on 25 de junio de 2002, 12:29
 */

package com.echiceros.bd.trs.sql;

import java.io.*;
import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 * Env�a una serie de sqls al servidor indicado. La definici�n
 * seguir� este patr�n:
 *
 *  <data>
 *    <url>jdbc:mysql://coco.e-chiceros.com/gipnet</url>
 *    <username>Admin</username>
 *    <password>AdminPass</password>
 *    <sqlsource>file:///c:/thedata.sql</sqlsource>
 *  </data>
 *
 *
 *  sqlsource especifica la fuente de datos. Actualment solo
 *  el protocolo file: esta soportado y permite cargar el 
 *  script sql desde un archivo.
 *
 *  alternativamente puede utilizarse el m�todo setSourceStream(...)
 *  para indicar la fuente de datos.
 *
 *  [ATENCI�N] No registra el driver jdbc.
 *
 * @author  jv
 */
public class TrsImportSQL extends com.echiceros.bd.trs.TrsAdapter {
    
    /** Holds value of property sourceStream. */
    private InputStream sourceStream;
    
    /** Creates a new instance of TrsImportSQL */
    public TrsImportSQL() {
    }
    
    /** Ejecuta la transacci�n.   */
    public void execute() throws TrsException {
        Connection con = null;
        boolean closeSource = false;
        String sourceURL;
        
        try {
            con = DriverManager.getConnection(super.getParam("url"),
                                              super.getParam("username"),
                                              super.getParam("password"));
            if (this.getSourceStream() == null) {
                sourceURL = super.getParam("sqlsource");
                sourceURL = sourceURL.substring("file:///".length());
                this.setSourceStream(new FileInputStream(sourceURL));
                closeSource = true;
            } else {
                closeSource = false;
            }
            this.executeImpl(con, getSourceStream());
        } 
        catch (SQLException e) {
            super.rethrowException(e);
        }
        catch (IOException e) {
            super.rethrowException(e);
        }
        finally {
            if (con != null) {
                try {con.close(); }
                catch (SQLException e) {}
            }
            // Si hemos abierto nosotros el stream de entrada, lo cerramos.
            if ((closeSource == true) && (getSourceStream() != null)){ 
                try { this.getSourceStream().close(); }
                catch (IOException e) {}
            }
        }
    }
    
    protected void executeImpl(Connection con, InputStream in) 
    throws SQLException, IOException {
        DataInputStream dis;
        Statement stmt;
        String sentence;
        int count, errors;
        long t0, tf, seconds;
        
        dis = new DataInputStream(in);
        stmt = con.createStatement();
        
        count = 0;
        errors = 0;
        t0 = new java.util.Date().getTime();
        do {
            
            sentence = this.readSentence(dis);
            if ((sentence != null) && (sentence.length() > 0)) {
                try {
                    Category.getInstance(getClass()).debug(
                         "Ejecutando: " + (sentence.length() > 40 ? sentence.substring(0,40) : sentence) + "...");
                    stmt.executeUpdate(sentence);
                    count = count + 1;
                } 
                catch (SQLException e) {
                    errors = errors + 1;
                    Category.getInstance(getClass()).warn(
                         e.getMessage() + "\r\n" + sentence);
                }
            } 
        } while ((sentence != null) && (sentence.length() > 0));
        
        tf = new java.util.Date().getTime();
        seconds = (tf-t0) / 1000;
        Category.getInstance(getClass()).debug(
            count + " actualizaciones en " + seconds + " segundos. " + 
            "Fallaron " + errors + " sentencias. " + 
            "(" + ((count+errors) / seconds) + " por segundo)");
        
    }
    
    /** Debe retornar la siguiente sentencia a procesar. 
     *  La actual implementaci�n devuelve un readline.
     */
    protected String readSentence(DataInputStream in) 
    throws IOException {
        return in.readLine();
    }
    
    /** Getter for property sourceStream.
     * @return Value of property sourceStream.
     */
    public InputStream getSourceStream() {
        return this.sourceStream;
    }
    
    /** Setter for property sourceStream.
     * @param sourceStream New value of property sourceStream.
     */
    public void setSourceStream(InputStream sourceStream) {
        this.sourceStream = sourceStream;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        TrsImportSQL trs;
        BufferedWriter log;
        
        System.out.println("Lanzando volcado.");
        
        log = new BufferedWriter(new FileWriter("TrsImportSQL.log"));
                
        Category.getRoot().addAppender(new WriterAppender(new SimpleLayout(), log));
        Class.forName("org.gjt.mm.mysql.Driver").newInstance();
        trs = new TrsImportSQL();
        trs.setOut(System.out);
        trs.setParam("url", "jdbc:mysql://coco.e-chiceros.com/gipnet");
        trs.setParam("username", "remote");
        trs.setParam("password", "Gloria");
        trs.setParam("sqlsource", "file:///d:/userinfo/tomcat4/webapps/gipnet/WEB-INF/data/gipnet.sql");
        trs.execute();
        
        log.close();
        
        System.out.println("fin.");
    }
    
}
