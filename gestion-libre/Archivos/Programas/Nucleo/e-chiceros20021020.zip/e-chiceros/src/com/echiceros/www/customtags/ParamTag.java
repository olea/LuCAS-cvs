/*
 * ParamTag.java
 *
 * Created on 23 de septiembre de 2001, 12:15
 */

package com.echiceros.www.customtags;


import javax.servlet.http.*;
import javax.servlet.jsp.tagext.*;
import org.apache.log4j.*;

/**
 * Este est� pensado para a�adir par�mtros de una forma
 * sencilla al tag que lo contiene. 
 *
 *      <gen:param name="color" value="blue" />
 * 
 * o bien
 *
 *      <gen:param name="color">blue</gen:param>
 *
 * @author  jv
 * @version 1.1
 */
public class ParamTag extends BodyTagSupport {

    /** Nombre del par�metro a a�adir. */
    private String name;
    
    /** Valor del par�metro. */
    private String value;
    
    /** Creates new ParamTag */
    public ParamTag() {
        super();
    }

    public int doEndTag() throws javax.servlet.jsp.JspException {
        int action;
        
        if (getValue() != null) {
            setValue(this.getName(), this.getValue());
            action = this.SKIP_BODY;
        }
        else {
            action = this.EVAL_BODY_TAG;
        }
        
        return action;
    }
    
    public int doAfterBody() throws javax.servlet.jsp.JspException {
        String resourceName;
        HttpServletRequest request;
        String body;
        
        request = (HttpServletRequest) pageContext.getRequest();
        resourceName = HttpUtils.getRequestURL(request).toString();
        body = this.getBodyContent().getString();
        setValue(this.getName(), body);
        
        return EVAL_PAGE;
    }
    
    /** Agrega al tag parent el valor correspondiente.
     *  @see com.echiceros.tags.flowcontrol.IncludeTag
     */
    protected void setValue(String name, String value) {
        TagSupport parent;
        
        parent = (TagSupport) this.getParent();
        parent.setValue(name, value);
        Category.getInstance(getClass()).debug(
          "Par�metro: " + name + ", Valor : " + 
          ((value.length() < 30) ? value : value.substring(0,30)+"..."));
    }
    
    /** Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Getter for property value.
     * @return Value of property value.
     */
    public String getValue() {
        return value;
    }
    
    /** Setter for property value.
     * @param value New value of property value.
     */
    public void setValue(String value) {
        this.value = value;
    }
    
}
