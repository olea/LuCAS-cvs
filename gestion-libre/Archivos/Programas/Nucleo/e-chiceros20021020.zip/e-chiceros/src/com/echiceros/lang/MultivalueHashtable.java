/*
 * MultivalueHashtable.java
 *
 * Created on 10 de enero de 2002, 11:22
 */

package com.echiceros.lang;

import java.util.*;

/**
 * Una hashtable con la capacidad de almacenar un n�mero indterminado
 * de elementos por una misma clave.
 * @author  jv
 */
public class MultivalueHashtable {
    /** Aqu� almacena los la informaci�n. La clave es la misma proporcionada
     *  y el valor un vector en el que guardar los elementos.
     */
    Hashtable bag;
    /** Lleva la cuenta de los puts realizados. */
    int count = 0;
    
    /** Creates a new instance of MultivalueHashtable */
    public MultivalueHashtable() {
        this.bag = new Hashtable();
        this.count = 0;
    }
    
    /** @param key Clave por la que se desea realizar el almacenamiento.
     *  @param value Elemento a agregar a la clave.
     */
    public void put(Object key, Object value) {
        Vector v;
        
        v = (Vector) bag.get(key);
        if (v == null) {
            v = new Vector();
            bag.put(key, v);
        }
        
        v.addElement(value);
        count = count + 1;
    }
    
    /** @param key Clave por la que se desea recuperar los elementos. 
     *  @return un iterador con todos los elementos asignados a esa clave.
     */
    public Iterator get(Object key) {
        Vector v;
        
        v = (Vector) bag.get(key);
        if (v == null) { 
            v = new Vector();
        }
        
        return v.iterator();
    }

    /** @return las keys por las que est�n indexados los elementos. */
    public Iterator keys() {
        return bag.keySet().iterator();
    }
    
    /** @returns la cuenta de los puts realizados (elementos almacenados). */
    public int getSize() {
        return this.count;
    }
}
