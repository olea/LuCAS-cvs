/*
 * PortletServlet.java
 *
 * Created on 18 de julio de 2001, 12:21
 */
 
package com.echiceros.www.portlets;           

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.echiceros.system.*;
import com.echiceros.io.*;
import com.echiceros.regexp.*;
import com.echiceros.www.tools.*;

/** 
 *  Este servlet genera los portlets requeridos.
 *  Admite los siguientes par�metros:
 *
 *     portletPattern  -- Fuente de portlets, pero en este caso 
 *                        permitimos la utilizaci�n de expresiones
 *                        regulares para localizar los portlets y
 *                        paths relativos.
 *     template        -- P�gina jsp encargada de utilizar el bean
 *                        "portlet" para mostrarlo de una forma m�s
 *                        flexible que la original. De momento
 *                        debe proporcionarse como un path absoluto
 *                        con respecto a la webapp (/xxx/yyy.jsp, p/ej.);
 *     topMaxLength    -- Tama�o del resumen de cada portlet.
 *     appendBefore    -- Prefijo que se escribir� antes de cada portlet.
 *     appendAfter     -- Sufijo que se a�adir� a cada portlet.
 *     sortBy          -- No especificado, "dateAsc", "dateDesc",
                          "titleAsc" o "titleDesc". Fija 
 *                        el orden que se seguir� para ordenar los
 *                        portlets.
 *     howMany         -- M�ximo n�mero de portlets a recuperar. 
 *                        null se considera todos.
 *
 *
 *  Ejemplo:
 *
 *     <flow:include page="/cgi-bin/portlets">
 *        <gen:param name="portletPattern" value="./news/*portlet*" />
 *
 *       <gen:param name="template" value="/templates/goldandsilver.jsp" /> 
 *       <gen:param name="sortBy" value="dateDesc" />
 *       <gen:param name="appendBefore" value="<p align='center'>" />
 *       <gen:param name="appendAfter" value="</p><br/>" />
 *       <gen:param name="howMany" value="8" />
 *
 *       <gen:param name="xslPath" value="/xsl/presentation.portlets.xsl" />
 *     </flow:include>
 *
 *  El algoritmo utilizado es el siguiente:
 *
 *  - determinar de d�nde queremos obtener los servl
 *        - �porletPattern comienza por "/"?
 *
 *            [s�] es un path absoluto. obtendremos el path real
 *                 utilizando getAbsolutePath sobre �l.
 *
 *            [no] es un path relativo. hay que utilizar el requestFolder
 *                 y aplicar la simplificaci�n de rutas. Despues path real.
 *
 *        - Dividimos el path en la ra�z (hasta la �ltima carpeta) y el
 *          patr�n a buscar (nombre del archivo).
 *
 *        - Generamos los resultados de la b�squeda. ahora tenemos un conjunto
 *          de rutas absolutas.
 *
 *        - Averiguamos la fecha de cada archivo.
 *
 *        - Filtramos por los par�metros de fecha.
 *
 *        - [YA NO SE UTILIZA]
 *          Si la ordenaci�n se hace por fecha, ordenamos ahora y 
 *          nos quedamos con los que indique howMany.
 *
 *        - Para cada resultado, 
 *
 *             utilizando el path absoluto de "/", obtenemos el path relativo.
 *             creamos una url absoluta a la aplicaci�n con este path relativo.
 *             abrimos una conexi�n http a dicha url.
 *             creamos el portlet.
 *
 *        - Si la ordenaci�n se hac�a por t�tulo, ordenamos ahora y 
 *          nos quedamos con los que indique howmany.      
 *
 *        - Obtemos el dispatcher del template.
 *
 *        - Para cada portlet creado, hacemos un include del template.
 *
 *
 * @author  jv
 * @version 2.0
 */
public class PortletServlet extends HttpServlet {

    /** Comprueba el valor de los par�metros y fija params.
     */
    protected Params checkParameters(HttpServletRequest request)
    throws IllegalArgumentException
    {   Params params;
        String normPath;
        
        params = new Params();
        try {
            if (request.getParameterValues("portletPattern") == null)  {
                 throw new IllegalArgumentException(
                       "portletPattern is a mandatory parameter.");
            }
            params.portletPattern = request.getParameter("portletPattern");
            if (request.getParameterValues("template") == null)  {
                 throw new IllegalArgumentException(
                       "template is a mandatory parameter.");
            }
            params.template = request.getParameter("template");
            if (request.getParameter("topMaxLength") != null) {
                params.topMaxLength = 
                  Integer.parseInt(request.getParameter("topMaxLength"));
            }
            if (request.getParameter("howMany") != null) 
            {  params.howMany = 
                  Integer.parseInt(request.getParameter("howMany"));
            }
            
            params.sortBy = (request.getParameter("sortBy") == null) ? 
                            "" : request.getParameter("sortBy");
            
            params.appendBefore = (request.getParameter("appendBefore") == null) ?
                                  "" : request.getParameter("appendBefore");
            params.appendAfter = (request.getParameter("appendAfter") == null) ?
                                  "" : request.getParameter("appendAfter");
            normPath = this.getNormalizedPath(params, request);
            params.folderRealPath = this.getFolderRealPath(normPath, request);
            params.portletPattern = this.getPatternRealPath(normPath);
            
        }
        catch (NumberFormatException e){
            throw new IllegalArgumentException(
                       "PortletServlet.checkParameters(): " + e.getMessage());
        }
        
        return params;
    }
    
    /** @returns Combina params.portletPattern con URLBase para proporcionar la url
     *  de la que debemos extraer los portlets. 
     */
    protected String getNormalizedPath(Params params, HttpServletRequest request) {
        String url;
        String prefix;
        URLNormalizer norm;
        
        if (params.portletPattern.startsWith("/") == true) {
            // Tratamiento para paths absolutos.
            prefix = request.getParameter("URLBase");
            url = prefix + params.portletPattern;
        }
        else {
           // Tratamiento para paths relativos.
            prefix = request.getParameter("URLBase");
            prefix = ServletTools.getRequestFolder(prefix);
            norm = new URLNormalizer(prefix, params.portletPattern);
            url = norm.getURL();
        }
        
        
        return url;
    }

    /** @returns obtiene la parte de la url que refiere a la carpeta del
     *           recurso y retorna el path absoluto a la carpeta que los
     *           contiene.
     */
    protected String getFolderRealPath(String patternURL, HttpServletRequest request) {
        String res;
        String appURL;
        String resourcePath;
        
        appURL = ServletTools.getAppURL(request);
        resourcePath = patternURL.substring(appURL.length());
        resourcePath = resourcePath.substring(0, resourcePath.lastIndexOf('/'));
        
        res = request.getRealPath(resourcePath);
        
        return res;
    }
    
    /** @returns la porci�n de la url correspondiente al pattern (es decir,
     *           elimina la porci�n correspondiente a la carpeta).
     */
    protected String getPatternRealPath(String patternURL) {
        String res;
        
        res = patternURL.substring(patternURL.lastIndexOf('/')+1);
        
        return res;
    }
    
    /* @param path El path en el que empezar la b�squeda.
     * @param pattern El patr�n a utilizar para reconocer los archivos.
     *
     * @returns un array con los archivos cuyo path y nombre coinciden
     *          con los par�metros proporcionados.
     * @throws  IllegalArgumentException si pattern no es v�lido.
     */
    protected String[] getFilePaths(String folder, String pattern) 
    throws IllegalArgumentException {
        SimpleFindFileAdapter finder;
        
        finder = new SimpleFindFileAdapter(folder, pattern);
        
        return finder.getPaths();
    }
    
    /** A�ade la informaci�n sobre fecha de fichero a cada path. 
     *  @param paths Los paths absolutos de los ficheros.
     *  @returns una serie de FileInfo con los paths y las fechas,
     *           ordenados por fechas ascendentemente.
     */
    protected FileInfo[] getFileInfos(String[] filePaths) {
        Vector res;
        File currentFile;
        FileInfo fileInfo;
        FileInfoComparator comparator;
        long date;
        
        res = new Vector();
        for (int i=0; i < filePaths.length; i++) {
            currentFile = new File(filePaths[i]);
            fileInfo = new FileInfo(filePaths[i], 
                                    new Date(currentFile.lastModified()));
            res.addElement(fileInfo);
        }
        comparator = new FileInfoComparator();
        Collections.sort(res, comparator);
        
        return (FileInfo[]) res.toArray(new FileInfo[0]);
    }
    
    /** Filtra los fileInfo por fecha, seg�n el orden indicado.
     *  @param fileInfos los FileInfo a filtrar, ordenados por fecha
     *         ascendentemente.
     *  @param top true ssi deseamos los primeros (los m�s antiguos).
     *  @param howMany cu�ntos queremos como m�ximo.
     *  @return un array con los los FileInfo resultantes.
     */
    protected FileInfo[] filterByDate(FileInfo[] fileInfos, boolean top, int howMany) {
        Vector res;
        
        if ((howMany < 0) || (howMany > fileInfos.length)) {
            howMany =  fileInfos.length;
        }
        res = new Vector();
        for (int i=0; i < howMany; i++) {
            if (top == true) {
               res.addElement(fileInfos[i]);
            }
            else {
               res.addElement(fileInfos[fileInfos.length -1 - i]);
            }
        }
        
        return (FileInfo[]) res.toArray(new FileInfo[0]);
    }

    /** Filtra los fileInfo por fecha: solo retorna aquellos que
     *  se encuentran en el rango especificado.
     *
     *  @param fileInfos los FileInfo a filtrar, ordenados por fecha
     *         ascendentemente.
     *  @param firstDate primera fecha a considerar. formato yyyymmdd.
     *  @param lastDate �ltima fecha a considerar. formato yyyymmdd.
     *  @return un array con los los FileInfo resultantes.
     *  @deprecated No se utiliza.
     */
    protected FileInfo[] filterByDate(FileInfo[] fileInfos, 
                                      int firstDate, int lastDate) 
    {   Vector res;
        
        res = new Vector();
        for (int i=0; i < fileInfos.length; i++) {
            if ((fileInfos[i].getDate() >= firstDate) &&
                (fileInfos[i].getDate() <= lastDate)) {
               res.addElement(fileInfos[i]);
            }
        }
        
        return (FileInfo[]) res.toArray(new FileInfo[0]);
    }
    
    /** Convierte los paths de los FileInfos en urls absolutas a la
     *  webapp actual.
     * 
     *  @param fileInfos FileInfos con los paths absolutos de los
     *         archivos.
     *  @param request Es necesaria para convertir a URLs.
     *  @returns un array con las URLs absolutas de los fileInfos.
     * 
     */
    protected String[] getURLs(FileInfo[] fileInfos, HttpServletRequest request) {
        Vector res;
        FileInfo current;
        String url;
        
        res = new Vector();
        for (int i=0; i < fileInfos.length; i++) {
            current = (FileInfo) fileInfos[i];
            url = ServletTools.getURLFromPath(current.getPath(), request);
            res.addElement(url);
        }
        
        return (String[]) res.toArray(new String[0]);
    }
        
    /** Crea los portlets.
     *  @param URLs urls absolutas de cada portlet.
     *  @params pathInfos PathInfos de cada url almacenada en URLs.
     *  @params topMaxLength longitud m�xima del top del portlet.
     *  @returns los portlets creados.
     */
    protected Portlet[] createPortlets(String[] URLs, 
                                       FileInfo[] fileInfos, int topMaxLength) 
    throws IOException {                                   
        Vector res;
        Portlet currentPortlet;
        URL currentURL;
        HttpURLConnection currentCon;
        
        res = new Vector();
        for (int i=0; i < URLs.length; i++) {
            currentURL = new URL(URLs[i]);
            currentCon = (HttpURLConnection) currentURL.openConnection();
            currentPortlet = new Portlet(currentCon, 
                                         fileInfos[i].getPath(), topMaxLength);
            res.addElement(currentPortlet);
        }
        
        return (Portlet[]) res.toArray(new Portlet[0]);
    }
    
    /** Ordena los portlets por titulo.
     *
     *  @param portlets los portlets a ordenar.
     *  @param boolean asc true ssi los portlets se presentar�n en orden ascendente.
     *  @returns los portlets ordenados.
     */
    protected Portlet[] sortByTitle(Portlet[] portlets, boolean asc) {
        Portlet.PortletComparator comparator;
        
        if (asc == true) {
            comparator = new Portlet.PortletComparator(Portlet.PortletComparator.SORTBY_TITLE_ASC);
        } else {
            comparator = new Portlet.PortletComparator(Portlet.PortletComparator.SORTBY_TITLE_DESC);
        }
        
        Arrays.sort(portlets, comparator);
        
        return portlets;
    }
    
    /** Ordena los portlets por fecha.
     *
     *  @param portlets los portlets a ordenar.
     *  @param boolean asc true ssi los portlets se presentar�n en orden ascendente.
     *  @returns los portlets ordenados.
     */
    protected Portlet[] sortByDate(Portlet[] portlets, boolean asc) {
        Portlet.PortletComparator comparator;
        
        if (asc == true) {
            comparator = new Portlet.PortletComparator(Portlet.PortletComparator.SORTBY_DATE_ASC);
        } else {
            comparator = new Portlet.PortletComparator(Portlet.PortletComparator.SORTBY_DATE_DESC);
        }
        
        Arrays.sort(portlets, comparator);
        
        return portlets;
    }
    
    /** Realiza el include de los portlets a partir del template.
     *  Conforme vaya utilizando los portlets los ir� destruyendo.
     *
     *  @param portlets los portlets a utilizar.
     *  @param templatePath el path relativo a la aplicaci�n del template.
     *  @param howMany cu�ntos portlets deseamos presentar como m�ximo.
     *  @param request utilizada para realizar el dispatch.
     *  @param response utilizada para realizar el dispatch.
     */
    protected void includePortlets(Portlet[] portlets, 
                                   String templatePath, int howMany,
                                   HttpServletRequest request,
                                   HttpServletResponse response) 
    throws IOException, ServletException {
        RequestDispatcher dispatcher;
        
        dispatcher = request.getRequestDispatcher(templatePath);
        if ((howMany < 0) || (howMany > portlets.length)) {
            howMany =  portlets.length;
        }
        
        for (int i=0; i < howMany; i ++) {
            request.setAttribute("portlet", portlets[i]);
            dispatcher.include(request, response);
            portlets[i].finalize();
        }
        request.removeAttribute("portlet");
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        Params params;     
        String[] filePaths;
        FileInfo[] fileInfos;
        String[] portletsURLs;
        Portlet[] portlets;
        
        response.setContentType("text/html");
        params = this.checkParameters(request);
        filePaths = this.getFilePaths(params.folderRealPath, params.portletPattern);
        fileInfos = this.getFileInfos(filePaths);
        
        if (params.sortBy.startsWith("date") == true) {
           fileInfos = this.filterByDate(fileInfos, params.sortBy.endsWith("Asc"), 
                                         params.howMany);
        }        
        portletsURLs = this.getURLs(fileInfos, request);
        portlets = this.createPortlets(portletsURLs, fileInfos, params.topMaxLength);
        if (params.sortBy.startsWith("title") == true) {
            portlets = this.sortByTitle(portlets, params.sortBy.endsWith("Asc"));
        }
        this.includePortlets(portlets, params.template,   
                             params.howMany, request, response);
    }
    

    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Genera portlets a petici�n del sistema.";
    }
    
    /** Una forma conveniente de guardar los par�metros empaquetados. */
    class Params implements java.io.Serializable {
        String portletPattern = null;
        String template = null;
        int topMaxLength = 60*4;
        int howMany = -1;
        String appendBefore;
        String appendAfter;
        String sortBy = null;
        String folderRealPath;
    }
    
    /** Informaci�n con el path y la fecha de cada archivo implicado. */
    class FileInfo {
        String path;
        long date;
        
        public FileInfo(String path, Date date) {
            this.setPath(path);
            this.setDate(date); 
        }
        
        public void setDate(Date date) {
            StringBuffer tmp;
             
            tmp = new StringBuffer();
            
            tmp.append(date.getYear()+ 1900);
            if (date.getMonth() < 9) {
                tmp.append("0");
            }
            tmp.append(date.getMonth() +1);
            if (date.getDate() < 10) {
                tmp.append("0");
            }
            tmp.append(date.getDate());
            
            this.date = Long.parseLong(tmp.toString());
        }
        
        public void setPath(String path) {
            this.path = path;
        }
        
        public String getPath() { return path; }
        public long getDate() { return date; }
        
    }    
    
    class FileInfoComparator implements Comparator {
        
        public int compare(Object obj, Object obj1) {
            int res = 0;
            FileInfo o1, o2;
            
            o1 = (FileInfo) obj;
            o2 = (FileInfo) obj1;
            
            if (o1.getDate() < o2.getDate()) { res = -1; }
            else if (o1.getDate() == o2.getDate()) { res = 0; }
            else if (o1.getDate() > o2.getDate()) { res = +1; }
            
            return res;
        }        
        
    }
}
