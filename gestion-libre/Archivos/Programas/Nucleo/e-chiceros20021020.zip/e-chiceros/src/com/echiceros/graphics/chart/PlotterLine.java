/*
 * PlotterPoint.java
 *
 * Created on 7 de febrero de 2002, 10:11
 */

package com.echiceros.graphics.chart;

import java.util.*;
import java.awt.*;
import java.awt.Graphics.*;

/**
 *
 * @author  Administrador
 */
public class PlotterLine extends com.echiceros.graphics.chart.Plotter {
    
    /** Creates a new instance of PlotterPoint */
    public PlotterLine() {
        super(false);
    }
    
    public PlotterLine(boolean drawLabels) {
        super(drawLabels);
    }

    /** Dibuja los puntos en un lienzo.
     *
     * @param Ejes de coordenadas.
     * @param Puntos a dibujar.
     * @param Lienzo.
     * @param Tama�o de lienzo.
     * @param M�rgenes del lienzo.
     */
    public void drawPoints(Graphics graphics, Dimension size, Insets insets, 
                           Axe[] axes, ArrayList points) {
        Enumeration enum;
        ChartPoint cpoint;
        ChartPoint oldcpoint;
        Point fpoint;
        Point oldfpoint;
        String text;
        Vector zValues;
        int zOrder;
        
        zValues = calcDiffZValues(points.iterator());
        enum = axes[Axe.X].getOrderedPoints(points);
        oldcpoint = null;
        oldfpoint = null;
        while (enum.hasMoreElements() == true) {
            cpoint = (ChartPoint) enum.nextElement();
            fpoint = getPoint(size, insets, axes, cpoint);
            zOrder = zValues.indexOf(cpoint.getZ());
            graphics.setColor(this.getPointColor(axes, cpoint, zOrder));
            if ((oldfpoint != null) && (oldcpoint.getZ().equals(cpoint.getZ()))) {
                graphics.drawLine(oldfpoint.x, oldfpoint.y, fpoint.x, fpoint.y);
            } 
            
            graphics.fillOval(fpoint.x-3, fpoint.y-3, 6, 6);
            if (super.drawLabels == true) {
                text = axes[Axe.Y].getLabelValue(cpoint.getY());
                this.drawLabel(graphics, fpoint, text);
            }
            oldcpoint = cpoint;
            oldfpoint = fpoint;
        }
    }
}
