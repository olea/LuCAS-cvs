/*
 * JythonInstantiator.java
 *
 * Created on 11 de septiembre de 2002, 17:21
 */

package com.echiceros.lang;

import java.util.*;
import java.io.*;
import org.jdom.*;
import org.python.core.*;
import org.python.util.*;
import org.apache.log4j.*;
import com.echiceros.system.*;
import com.echiceros.system.pooling.*;

/**
 *
 * Esta clase es capaz de ejecutar transacciones escritas en jython.
 * Muchas gracias al equipo de jython.org por proporcionar su base en
 * el c�digo de PyServlet.java.
 *
 * Busca en la configuraci�n una entrada para python/home en la
 * que deber�a especificarse la localizaci�n del runtime de jython.
 *
 * [Pendiente] Una correcta gesti�n de los m�dulos.
 *
 * [Pendiente] Cach� de int�rpretes, de forma que no sea necesario
 * crear uno a cada ejecuci�n.
 *
 * @author  jv
 */
public class JythonInstantiator {
    /** Nombre de la cache que contiene los scripts ya compilados. */
    protected static String CACHE_NAME = "jythonClasses";

    /** Instancia pro defecto (singleton). */
    protected static JythonInstantiator defaultInstance = null;
    
    /** Lista de carpetas que pueden contener los scripts jython
     *  si no se proporciona un path absoluto.
     */
    String[] scriptPaths;
    
    /** Crea una nuevo objeto utilizando el engine de configuraci�n
     *  proporcionado por defecto.
     */
    public JythonInstantiator() {
        this(ConfigEngine.getInstance());
    }
    
    /** Creates a new instance of JythonInstantiator */
    public JythonInstantiator(ConfigEngine config) {
        super();
        init(config);
        this.defaultInstance = this;
    }

    /** Inicializa el entorno de ejecuci�n. */
    protected void init(ConfigEngine config) {
        Properties props;
        PySystemState sys;
        
        props = new Properties();
        props.put("python/home", config.getProperty("python/home"));
        PythonInterpreter.initialize(System.getProperties(),
                                     props, new String[0]);
        
        this.scriptPaths = config.getPropertyTexts("python/scriptpath");
        if (this.scriptPaths != null) {
            for (int i=0; i < scriptPaths.length; i++) {
                scriptPaths[i] = scriptPaths[i].replace('\\', '/');
                if (scriptPaths[i].endsWith("/") == true) {
                    scriptPaths[i] = scriptPaths[i].substring(0, scriptPaths[i].length()-1);
                }
            }
        }
    }

    /** Retorna un nuevo objeto java de la clase especificada a partir
     *  del script situado en el path indicado.
     *  @param path Localizaci�n del script.
     *  @param javaClass Clase del objeto a retornar.
     *
     *  @returns El objeto creado a partir del script.
     */
    public static Object newInstance(String path, Class javaClass) 
    throws IllegalArgumentException {
        PyObject pyObject;
        Object javaObject;
        
        pyObject =  JythonInstantiator.getDefault().getPyObject(path);
        javaObject = pyObject.__tojava__(javaClass);
        if (javaObject == Py.NoConversion) {
            throw new IllegalArgumentException("The value from " + path +
                                               "must implement be a" + 
                                               javaClass.getName());
        }
        
        return javaObject;
    }
    
    /** Localiza el path real del script. Si es absoluto respeta el
     *  par�metro. Si es relativo lo concatena con cada uno de los
     *  valores almacenados en this.scriptPaths.
     *  
     *  @param El path original.
     *  @returns El path real del script.
     */
    protected String findRealPath(String path) {
        String realPath;
        int idx;
        File f;
        
        if ((path.startsWith("/") == true) || 
            ((path.length() >= 2) && (path.charAt(1) == ':'))) 
        {  realPath = path;           
        } else {
            realPath = null;
            idx = 0;
            while ((idx < this.scriptPaths.length) && (realPath == null)) {
               f = new File(scriptPaths[idx] + '/' + path);
               if (f.exists() == true) {
                   realPath = scriptPaths[idx] + '/' + path;
               } else {
                   idx = idx + 1;
               }
            }            
        }
        
        return realPath;
    }
    
    /** Elimina el path y la extensi�n del archivo para retornar
     *  el nombre del objeto.
     */
    private String extractObjectName(String path) {
        int pos0, posf;
        String name;
        
        pos0 = path.replace('\\', '/').lastIndexOf('/');
        if (pos0 < 0) {
            pos0 = 0;
        } else  {
            pos0 = pos0 + 1;
        }
        posf = path.lastIndexOf('.');
        if ((posf < 0) || (posf <= pos0)) {
            posf = path.length();
        }
        
        name = path.substring(pos0, posf);
        return name;
    }
    
    /** Retorna el PyObject generado por el script.
     *
     *  @param path El path del script a compilar.
     *  
     *  @return El PyObject creado.
     */
    public PyObject getPyObject(String path) throws PyException {
        return this.getPyObject(path, null);
    }
    
    /** Retorna el PyObject generado por el script.
     *
     *  @param path El path del script a compilar.
     *  @param out  El stream sobre el que se redireccionar� la salida
     *              estandar. null si no se desea redirecci�n.
     *  @return El PyObject creado.
     */
    public PyObject getPyObject(String path, OutputStream out) 
    throws PyException {
        PythonInterpreter interp;
        String realPath, name;
        PyObject cls;
        CachedPythonClass cached;
        PyObject pyObject;
        
        interp = new PythonInterpreter();
        interp.set("__file__", path);
        if (out != null) {
            interp.setOut(out);
        }

        realPath = this.findRealPath(path);
        if (realPath == null) {            
            Category.getInstance(getClass()).warn("No script found at " + path + ".");
        }
        name = this.extractObjectName(path);
        cached = (CachedPythonClass) Cache.createCache(this.CACHE_NAME).get(path, false);
        if (cached == null) {
            interp.execfile(realPath);
            cls = interp.get(name);

            if (cls == null) {
               Category.getInstance(getClass()).warn("No callable found at " + realPath + ".");
                throw new IllegalArgumentException(
                                       "No callable (class or function) "+
                                       "named " + name + " in " + path);
            }

            cached = new CachedPythonClass(path, cls);
            Cache.getCache(this.CACHE_NAME).put(cached);
        } else {
            cls = cached.getJavaClass();
        }

        pyObject = cls.__call__();
        
        return pyObject;
    }    
    
    /** Retorna la instancia por defecto del instanciador. */
    public static JythonInstantiator getDefault() {
        if (defaultInstance == null) {
            defaultInstance = new JythonInstantiator();
        }
        
        return defaultInstance;
    }

    /** Utilizada para guardar en cach� los scripts compilados. 
     *  Expirar�n si se modifica el fichero que contiene el script.
     */
    class CachedPythonClass implements Cacheable {
        String path;
        PyObject javaClass;
        long lastModified;
        
        public CachedPythonClass(String path, PyObject javaClass) {
            File file;
            
            this.path = path;
            this.javaClass = javaClass;
            
            file = new File(this.path);
            this.lastModified = file.lastModified();
        }
        
        public PyObject getJavaClass() {
            return this.javaClass;
        }
        
        /** Retorna el identificador del objeto, es decir un nombre por
         *  el que ser� conocido.
         */
        public Object getIdentifier() {
            return this.path;
        }
        
        /** True si el objeto ya no es �til y en lugar de ser retornado
         *  debe eliminarse.
         */
        public boolean hasExpired() {
            File file;
            
            file = new File(this.path);
            
            return (file.lastModified() > this.lastModified);
        }
        
        /** Ejecutado al ser eliminado de la cach�.  */
        public void destroy() {            
        }
        
    }
    
    public static void main(String[] args) throws Exception {
        JythonInstantiator engine;
        ConfigEngine config;
        org.jdom.input.SAXBuilder builder;
        String xml;
        Document doc;
        
        config = new ConfigEngine();
        config.setProperty("python/home", "d:/dev/jython");
        config.setProperty("python/scriptpath", "d:/dev/jython/demo");

        xml = "<data><message>HOOOOLA!!!</message></data>";
        builder = new org.jdom.input.SAXBuilder();
        doc = builder.build(new StringReader(xml));
        
        engine = new JythonInstantiator(config);
        PyObject obj;
        
        obj = engine.getPyObject("d:/userinfo/projects/echidemo/client/FrmUpdate.py");
        obj.invoke("cmdUpdate_onClick");
        
        //engine.newInstance("TrsTest.py", com.echiceros.bd.trs.Trs.class);
        //        engine.executeTransaction("d:/dev/jython/demo/TrsTest.py",
//                                  doc.getRootElement(), System.out);
        System.exit(0);         
    }
} 
