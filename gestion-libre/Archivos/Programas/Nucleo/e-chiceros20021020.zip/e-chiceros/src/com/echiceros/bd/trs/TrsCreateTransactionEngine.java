/*
 * TrsCreateTransactionEngine.java
 *
 * Created on 23 de noviembre de 2001, 12:00
 */

package com.echiceros.bd.trs;


import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.bd.TransactionEngine;

/**
 * Crea un TransactionEngine.
 * 
 * La definition tiene el siguiente formato:
 *
 *    <data>
 *      <TEConfigPath>
 *        c:/tomcat3/webapps/poscom/fca005/WEB-INF/poscom.xml
 *      </TEConfigPath>       
 *    </data>
 *
 * @author  jv
 * @version 1.0
 */
public class TrsCreateTransactionEngine extends TrsAdapter {

    /** Creates new TrsCreateTransactionEngine*/
    public TrsCreateTransactionEngine() {
        super();
    }

    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        TransactionEngine engine;
        String configPath;
        
        configPath = super.definition.getChildTextTrim("TEConfigPath");
        Category.getInstance(getClass()).debug("Path de Configuracion: " + configPath);
        engine = new TransactionEngine(configPath);
        engine.setStatus(true);
    }
    
}
