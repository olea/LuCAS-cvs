package com.echiceros.system;

import java.util.*;
import java.io.*;
import org.apache.log4j.*;

/** Datos que var�an seg�n la instalaci�n del sistema.
 *
 *  [ATENCI�N] ESTA CLASE HA SIDO DEPRECADA.
 *             �aka!
 *             Se recomienda la utilizaci�n de ConfigEngine.
 *
 */
public class Env implements java.io.Serializable {
    /** Situaci�n por defecto del app.inf: aparentemente, existe
     *  un error que impide el acceso a las propiedades del sistema
     *  en situaciones que no he podido determinar.
     */
    public static final String DEFAULT_INF_PATH =
    "./app.inf";
    
    /** Constantes por defecto: */
    static Hashtable envsPool = null;
    
    /** Nombre de este entorno. */
    String envName;
    
    /** Almac�n de propiedades. */
    Properties properties = null;
    
    protected Env() {
        this("");
    }
    
    public Env(String envName) {
        Category.getInstance(getClass()).debug("Inicializando configuracion.");
        this.envName = envName;
        this.loadConfig();
    }
    
    public void loadConfig() {
        FileInputStream in;
        Properties tmp = null;
        Enumeration keys = null;
        String key = null;
        String infFileName;
        
        infFileName = System.getProperty("app.config.path");
        infFileName = (infFileName != null) ? infFileName : "./app.inf";
        Category.getInstance(getClass()).debug(
                "Cargando configuracion desde " + infFileName + ".");
        tmp = new Properties();
        try {
            in = new java.io.FileInputStream(infFileName);
            tmp.load(in);
            in.close();
        }
        catch(java.io.IOException e) {
            Category.getInstance(getClass()).debug(
                "No se pudo acceder al archivo de configuraci�n.");
            tmp = System.getProperties();
        }
        properties = new Properties();
        keys  = tmp.keys();
        // Hacemos un traspaso de las propiedades para poner la clave
        // en may�sculas. De esta forma, no seremos case-sensitive.
        while (keys.hasMoreElements() == true) {
            key = (String) keys.nextElement();
            properties.setProperty(key.toUpperCase(), tmp.getProperty(key));
        }
    }
    
    
    /** Retorna el contenido de una propiedad como un string. No tiene
       en cuenta las may�sculas en el nombre.
     */
    public String getString(String name) {
        String result;
        
        result = properties.getProperty(name.toUpperCase());
        if (result == null) {
            result = System.getProperty(name);
        }
        if (result == null) {
            toLog("Env.getString("+"\""+name+"\""+"): result == null.");
        }
        return result;
    }
    
    /** Agrega en tiempo de ejecuci�n una propiedad al entorno. */
    public void setString(String name, String value) {
        properties.put(name.toUpperCase(), value);
    }
    
    /** Retorna el contenido de una propiedad como un long. PARA el sistema
       si la propiedad pedida no era un n�mero.
     */
    public long getLong(String name) {
        String value;
        long result = 0;
        
        value = getString(name);
        try {
            result = Long.parseLong(value);
        }
        catch (NumberFormatException e) {
            toLog("Env.getLong("+"\""+"name"+"\""+"): " + e  +".");
        }
        
        return result;
    }
    
    
    /** Retorna el contenido de una propiedad como un int. PARA el sistema
       si la propiedad pedida no era un n�mero.
     */
    public int getInt(String name) {
        return (int) getLong(name);
    }
    
    public static Env getDefault() {
        return getEnv(null);
    }
    
    public static Env getEnv(String envName) {
        Enumeration envs;
        Env res = null;
        
        if (envsPool == null){
            envsPool = new Hashtable();
        }
        
        if (envName == null) {
            envs = envsPool.elements();
            if (envs.hasMoreElements() == true) {
                res = (Env) envs.nextElement();
            } else {
                res = new Env();
                envsPool.put("", res);
            }
        }
        else {
            res = (Env) envsPool.get(envName);
            if (res == null) {
                res = new Env(envName);
                envsPool.put(envName, res);
            }
        }
        return res;
    }
    
    /** Env�a al log de la aplici�n el error. */
    protected void toLog(String eventDesc) {
        System.out.println(eventDesc);
    }
    
    /** Retorna una lista de files incluyendo solo
     *  las carpetas y aquel que se llama app.inf.
     */
    class FolderFilter implements java.io.FileFilter {
        String fileName;
        
        public FolderFilter(String fileName) {
            this.fileName = fileName;
        }
        
        public String getFileName() {
            return this.fileName;
        }
        
        public boolean accept(java.io.File file) {
            return ((file.isDirectory() ||
            (file.getPath().indexOf(fileName) != -1)));
        }
        
        
    }
    
    
    public static void main(String[] args) throws Exception {
        Env.getDefault().setString("PMSysURL", "/127.0.0.1/PMSys");
        System.out.println(Env.getDefault().getString("PMSysURL"));
        System.out.println(Env.getDefault().getString("PMSysURL"));
        System.out.println(Env.getEnv("wop.inf").getString("PMSysURL"));
        System.out.println(Env.getEnv("wop2.inf").getString("PMSysURL"));
    }
    
}