/*
 * TrsSelect.java
 *
 * Created on 15 de agosto de 2001, 13:57
 */

package com.echiceros.bd.trs;

import java.util.*;
import java.io.*;
import java.sql.*;
import org.jdom.*;
import org.jdom.input.*;
import org.apache.log4j.*;
import com.echiceros.system.pooling.*;
import com.echiceros.bd.*;

/**
 * Permite realizar una select gen�rica. ,El trabajo de
 * procesamiento ser� delegado en un Processor.
 *
 * El documento esperado por setDefinition debe al menos
 * contener un elemento bajo la ra�z llamado "query" con
 * el sql a ejecutar:
 *
 *              <data>    
 *                <query>SELECT * FROM acl</query>   
 *                <cache>DEFAULTCONNECTIONPOOL</cache>   
 *              </data>  
 *
 * @author  jv
 * @version 1
 */
public class TrsSQLSelect extends TrsAdapter {
    /** Encargado de procesar cada registro que se recupere.*/
    TrsSQLSelect.Processor processor;
 
    /** Crea una nueva instancia. Ser�a aconsejable fijar a continuaci�n
     * el processor, el out y la definici�n.
     */    
    public TrsSQLSelect() {
        super();
    }
    
    /** Crea una nueva instancia, indicando qu� processor se
     * encargar� de tratar los registros recuperados. Seria
     * aconsejable fijar a continuaci�n la definici�n y el out.
     * @param processor El encargado de procesar los registros.
     */
    public TrsSQLSelect(TrsSQLSelect.Processor processor) {
        this();
        setProcessor(processor);
    }
    
    /** Fija el objeto encargado de ciclar sobre los resultados.
     * @param processor El objeto de clase Processor que tratar� los registros.
     */
    public void setProcessor(TrsSQLSelect.Processor processor) {
        this.processor = processor;
    }
        
     
    /** Delega la funcionalidad sobre executeImp()..
     * @throws TrsException Si se produce cualquier error (normalmente una
     * SQLException o una IOException).
     */    
    public void execute() throws TrsException {
        try {
            this.executeImp();
        }
        catch (SQLException e) {
          throw new TrsException(getClass().getName() + ": " + e.getMessage());
        }
        catch (IOException e) {
          throw new TrsException(getClass().getName() + ": " + e.getMessage());
        }
    }
    
    /** Cicla sobre los registros recuperados invocando los
     * m�todos pertinentes del Processor.
     * @throws IOException Si se produce un error al escribir en el canal de
     * salida.
     * @throws SQLException Si se produce un error relacionado con la consulta.
     */    
    protected void executeImp() throws IOException, SQLException {
      Connection con = null;
      Statement stmt = null;
      ResultSet rs = null;
      MetaData meta;
      String cacheName;
      Cache cache;
      
      cache = this.findCache(); 
      if (cache == null)  {
          Category.getInstance(getClass()).warn(
            "No se ha obtenido ninguna cach�!!!");
      }
      con = (Connection) cache.get(true);
      if (con == null)  {
          Category.getInstance(getClass()).warn(
            "No se ha obtenido ninguna conexi�n de " + cache.getItsId() + ".");
      }
      try {
          stmt = con.createStatement();
          rs = stmt.executeQuery(this.getSQL());
          meta = new MetaData(rs);

          this.processor.preProcess(out);
          while (rs.next() == true) {
              this.processor.processRecord(out,meta, rs);
          }
          this.processor.postProcess(out);
          rs.close();
      }
      catch (SQLException e) {
          throw e;
      }
      finally {
          if (con != null) {
              stmt.close();
              cache.put(con);
          }
      }      
    }
    
    /** Intenta averiguar qu� cach� debe utilizar la consulta. */
    protected Cache findCache() {
        Cache cache = null;
        String cacheName;
        String table;
        String sql;
        int idx0, idx1;
        
        cacheName = getParam("cache");
        if (cacheName != null) {
            Category.getInstance(getClass()).debug("Nombre de cache: " + cacheName);
            cache = Cache.getCache(cacheName);
        } 
        else {
            Category.getInstance(getClass()).debug("Buscando cach� con tabla.");
            sql = this.getSQL();
            idx0 = sql.toUpperCase().indexOf("FROM") + "FROM".length() + 1;
            while ((idx0 < sql.length()) && (sql.charAt(idx0) == ' ')) {
                idx0 = idx0 + 1;
            }
            idx1 = idx0;
            while ((idx1 < sql.length()) && 
                   (sql.charAt(idx1) != ' ') && (sql.charAt(idx1) != ',')) {
                idx1 = idx1 + 1;
            }

            table =  sql.substring(idx0, idx1);
            Category.getInstance(getClass()).debug("Tabla: " + table + ".");
            cache = CacheFinder.getInstance().getCacheWithTable(table);
        }
        
        return cache;
    }
        
    /** Extrae la sql del elemento query de la definici�n.
     * Puede redifinirse para que act�e de otra manera.
     * @return La sql a ejecutar, extra�da de la definici�n.
     */
    protected String getSQL() {
       return getParam("query");
    }

    /** Se realizaran calls sobre los m�todos de la instancia
     * correspondiente de esta clase cuando se inicie y finalice
     * el ciclado sobre los registros recuperados y tambi�n
     * para cada uno de ellos: estos objetos son los responsables
     * de tratar los registros.
     */    
    public interface Processor {
       void preProcess(PrintStream out) 
       throws IOException;
       
       void processRecord(PrintStream out, MetaData meta, ResultSet rs)
       throws IOException, SQLException;
       
       void postProcess(PrintStream out)
       throws IOException;
    }
    
    static class TestProcessor implements Processor {
        /** Para cada registro recuperado se invocar� este m�todo.
         */        
        public void processRecord(PrintStream out, MetaData meta, ResultSet rs) throws IOException, SQLException {
            String name;
            String value;
            
            out.print("------------------\n");
            for (int i=0; i < meta.getColumnCount(); i++) {
                name = meta.getColumnMetaData(i).getName();
                value= rs.getString(i+1);
                out.print("[" + name + " = " + value + "]\n");
            }
        }
        
        /** Invocado antes de recuperar cualquier registro.
         */        
        public void preProcess(PrintStream out) throws IOException {
            out.print("Iniciando.\n");
        }
        
        /** Invocado tras procesar todos los registros.
         */        
        public void postProcess(PrintStream out) throws IOException {
            out.print("Finalizando.\n");
            out.flush();
        }
    }
    
    /** Testea la clase.
     * @param args
     * @throws Exception
     */    
    public static void main(String[] args) throws Exception {
        Connection con;
        Cache cache;
        TrsSQLSelect trs;
        TestProcessor processor;
        String xml;
        
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        con = DriverManager.getConnection("jdbc:odbc:fca005-0");
        cache = Cache.createCache(DEFAULT_CONNECTION_CACHE_NAME, 20);
        cache.put(con);

        xml = "<data>" + 
              "  <query>SELECT * FROM acl</query>" +
              "  <cache>" + Trs.DEFAULT_CONNECTION_CACHE_NAME + "</cache>" +
              "</data>";
        processor = new TestProcessor();
        trs = new TrsSQLSelect();
        trs.setDefinition(xml);
        trs.setOut(new PrintStream(System.out));
        trs.setProcessor(processor);
        trs.execute();
        
    }
}
