/*
 * TrsEditProfile.java
 *
 * Created on 5 de noviembre de 2001, 9:13
 */

package com.echiceros.profile;

import java.util.*;
import java.io.*;
import java.sql.*;
import org.jdom.*;
import org.jdom.input.*;
import org.apache.log4j.*;
import com.echiceros.lang.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;
import com.echiceros.system.*;
import com.echiceros.system.pooling.Cache;
import com.echiceros.lang.StringTools;

/**
 * Actualiza un determinado perfil. Como definici�n tendr� siempre
 * un nombre de usuario y un password, adem�s de las propiedades
 * que se deseen asociar al mismo. Los c�digos de error son:
 *
 *  1001 - no se ha especificado username.
 *  1002 - formato de username no v�lido.
 *  1003 - no se ha especificado password.
 *  1004 - formato de password no valido.
 *  1010 - username existe y el password no coincide.
 *
 * El formato de definici�n esperado es:
 *
 *             <data>
 *               <cache>datasourcename</cache>                
 *               <storexpath>//coco:9998/webapps/vincere/rsessions/3kj34jka</storexpath>
 *               <profile username="javito" trustedkey="qQWqoYeiCMqmKaQA">
 *                 <property name="password" value="Gloria"/>
 *                 <property name="email" value="jv@e-chiceros.com"/> 
 *                 <property name="hobby" value="Decorar despachos."/> 
 *                 <property name="realname" value="Javier"/> 
 *                 <property name="realsurnames" value="Moreno Mu�oz"/>
 *               </profile>
 *             </data>
 *
 * cach� es opcional.
 *
 * storexpath es opcional y en caso de que se especifique marcar� en qu�
 * servidor de configuraci�n y xpath se almacenar� el username del usuario
 * que acaba de darse de alta.
 *
 * Las propiedades que existan previamente y cuyo elemento no se especifique
 * ser�n ignoradas. Si el username ya existe se considera una actualizaci�n.
 * Para que sea efectiva trustedkey debe contener el fastdigest de la 
 * antigua password. Si el valor indicado es "" se eliminar�n. username y
 * password se tratan de manera especial. 
 *
 * El resultado de una actualizaci�n exitosa ser� un documento como el
 * siguiente:
 *
 *      <transactionresponse>
 *       <type>success</type>
 *       <data>
 *          <trustedkey>qQWqoYeiCMqmKaQA</trustedkey>
 *       </data>
 *     </transactionresponse>
 *
 * @author  jv
 * @version 
 */
public class TrsEditProfile extends TrsAdapter {
    /* Longitud de la password digerida. */
    static final int DIGESTPASSLEN = 16;
    
    /** Los elementos almacenados, guardados por nombre del elemento. */
    Hashtable elements;
    /** true si el usuario ya existe (debe actualizarse la password). */
    boolean exists;
    /** Nueva trustedKey (password digerido). */
    String newTrustedKey;
    
    /** Creates new TrsEditProfile */
    public TrsEditProfile() {
        super();
        elements = new Hashtable();
    }

    /** Carga los elementos en una hash para una manipulaci�n m�s
     *  c�moda.
     */
    protected void loadElements() {
        Iterator iter;
        Element anElement;
        
        iter = definition.getChild("profile").getChildren("property").iterator();
        while (iter.hasNext() == true) {
            anElement = (Element) iter.next();
            this.elements.put(anElement.getAttributeValue("name"),
                              anElement.getAttributeValue("value"));
        }
    }
    
    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        Cache cache = null;
        Connection con = null;
        String result = null;
        String errCode;
        String username;
        String storexpath;
        
        try { 
          loadElements();
          checkParameters();
          cache = CacheFinder.getInstance().
                     getCacheWithTable(definition.getChildText("cache"), "userinfo");
          con = (Connection) cache.get(true);
          update(con);
          result = TransactionEngine.createSuccessXML(
                        "   <trustedkey>" + this.newTrustedKey + "</trustedkey>");
          // si se ha completado con �xito la almacenamos en la configuraci�n.
          storexpath = this.getParam("storexpath");
          if (storexpath != null) {
            username = definition.getChild("profile").getAttributeValue("username");
            ConfigClient.setPropertyByURL(storexpath+"/username", username);
          }
        }
        catch (IllegalArgumentException e) {
            errCode = StringTools.extract(e.getMessage(), "[", "]");
            result = TransactionEngine.createErrorXML(errCode, e.toString());
        }
        catch (SQLException e) {
            Category.getInstance(getClass()).warn("Error: " + e.getMessage());
            throw new TrsException(e.getMessage());
        }
        finally {
          write(result);
          if (con != null) { 
              cache.put(con); 
          }
        }
    }
    
    /** Comprueba que est� definido el element username y el elemento
     *  password, asi como su validez. Si el username ya existe en la
     *  base de datos comprueba que el password suministrado sea v�lido.
     *
     *  @throws IllegalArgumentException Si alguna de la condiciones 
     *          no se cumple
     */
    protected void checkParameters() throws IllegalArgumentException {
        String username;
        String password;
        
        username = (String) definition.getChild("profile").getAttributeValue("username");
        username = StringTools.escapeToSQL(username);
        password = (String) elements.get("password");
        
        if (username == null) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " + "[1000] username is a mandatory parameter.");
        }
        if ((username.length() < 6) || (username.length() > 16)) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " + "[1001] username length is not valid.");
        }
        if (password == null) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " + "[1002] password is a mandatory parameter.");
        }
        if ((password.length() < 6) || (password.length() > 16)) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " + "[1003] password length is not valid.");
        }
        this.exists = checkIfExists(username, password);
    }
    
    /** Comprueba si existe el nombre de usuario y no coincide la trusted key
     *  con el digest del mismo.
     *
     *  @param username Nombre de usuario.
     *  @param password Password a comprobar.
     *  @returns true si el usuario existe (y la trustedkey es correcta).
     *
     *  @throws IllegalArgumentException si el username existe y no coincide
     *          su password con la suministrada.
     */
    protected boolean checkIfExists(String username, String password)
    throws IllegalArgumentException {
        boolean exists;
        Cache cache;
        Connection con = null;
        Statement stmt;
        ResultSet rs;
        String trustedKey = null;
        String key = null;
       
        exists = false;
        cache = CacheFinder.getInstance().
                     getCacheWithTable(definition.getChildText("cache"), "userInfo");
        con = (Connection) cache.get(true);
        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT passDigest " +
                                   "FROM userInfo " +
                                   "WHERE (username = '" + username + "')");
            if (rs.next() == true) {
                key = rs.getString("passDigest");
                trustedKey = definition.getChild("profile").getAttributeValue("trustedkey");
                exists = true;
            }

            rs.close();
            stmt.close();
            Category.getInstance(getClass()).debug(
                "trustedKey: [" + trustedKey + "], username: [" + username + "], key: [" + key + "].");
            if ((trustedKey != null) && (key != null) &&
                (key.equals(trustedKey) == false)) {
                  Category.getInstance(getClass()).warn(
                     "�Intrusi�n! " + username + ": [" + trustedKey + 
                     "], [" + key+ "]");
                  throw new IllegalArgumentException(
                     getClass().getName() + ": " + " [1010] access denied.");
            }        
        }
        catch (SQLException e) {
            System.out.println(getClass().getName() + ": " + e);
        }
        finally {
            if (con != null) {
               cache.put(con);
            }
        }
        return exists;
    }
    
    /** Actualiza el perfil indicado, modificando las propiedades asociadas.
     *  El comportamiento es el siguiente:
     *  
     *      Si se ha asignado un valor a una propiedad distinto de ""
     *      s inserta la propiedad o se actualiza su valor.
     *
     *      Si se ha asignado un valor "" a una propiedad, dicha
     *      propiedad se elimina.
     *
     *      Si no se declara una propiedad existente se ignora.
     *
     *  El m�todo presupone que cualquier elemento de la definici�n
     *  distinto de username, password es una propiedad.
     */
    protected void update(Connection con) throws SQLException {
        String username;
        String password;
        
        username = (String) definition.getChild("profile").getAttributeValue("username");
        username = StringTools.escapeToSQL(username);
        password = (String) elements.get("password");
        elements.remove("username");
        elements.remove("password");
     
        updateInfo(con, username, password);
        updateProperties(con, username);
    }
    
    /** Actualiza la tabla de informaci�n, si es necesario. */
    protected void updateInfo(Connection con, String username, String password) 
    throws SQLException {
        Statement stmt;
        String sql;
        
        try {
            stmt = con.createStatement();
            this.newTrustedKey = StringTools.fastDigest(password, DIGESTPASSLEN);
            if (this.exists == false) {
                sql = "INSERT INTO userInfo " + 
                      "VALUES (" + 
                      "  '"+ username + "', " + 
                      "  '"+ this.newTrustedKey + "')";
            } else {
                sql = "UPDATE userInfo " + 
                      "SET passDigest = '"+ this.newTrustedKey + "' " + 
                      "WHERE username = '" + username + "'";;
            }
            stmt.executeUpdate(sql);
            stmt.close();
        }
        catch(SQLException e) {
            Category.getInstance(getClass()).debug(e.toString());
        }
    }
    
    /** Actualiza la tabla de propidades, si es necesario. */
    protected void updateProperties(Connection con, String username) 
    throws SQLException {
        Iterator iter;
        String name;
        String value;
        PreparedStatement stmtInsert;
        PreparedStatement stmtUpdate;
        PreparedStatement stmtDelete;
        
        stmtInsert = con.prepareStatement("INSERT INTO userProperties " +
                                          "  (username, name, value) " + 
                                          "VALUES " + 
                                          "  ('" + username + "', ?, ?)");
        stmtUpdate = con.prepareStatement("UPDATE userProperties " +     
                                          "SET value = ? " +
                                          "WHERE username = '" + username + "' " +
                                          "  AND name = ? ");
        stmtDelete = con.prepareStatement("DELETE FROM userProperties " +
                                          "WHERE username = '" + username + "' " +
                                          "  AND name = ? ");
               
        
        iter = elements.keySet().iterator();
        while (iter.hasNext() == true) {
            name = (String) iter.next();
            value= (String) elements.get(name);
            updateProperty(stmtInsert, stmtUpdate, stmtDelete, name, value);
        }        
    }
    
    
    /** Actualiza la propiedad. */
    protected void updateProperty(PreparedStatement stmtInsert,
                                  PreparedStatement stmtUpdate,
                                  PreparedStatement stmtDelete,
                                  String name, String value)
    throws SQLException { 
      if (value.length() == 0) {
          stmtDelete.setString(1, name);
          stmtDelete.execute();
      }
      else {
          try {
              stmtInsert.setString(1, name);
              stmtInsert.setString(2, value);
              stmtInsert.execute();
          }
          catch (SQLException e) {
              stmtUpdate.setString(1, value);
              stmtUpdate.setString(2, name);
              stmtUpdate.execute();
          }
      }
    }
    
    public static void main(String[] args) throws Exception {
        TrsEditProfile trs;
        String xml;
        Connection con;
        
        Class.forName("org.gjt.mm.mysql.Driver").newInstance();
        con = DriverManager.getConnection(
                              "jdbc:mysql://127.0.0.1/vincere?" + 
                              "user=trsengine&password=trs3ng1n3&" + 
                              "autoReconnect=true");
        
        Cache.createCache("demoDataSource", 20).put(con);
        
        xml = "<data>\n" +
              "  <element name=\"username\" value=\"javito\"/> \n" +
              "  <element name=\"password\" value=\"Gloria\"/> \n" +
              "  <element name=\"email\" value=\"jv@e-chiceros.com\"/> \n" +
              "  <element name=\"hobby\" value=\"Decorar despachos.\"/> \n" +
              "  <element name=\"realname\" value=\"Javier\"/> \n" +
              "  <element name=\"realsurnames\" value=\"Moreno Mu�oz\"/> \n" +
              "</data>\n";        
        trs = new TrsEditProfile();
        trs.setDefinition(xml);
        trs.setOut(new PrintStream(System.out));
        trs.execute();
        
        System.out.flush();
    }
}
