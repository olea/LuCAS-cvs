/*
 * RETools.java
 *
 * Created on 2 de agosto de 2001, 19:01
 */

package com.echiceros.regexp;

import org.apache.oro.text.regex.*;

/**
 * Permite ejecutar de forma sencilla patrones de expresiones
 * regulares. Guarda en la cach� el compilador para optimizar
 * el rendimiento.
 *
 * @author  jv
 * @version 
 */
public class Matcher {
    /** Patr�n a reconocer. */
    Perl5Compiler compiler;
    /** Patr�n a buscar. */
    Pattern pattern;
    /** Reconocedor. */
    Perl5Matcher matcher;
    /** Fuente de datos. */
    PatternMatcherInput pmi;
    /** Cadena de caracteres en al que buscaremos. */
    String text;
    
    /** Creates new Matcher */
    public Matcher(String pattern) 
    throws MalformedPatternException {
       System.out.println("[DEBUG] Pattern: " + pattern + ".");
       this.compiler = new Perl5Compiler();
       this.pattern = this.compiler.compile(pattern);
       this.matcher  = new Perl5Matcher();
       this.pmi = null;
       this.text = null;
    }
    
    /** Fija la cadena en la que se ejecutara la re. */
    public void setText(String value) {
       this.text = value;
       pmi = new PatternMatcherInput(text);
    }
    
    /** Retorna la cadena en la que se realiza la b�squeda. */
    public String getText() {
       return this.text;
    }
    
    /** Realiza la busqueda.
     *
     *  @result Un MatchResult con la informaci�n del patr�n encontrado.
     *          Retornar� null si no hay m�s matching.
     */
    public MatchResult next() {
        MatchResult res;
        
        if (matcher.contains(pmi, pattern) == true) {
          res = matcher.getMatch();
        }
        else {
          res = null;
        }
        
        return res;
    }
   
    /** Realiza una b�squeda y retorna true si se han encontrado grupos.
     */
    public boolean match(String text) {
      MatchResult result;
      
      this.setText(text);
      result = this.next();
      
      return (result == null) ? false : (result.groups() != 0);
    }
    
    
    public static void main(String[] args) {
      Matcher matcher;
      MatchResult result;
      
      try {
          matcher = new Matcher("ja*v[a,i]");
          matcher.setText("Hola, soy jaaaaaaaavi. Vivo en la isla de java (en la hacienda de javi) programando en java.");
          do {
              result = matcher.next();
              if (result != null) {
                  System.out.println(result.toString());
              }
          } while (result != null);
      }
      catch (MalformedPatternException e) {
          System.err.println(e);
      }
    }

    
}
