/*
 * IfTag.java
 *
 */

package com.echiceros.www.customtags.flowcontrol;

import java.util.*;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * Se limita a comprobar si el par�metro cond vale false, null,
 * 0 o "" y en tal caso no procesa el contenido. El parametro
 * cond puede especificarse como atributo del tag o mediante
 * <gen:param.../>, pero el comportamiento es sutilmente diferente:
 * en el primer caso no se evaluar� el body y en el segundo caso s�.
 * Esto �ltimo puede producir problemas si en el body existen 
 * expresiones que generan excepciones en caso de no cumplirse la
 * condici�n.
 *
 * @author  jv
 * @version 
 */
public class IfTag extends BodyTagSupport {
    
    /** Holds value of property cond. */
    private String cond;
    
    public IfTag() {
        super();
    }

    public int doStartTag() throws JspTagException {
       int res;
       
       if (this.cond == null) {
           res = this.EVAL_BODY_TAG;
       } else if ((this.cond.length() == 0)  ||  
                  (this.cond.equals("null")) || 
                  (this.cond.equals("0")) || 
                  (this.cond.equals("false"))) {
           res = this.SKIP_BODY;
       } else {
           res = this.EVAL_BODY_TAG;
       }
       
       return res;
    }    
    
    public int doAfterBody() throws JspTagException {
        String body;
        String cond;
        
        try {
            cond = (String) this.getValue("cond");
            if ((cond != null) && (cond.length() != 0)  &&
                (cond.equals("null") == false) && 
                (cond.equals("0") == false) && 
                (cond.equals("false") == false)) {
                body = getBodyContent().getString();
                this.getPreviousOut().print(body);
            }
        } catch (IOException e) {
           throw new JspTagException(e.toString());
        }
        
        return SKIP_BODY;
    }
    
    public int doEndTag() throws JspException {
        return this.EVAL_PAGE;  
    }
       
    /** Setter for property cond.
     * @param cond New value of property cond.
     */
    public void setCond(String cond) {
        this.cond = cond;
    }
    
}
