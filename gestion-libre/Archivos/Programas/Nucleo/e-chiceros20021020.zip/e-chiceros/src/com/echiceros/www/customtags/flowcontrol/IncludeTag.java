/*
 * IncludeTag.java
 *
 * Created on 23 de septiembre de 2001, 12:13
 */

package com.echiceros.www.customtags.flowcontrol;

import java.io.*;
import java.util.*;
import java.net.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import org.apache.log4j.*;
import HTTPClient.*;
import com.echiceros.www.tools.*;


/**
 * Sustituye y mejora la funcionalidad proporcionada por jsp:include. 
 * Admite (e ignora!) flush en el output de salida.
 *
 * Agrega a la invocaci�n todos los par�metros del request original.
 * 
 * Agrega a la invocaci�n todos los par�metros que se indiquen
 * mediante <gen:param.../>
 *
 * Agrega a la invocaci�n un par�metro (URLBase) con la url
 * que ejecuto el include. Puede sobreescribirse mediante <gen:param.../>.
 *
 * Agrega a la invocaci�n un par�metro (JSESSIONID) con el identificador
 * de sessi�n original.
 *
 * 
 * @author  jv
 * @version 1
 */
public class IncludeTag extends BodyTagSupport {

    /** La url (relativa o absoluta) a resolver. */
    protected String page;
    
    /** Los par�metros fijados mediante <param .../> */
    protected Hashtable params;
    
    /** Creates new IncludeTag */
    public IncludeTag() {
        super();
        params = new Hashtable();
    }

    public int doEndTag() throws JspException {
        URLNormalizer norm;
        
        try {
          norm = this.calcURL();
          Category.getInstance(getClass()).debug(norm.getURL());
          this.include(norm); 
        }
        catch (IOException e) {
            throw new JspException ("IncludeTag.doEndTag(): " + e);
        }
        
        return this.EVAL_PAGE;  
    }
    
    /** Compone la url del recurso a incluir. */
    protected URLNormalizer calcURL() {
        URLNormalizer norm;
        Enumeration paramEnum;
        String paramName;
        String paramValue;
        HttpServletRequest request;
        String URLBase;
        
        request = (HttpServletRequest) pageContext.getRequest();
        URLBase = HttpUtils.getRequestURL(request).toString();
        URLBase = URLBase.substring(0, URLBase.lastIndexOf("/"));
        
        norm = new URLNormalizer(ServletTools.getAbsolutePath(getPage(), request), "");
        // Agrega los par�metros explicitados con <gen:param../>
        paramEnum = this.getValues();
        while (paramEnum.hasMoreElements() == true) {
            paramName = (String) paramEnum.nextElement();
            paramValue = (String) this.getValue(paramName);
            norm.addParam(paramName, paramValue);
        }
        // Agrega los par�metros procedentes del request
        paramEnum = request.getParameterNames();
        while (paramEnum.hasMoreElements() == true) {
            paramName = (String) paramEnum.nextElement();
            paramValue = request.getParameter(paramName);
            norm.addParam(paramName, paramValue);
        }
        // Agrega la URL desde la que se origin� el request
        if (norm.getParams().indexOf("URLBase") == -1) {
           // Solo si no hemos heredado el par�metro URLBase...
           norm.addParam("URLBase", URLBase);
        }
        // Agrega un par�metro con el valor de las session original
        if (request.getParameter("JSESSIONID") == null) {
           norm.addParam("JSESSIONID", request.getRequestedSessionId());
        } 
        
        return norm;
    }
    
    /** Abra una conexi�n a la url indicada e incluye el recurso
     *  asociado.
     */
    protected void include(URLNormalizer norm) throws IOException {        
        String urlSpec;
        HTTPClient.URI uri;
        String query;
        HTTPConnection con;
	HTTPResponse   rsp;
        BufferedReader in;
        String text;
        
        try {
            CookieModule.setCookiePolicyHandler(null);
            
            urlSpec = norm.getRoot();
            uri = new HTTPClient.URI(urlSpec);
            con = new HTTPConnection(uri);            
           
            query = norm.getFile() + "?" + norm.getParams();
            rsp = con.Get(query);
            if (rsp.getStatusCode() >= 300)	{
                throw new IOException(getClass().getName() + ": " +
                                          rsp.getReasonLine() + "\n" +
                                          rsp.getText());
            }
            else {
                text = rsp.getText(); 
                this.getPreviousOut().write(text);
            }
            con.stop();
        }
        catch (HTTPClient.ParseException e) {
                throw new IOException(getClass().getName() + ": " + e);
        }
        catch (HTTPClient.ModuleException e) {
                throw new IOException(getClass().getName() + ": " + e);
        }
    }
    
    /** Getter for property page.
     * @return Value of property page.
     */
    public String getPage() {
        return page;
    }
    
    /** Setter for property page.
     * @param page New value of property page.
     */
    public void setPage(String page) {
        this.page = page;
    }
    
    
    
    public java.lang.Object getValue(String key) {
        Object retValue;
        
        retValue = this.params.get(key);
        return retValue;
    }    
    
    public java.util.Enumeration getValues() {
        java.util.Enumeration retValue;
        
        retValue = this.params.keys();
        return retValue;
    }
    
    public void setValue(java.lang.String str, java.lang.Object obj) {
        this.params.put(str, obj);
    }
    
    /* -- DEBUG ----------------------------------------------------------------+/
    public static void main(String[] args) throws Exception {
        String data;
        
        HTTPConnection con = new HTTPConnection(new URI("http://127.0.0.1:8080"));
	HTTPResponse   rsp = con.Get("/fca005/cgi-bin/transactionservice?xml=wop");
	if (rsp.getStatusCode() >= 300)
	{
	    System.err.println("Received Error: "+rsp.getReasonLine());
	    System.err.println(rsp.getText());
	}
	else {
	    data = new String(rsp.getData()); 
            System.out.println(data);
        }
    }
    /* -- DEBUG ----------------------------------------------------------------*/
    
    public static void main(String[] args) throws Exception {
        String urlSpec;
        HTTPClient.URI uri;
        String query;
        HTTPConnection con;
	HTTPResponse   rsp;
        BufferedReader in;
        String text;

        urlSpec = "http://127.0.0.1:8080";
        uri = new HTTPClient.URI(urlSpec);
        con = new HTTPConnection(uri);
        query = "/vincere/cgi-bin/portlets";
        rsp = con.Get(query);
        if (rsp.getStatusCode() >= 300)	{
            throw new IOException(rsp.getReasonLine() + "\n" +
                                  rsp.getText());
        }
        else {
            text = rsp.getText(); 
            System.out.println(text);
        }
        con.stop();
        
    }
    
}
