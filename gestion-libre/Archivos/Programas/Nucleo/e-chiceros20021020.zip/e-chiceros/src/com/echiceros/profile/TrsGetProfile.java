/*
 * TrsGetProfile.java
 *
 * Created on 14 de febrero de 2002, 16:08
 */

package com.echiceros.profile;

import java.io.*;
import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 * Recupera la informaci�n asociada a un determinado perfil.      
 * No recuperar� el password de usuario.   
 *
 * El formato de definici�n esperado es:
 *
 *             <data>
 *               <cache>datasourcename</cache>                
 *               <username>ciberado</username> 
 *               <properties>email, hobby, realname</properties>
 *             </data>
 *
 * el elemento cach� es opcional. El elemento properties es opcional:
 * si no se especifica se retornar�n todas las disponibles. El 
 * resultado ser� un documento xml como el siguiente:
 *
 *             <data>
 *               <profile username="javito">
 *                 <property name="email" value="jv@e-chiceros.com"/> 
 *                 <property name="hobby" value="Decorar despachos."/> 
 *                 <property name="realname" value="Javier"/> 
 *               </profile>
 *             </data>
 *
 *
 * @author  jv
 */
public class TrsGetProfile 
extends com.echiceros.bd.trs.TrsSQLSelect
implements TrsSQLSelect.Processor {
    
    /** Creates a new instance of TrsGetProfile */
    public TrsGetProfile() {
        super();
        this.setProcessor(this);
    }
    
    public String getSQL() {
        String sql;
        
        sql = "SELECT * FROM userproperties " + 
              "WHERE username='" + getParam("username") + "'";
        
        return sql;
    }
    
    public void preProcess(PrintStream out) throws IOException {
        Category.getInstance(getClass()).info(
           "Accediendo a perfil de " + getParam("username") + ".");
        out.println("<profile username=\"" + getParam("username") + "\">");
    }
    
    
    public void processRecord(PrintStream out, MetaData meta, ResultSet rs) 
    throws IOException, SQLException {
        String name; 
        String value;
        
        name = rs.getString("name");
        if ((getParam("properties") == null) || 
            (getParam("properties").indexOf(name) != -1)) {
          value = rs.getString("value");
          out.println("<property name=\"" + name + "\" value=\"" + value + "\" />");
        }
    }
    
    public void postProcess(PrintStream out) throws IOException {
        out.println("</profile>");
    }    
    
}
