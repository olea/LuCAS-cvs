/*
 * StreamProcessor.java
 *
 * Created on 23 de octubre de 2001, 22:52
 */

package com.echiceros.io;

import java.util.*;
import java.io.*;
import com.echiceros.lang.*;

/**
 * Act�a como filtro entre un reader y un writer.
 *
 * @author  jv 
 * 
 */
public abstract class StreamProcessor {
    protected Reader in;
    protected Writer out;
    protected String name;    
    /** Permite especificar los par�metros de comportamiento. */
    protected Hashtable params;
    
    public StreamProcessor() {
        super();
        this.params = new Hashtable();
    }
    
    /** Creates new StreamProcessor */
    public StreamProcessor(Reader in, Writer out) {
        this();
        setIn(in);
        setOut(out);
    }
    
    public void setIn(Reader in) {
        this.in = in;
    }
    
    public void setOut(Writer out) {
        this.out = out;
    }

    public abstract void transform()  throws IOException;
    
    /** Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    public void setParam(String name, String value) {
        this.params.put(name, value);
    }
    
    public String getParam(String name) {
        return (String) params.get(name);
    }
    
    /** Considera el parametro <i>name</i> como un documento xml
     *  y trata de retornar el contenido del elemento cuyo nombre 
     *  se indica.
     * 
     *  [limitaci�n] Solo funcionar� correctamente si el elemento
     *  tiene contenido expl�cito, es decir, es de la forma
     *  <elemento>...</elemento>.
     *
     *   @param name Nombre del par�metro a considerar como xml.
     *   @param element Nombre del elemento a procesar.
     *   @returns el contenido (CONTENIDO) de dicho elemento.
     */
    public String getXmlParam(String name, String element) {
        String res;
        String xml;
        
        xml = getParam(name);
        if (xml != null) {
            res = StringTools.extract(xml, "<"+element + ">", "</" + element + ">");
        } else {
            res = null;
        }
        
        return res;
    }
}
