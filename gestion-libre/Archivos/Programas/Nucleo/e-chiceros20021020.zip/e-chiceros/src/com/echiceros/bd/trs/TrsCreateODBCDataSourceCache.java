/*
 * TrsCreateDataSourceCache.java
 *
 * Created on 20 de noviembre de 2001, 18:32
 */

package com.echiceros.bd.trs;


import java.sql.*;
import com.echiceros.bd.*;
import com.echiceros.system.pooling.*;

/**
 * Comprueba si la cach� cuyo nombre indicamos existe o no. En caso
 * negativo la crea y a�ade las conexiones a bases de datos que indiquemos
 * seg�n la url correspondiente. Utiliza un ODBCConnPool.
 * 
 * La definition tiene el siguiente formato:
 *
 *    <data>
 *      <name>mainDataSource</name>
 *      <limit>20</limit>
 *      <prefix>FCA005-</prefix>
 *      <username>fca005user</username>
 *      <password>Gemma</password>
 *    </data>
 *
 * @author  jv
 * @version 1.0
 */
public class TrsCreateODBCDataSourceCache extends TrsAdapter {

    /** Creates new TrsCreateDataSourceCache */
    public TrsCreateODBCDataSourceCache() {
        super();
    }

    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        String driverClassName;
        String url;
        String cacheName;
        String username;
        String password;
        int limit; 
        Connection con;
        ODBCConnPool pool;
        
        try {
            cacheName = super.definition.getChildTextTrim("name");
            driverClassName = "sun.jdbc.odbc.JdbcOdbcDriver";
            url = "jdbc:odbc:" + super.definition.getChildTextTrim("prefix");
            username =  super.definition.getChildTextTrim("username");
            password =  super.definition.getChildTextTrim("password");
            limit = Integer.parseInt(definition.getChildTextTrim("limit"));
            pool = new ODBCConnPool(cacheName, driverClassName, 
                                    url, username, password, limit);
        }
        catch (SQLException e) {
            throw new TrsException(getClass().getName() + ": " + e);
        }
    }
    
    public static void main(String[] args) throws Exception {
        TrsCreateODBCDataSourceCache trs;
        String xml;
        
        xml = 
             "<data>"+
             "  <name>mainDataSource</name>"+
             "  <limit>20</limit>"+
             "  <prefix>FCA005-</prefix>"+
             "  <username>fca005user</username>"+
             "  <password>Gemma</password>"+
             "</data>";
        
        trs = new TrsCreateODBCDataSourceCache();
        trs.setDefinition(xml);
        trs.execute();
        System.out.println(Cache.getCache("mainDataSource").getSize() +
                           " de un m�ximo de " +
                           Cache.getCache("mainDataSource").getLimit() +
                           ".");
        System.exit(0);
    }
}
