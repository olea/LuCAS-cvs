/*
 * Point.java
 *
 * Created on 7 de febrero de 2002, 10:12
 */

package com.echiceros.graphics.chart;

/**
 * Almacena las coordenadas xyz. Como coordenadas puede guardarse
 * cualquier objeto que implemente la interface Comparable.
 *
 * @author  jv
 */
public class ChartPoint implements java.lang.Comparable {
    Comparable x;
    Comparable y;
    Comparable z;

    public ChartPoint(Comparable x, Comparable y, Comparable z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public Comparable getX() { return x; }
    public Comparable getY() { return y; }
    public Comparable getZ() { return z; }
    
    public Comparable get(int axe) {
        Comparable res;
        
        if (axe == Axe.X) { res = getX(); }
        else if (axe == Axe.Y) { res = getY(); }
        else { res = getZ(); }
        
        return res;
    }
    
    /** pesos: z > x > y. */
    public int compareTo(Object obj) {
        int res;
        ChartPoint other;
        
        other = (ChartPoint) obj;
        res = z.compareTo(other.getZ());
        if (res == 0) {
            res = x.compareTo(other.getX());
        }
        if (res == 0) {
            res = y.compareTo(other.getY());
        }
        
        return res;        
    }

    public String toString() {
        return "ChartPoint (" + x + ", " + y + ", " + z + ")";
    }
}
