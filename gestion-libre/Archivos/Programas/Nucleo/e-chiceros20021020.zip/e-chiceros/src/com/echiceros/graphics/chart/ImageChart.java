/*
 * ImageChart.java
 *
 * Created on 6 de febrero de 2002, 16:55
 */

package com.echiceros.graphics.chart;

import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics.*;
import java.awt.geom.*;

/**
 * Contenedor de la imagen que posee la gr�fica.
 *
 * @author  jv
 */
public class ImageChart {
    /** Holds value of property width. */
    int width;
    
    /** Holds value of property height. */
    int height;
    
    /** Holds value of property axes. */
    Axe[] axes;
    
    /** Lista de puntos a dibujar. */
    ArrayList points;
    
    /** La imagen generada por el �ltimo createImage(). */
    BufferedImage image;
    
    /** Fuente para los labels x. */
    Font fontXLabels;
    
    /** Fuente para los labels y. */
    Font fontYLabels;
    
    /** FontMetrics para fontXLabels */
    FontMetrics fmFontXLabels;
    
    /** FontMetrics para fontYLabels */
    FontMetrics fmFontYLabels;
    
    /** Encargado de dibujar los puntos. */
    Plotter plotter;
    
    /** Creates a new instance of ImageChart */
    public ImageChart() {
        this.axes = new Axe[3];
        points = new ArrayList();
    }
    
    /** Fija el eje indicado.
     *  @param name Nombre del eje.
     *  @param dir  Direcci�n del eje (X, Y, Z).
     *  @param min  M�nimo del eje.
     *  @param max  M�ximo del eje.
     *  @param step Cada cu�ntos elementos queremos una marca en el eje.
     */
    public void setAxeNumeric(String name, int dir,
    double min, double max, double step) {
        axes[dir] = new AxeNumeric(name, min, max, step);
    }
    
    public void setAxeAlpha(String name, int dir, Object[] values) {
        axes[dir] = new AxeAlpha(name, values);
    }
    
    /** Fija un punto. x,y pueden ser cualquier objeto que pueda
     *  ser convertido en double.
     */
    public void addPoint(Comparable x, Comparable y) {
        this.addPoint(x,y,new Double(0.0));
    }
    
    /** Fija un punto. x,y,z pueden ser cualquier objeto que pueda
     *  ser convertido en double.
     */
    public void addPoint(Comparable x, Comparable y, Comparable z) {
        ChartPoint point;
        
        point = new ChartPoint(x, y, z);
        this.points.add(point);
    }
    
    /** Retorna los puntos del chart como un array de CharPoints. */
    public ChartPoint[] getPoints() {
        return (ChartPoint[]) this.points.toArray(new ChartPoint[0]);
    }
    
    /** Fija el plotter encargado de dibujar los puntos. */
    public void setPlotter(Plotter plotter) {
        this.plotter = plotter;
    }
    
    public void createImage() {
        Graphics2D graphics;
        
        image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        graphics = image.createGraphics();
        
        this.createFonts(graphics);
        this.fillBackground(graphics);
        this.drawXAxe(graphics);
        this.drawYAxe(graphics);
        plotter.drawPoints(graphics, getSize(), getInsets(), axes, points);
    }
    
    protected void createFonts(Graphics g) {
        Font f;
        
        f = new Font("Arial", Font.PLAIN, 10);
        fontXLabels = f.deriveFont(AffineTransform.getRotateInstance(Math.PI*.50));
        fmFontXLabels = g.getFontMetrics(fontXLabels);
        fontYLabels = f;
        fmFontYLabels = g.getFontMetrics(fontYLabels);
    }
    
    protected void fillBackground(Graphics2D graphics) {
        graphics.setColor(new Color(255,255,255));
        graphics.fillRect(0,0, getWidth(), getHeight());
    }
    
    protected void drawXAxe(Graphics2D graphics) {
        int y0;              // base de la l�nea.
        Hashtable labsDis;   // Distances de los labels sobre el eje.
        Enumeration labels;  // parejas label / distance
        String label;
        Float distance;
        int axeWidth;        // width del eje
        int x;               // posici�n real del label
        
        y0 = getHeight() - getBottom();
        graphics.setColor(Color.black);
        graphics.setFont(fontXLabels);
        
        graphics.drawLine(getLeft(), y0, getWidth()-getRight(), y0);
        
        labsDis = axes[Axe.X].getLabelsDistances();
        labels = labsDis.keys();
        while (labels.hasMoreElements() == true) {
            label = (String) labels.nextElement();
            distance = (Float) labsDis.get(label);
            axeWidth = getWidth()-getRight()-getLeft();
            x = (int) (axeWidth * distance.floatValue());
            graphics.drawLine(getLeft() + x, y0 - 2, getLeft() + x, y0 + 4);
            graphics.drawString(label, getLeft() + x - 3, y0 + 10);
        }
    }
    
    
    protected void drawYAxe(Graphics2D graphics) {
        Hashtable labsDis;   // Distances de los labels sobre el eje.
        Enumeration labels;  // parejas label / distance
        String label;
        Float distance;
        int axeHeight;       // height del eje
        int y;               // posici�n real del label
        int labelWidth;      // ancho en p�xels del label
        
        graphics.setColor(Color.black);
        graphics.setFont(fontYLabels);
        
        graphics.drawLine(getLeft(), getTop(), getLeft(), getHeight() - getBottom());
        
        labsDis = axes[Axe.Y].getLabelsDistances();
        labels = labsDis.keys();
        while (labels.hasMoreElements() == true) {
            label = (String) labels.nextElement();
            distance = (Float) labsDis.get(label);
            axeHeight = getHeight()-getBottom()-getTop();
            y = getHeight() - getBottom() - (int) (axeHeight * distance.floatValue());
            graphics.drawLine(getLeft()-4, y, getLeft()+3, y);
            labelWidth = fmFontYLabels.stringWidth(label);
            graphics.drawString(label, getLeft()- 4 - 2 - labelWidth, y + 3);
        }
    }
    
    public Dimension getSize() {
        return new Dimension(getWidth(), getHeight());
    }
    
    public Insets getInsets() {
        return new Insets(getTop(), getLeft(), getBottom(), getRight());
    }
    
    /** Getter for property width.
     * @return Value of property width.
     */
    public int getWidth() {
        return this.width;
    }
    
    /** Setter for property width.
     * @param width New value of property width.
     */
    public void setWidth(int width) {
        this.width = width;
    }
    
    /** Getter for property height.
     * @return Value of property height.
     */
    public int getHeight() {
        return this.height;
    }
    
    /** Setter for property height.
     * @param height New value of property height.
     */
    public void setHeight(int height) {
        this.height = height;
    }
    
    /** Distancia entre el bottom de la imagen y la l�nea del eje X. */
    protected int getLeft() {
        return 70;
    }
    
    /** Distancia entre el left de la imagen y la l�nea del eje Y. */
    protected int getBottom() {
        return 70;
    }
    
    /** Distancia entre el right de la gr�fica y el de la imagen. */
    protected int getRight() {
        return 60;
    }
    
    /** Distancia entre el top de la gr�fica y el de la imagen. */
    protected int getTop() {
        return 40;
    }
    
    /** Retorna la imagen. */
    public BufferedImage getImage() {
        return this.image;
    }
    
    static class FrmDemo extends Frame {
        BufferedImage img;
        
        public FrmDemo(BufferedImage img) {
            this.img = img;
        }
        
        public void paint(Graphics g) {
            Graphics2D g2d;
            
            g2d = (Graphics2D) g;
            g2d.drawImage(img, null, 20, 40);
        }
    }
    
    public static void zmain(String[] args) throws Exception {
        ImageChart chart;
        Frame frm;
        double x,y;
        
        chart = new ImageChart();
        chart.setWidth(600);
        chart.setHeight(250);
        chart.setAxeNumeric("Edad", Axe.X, -150, 150, 25);
        chart.setAxeNumeric("Sab", Axe.Y, -50, 100, 15);
        chart.setAxeNumeric("Sueldo", Axe.Z, -10, +10, 1);
        for (int i=-100; i <= 100; i = i + 50) {
            x = (double) i;
            y = -50 + Math.random() * 150;
            chart.addPoint(new Double(x), new Double(y), new Double(-1));
            y = -50 + Math.random() * 150;
            chart.addPoint(new Double(x), new Double(y), new Double(+1));
            y = -50 + Math.random() * 150;
            chart.addPoint(new Double(x), new Double(y), new Double(+2));
            y = -50 + Math.random() * 150;
            chart.addPoint(new Double(x), new Double(y), new Double(+3));
        }
         
        chart.setPlotter(new PlotterBar(false));
        chart.createImage();
        
        frm = new FrmDemo(chart.getImage());
        frm.setBounds(100,100,650,350);
        frm.setBackground(Color.white);
        frm.setVisible(true);
    }
    
    public static void main(String[] args) throws Exception {
        ImageChart chart;
        Frame frm;
        double x,y;
        String[] meses;
        
        meses = new String[] {"Enero", "Febrero", "Marzo", 
                              "Abril", "Mayo", "Junio" };         
                              
        chart = new ImageChart();
        chart.setWidth(400);
        chart.setHeight(250);
        chart.setAxeAlpha("Mes", Axe.X, meses);
        chart.setAxeNumeric("Prec", Axe.Y, 0, 130, 20);
        for (int i=0; i < meses.length; i++) {
           y = Math.random() * 100 + 10;
           chart.addPoint(meses[i], new Double(y), new Integer(0));
           y = Math.random() * 100 + 10;
           chart.addPoint(meses[i], new Double(y), new Integer(1));
           y = Math.random() * 100 + 10;
           chart.addPoint(meses[i], new Double(y), new Integer(3));
        }
         
        chart.setPlotter(new PlotterBar(true));
        chart.createImage();
        
        frm = new FrmDemo(chart.getImage());
        frm.setBounds(100,100,450,350);
        frm.setBackground(Color.white);
        frm.setVisible(true);
    }
}
