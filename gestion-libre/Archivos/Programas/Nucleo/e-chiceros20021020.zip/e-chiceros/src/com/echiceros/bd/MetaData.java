/*
 * TrsGetResultSetMetaData.java
 *
 * Created on 15 de agosto de 2001, 12:32
 */

package com.echiceros.bd;

import java.util.*;
import java.sql.*;
import com.echiceros.system.pooling.*;

/**
 * Permite obtener metainformaci�n sobre una determinada
 * columna de forma m�s o menos c�moda. Ofrece acceso al 
 * nombre de los campos, su tipo, su tama�o, escala y
 * precisi�n.
 *
 * Resulta mucho m�s eficiente utilizar esta clase que
 * el metadata de forma repetida.
 *
 *
 * [ATENCI�N] Los indices en metaV son 0 based, no 1 based como
 *            en los resultsets!!
 *
 * @author  jv
 * @version 
 */
public class MetaData {
    
    /** Almacena la meta en el mismo orden que se ha generado. */
    Vector metaV;

    /** Ofrece acceso directo a la meta, por nombre de columna
      * (ignora may�sculas). 
     */
    Hashtable metaH;
    
    /** Utilizada para almacenar el n�mero de �ndice de columna
     *  asociado al nombre de la misma. �til para aquellos
     *  drivers (como el bridge) que tienen problemas en este punto.
     */
    Hashtable name2index;
    
    /** Almacena la lista de columnMetaDatas que corresponden
     *  a columnas unique (primary keys, en principio). Solo
     *  estar� disponible si se ha generado el meta a partir
     *  de una con y un nombre de tabla, no un resultset.
     */
    Vector pks;
    
    /** Utilizado para inicializar las estructuras internas. */
    protected MetaData() {
        metaV = new Vector();
        metaH = new Hashtable();
        name2index = new Hashtable();
        pks = new Vector();
    }
    
    /** Obtiene la meta de una tabla determinada. */
    public MetaData(Connection con, String tableName) {
        this();
        
        Statement stmt;
        ResultSet rs;
        
        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT * FROM " + tableName);
            this.executeMetaData(rs, tableName);
            rs.close();
            stmt.close();
            this.executePKFinder(con, tableName);
        }
        catch (SQLException e) {
            System.err.println(e);
        }
    }
    
    /** Obtiene la meta a partir de un resustset. NO obtiene
        informaci�n sobre claves primarias.
     */
    public MetaData(ResultSet rs) {
        this();
        
        try {
            this.executeMetaData(rs, null);
        }
        catch (SQLException e) {
            System.err.println(e);
        }
    }
    
    /** Retorna una instancia de la clase. Es preferible a 
     *  crearla directamente porque de esta forma podemos
     *  reciclarlas.
    */
    public static MetaData getInstance(Connection con, String tableName) {
        Cache cache;
        MetaData meta;
        
        meta = (MetaData) Cache.createCache("MetaDatas").get(tableName, false);
        if (meta == null) {
            meta = new MetaData(con,tableName);
            Cache.getCache("MetaDatas").put(tableName, meta);
        }
        
        return meta;
    }
    
    /** Retorna una instancia de la clase. Es preferible a 
     *  crearla directamente porque de esta forma podemos
     *  reciclarlas.
    */
    public static MetaData getInstance(ResultSet rs) {
        return new MetaData(rs);
    }
    
    /** Averigua la metainformaci�n sobre cada una de las columnas
     *  del resultset. El par�metro de tabla es secundario: si vale
     *  null, intentar� averiguarlo. Muchos drivers no soportan esta
     *  funcionalidad.
     */
    protected void executeMetaData(ResultSet rs, String tableName) 
    throws SQLException {
        ResultSetMetaData metaRs;
        ColumnMetaData metaColumn;
        boolean isAlfa;
        String rsTableName;
        
        metaRs = rs.getMetaData();
        for (int i=1; i <= metaRs.getColumnCount(); i++) {
          rsTableName = metaRs.getTableName(i);
          if (((rsTableName == null) || (rsTableName.length()==0)) && 
               (tableName != null)) {
            rsTableName = tableName;
          }
          isAlfa = ((metaRs.getColumnType(i) == java.sql.Types.CHAR) ||
                    (metaRs.getColumnType(i) == java.sql.Types.VARCHAR) ||
                    (metaRs.getColumnType(i) == java.sql.Types.LONGVARCHAR) );
          
          metaColumn = new ColumnMetaData(
                             rsTableName,
                             metaRs.getColumnName(i),
                             metaRs.getColumnType(i),
                             metaRs.getColumnTypeName(i),
                             metaRs.getPrecision(i),
                             metaRs.getScale(i),
                             isAlfa
                           );
          this.metaV.addElement(metaColumn);
          this.metaH.put(metaColumn.getName().toUpperCase(), metaColumn);
          if (name2index.get(metaColumn.getName().toUpperCase()) == null) {
              this.name2index.put(metaColumn.getName().toUpperCase(), 
                                  new Integer(i));
          }
        }            
    }
    
    /** Obtiene las claves primarias de la tabla indicada. */
    protected void executePKFinder(Connection con, String tableName) 
    throws SQLException {
        DatabaseMetaData dbMeta;
        ResultSet rs;
        String columnName;
        ColumnMetaData clMeta;
        
        dbMeta = con.getMetaData();
        rs = dbMeta.getPrimaryKeys(null, null, tableName);
        while (rs.next() == true) {
            columnName = rs.getString("COLUMN_NAME");            
            if (columnName != null) {
                clMeta = this.getColumnMetaData(columnName);
                clMeta.setPrimaryKey(true);
                this.pks.removeElement(clMeta);
                this.pks.addElement(clMeta);
            }
        }
        if (this.pks.size() == 0) {
            executeIndexFinder(con, tableName);
        }
    }
    
    /** Obtiene las claves primarias de la tabla indicada con un 
     *  criterio m�nimo (�ndices no �nicos). Debe ser utilizado solo
     *  si executePKFinder no tiene �xito.
     */
    protected void executeIndexFinder(Connection con, String tableName) 
    throws SQLException {
        DatabaseMetaData dbMeta;
        ResultSet rs;
        String columnName;
        ColumnMetaData clMeta;
        
        dbMeta = con.getMetaData();
        rs = dbMeta.getIndexInfo(null, null, tableName, true, false);
        while (rs.next() == true) {
            columnName = rs.getString("COLUMN_NAME");
            
            if (columnName != null) {
                clMeta = this.getColumnMetaData(columnName);
                clMeta.setPrimaryKey(true);
                this.pks.removeElement(clMeta);
                this.pks.addElement(clMeta);
            }
        }
    }
    
    /** Retorna una enumeraci�n de ColumnMetaDatas con la informaci�n
     *  almacenada.
     */
    public Enumeration getColumnMetaDatas() {
        return this.metaV.elements();
    }
    
    /** Retorna la metainformaci�n de la la columna cuyo �ndice se indica. 
      * [ATENCI�N] Los indices en metaV son 0 based, no 1 based como
      *            en los resultsets!!
      */
    public ColumnMetaData getColumnMetaData(int i) {
      return (ColumnMetaData) metaV.elementAt(i);
    }
    
    /** Retorna la metainformaci�n de la la columna cuyo nombre se indica. */
    public ColumnMetaData getColumnMetaData(String columnName) {
      ColumnMetaData meta;
      
      meta = (ColumnMetaData) metaH.get(columnName.toUpperCase());
      return meta;
    }
        
    /** Retorna las ColumnMetaData de las columnas que
     *  son claves primarias.
     */
    public Enumeration getPrimaryKeysMetaData() {
        return pks.elements();
    }
    
    /** Retorna los nombres de las columnas que son claves primarias. */
    public Enumeration getPrimaryKeyNames()  {
        Vector res;
        ColumnMetaData clMeta;
        Enumeration metaEnum;
        
        res = new Vector();
        for (int i=0; i < pks.size(); i++) {
            clMeta = (ColumnMetaData) pks.elementAt(i);
            res.addElement(clMeta.getName());
        }
        
        return res.elements();
    }
    
    /** @param columnName nombre de la columna cuyo �ndice en el ResultSet
     *         queremos averiguar.
     *  @returns el �ndice que ocupa en el resultset <b>LA PRIMERA</b> 
     *           aparici�n del columnName indicado.
     */
    public int getIndex(String columnName) {
      Integer res;

      res = (Integer) name2index.get(columnName.toUpperCase());

      return (res == null) ? -1 : res.intValue();
    }
    
    public int getColumnCount() {
      return metaV.size();
    }

    public static final int UNKNOWN = 0;
    public static final int IS_PK   = +1;
    public static final int NON_PK  = -1;
    
    public static class ColumnMetaData {
        String table;
        String name;
        int type;
        String typeName;
        int size;
        int precision;
        int scale;
        boolean isAlfa;
        int primaryKey;
        
        public ColumnMetaData(String table, String name, int type, 
                        String typeName, int precision, int scale,
                        boolean isAlfa) {
          this.table = (table==null) ? null : table.toUpperCase();
          this.name = (name == null) ? null : name.toUpperCase();
          this.type = type;
          this.typeName = typeName;
          this.precision = precision;
          this.scale = scale;
          this.isAlfa = isAlfa;
          this.primaryKey = UNKNOWN;
        }
        
        public String getTable() { return table; }
        public String getName() { return name; }
        public int getType() { return type;}
        public String getTypeName() { return typeName; }
        public int getPrecision() { return precision;}
        public int getScale() { return scale; }
        public boolean isAlfa() { return isAlfa;}
        
        public void setPrimaryKey(boolean value) {
            primaryKey = (value == false) ? NON_PK : IS_PK;
        }
        
        public String toString() {
            return table + "." + name + " [" +
                   typeName + " (" + precision + ", " + scale + "), " +
                   ((isAlfa) ? "ALFA" : "NO-ALFA") +  
                   ((primaryKey == IS_PK) ? " (Primary Key)" : "") + 
                   "]";
        }
    }
    
    public static void main(String[] args) throws Exception {
        MetaData meta;
        Connection con;
        Enumeration enumMetas;
        ColumnMetaData columnMeta;
        
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        con = DriverManager.getConnection("jdbc:odbc:fca005-0");
        
        meta = new MetaData(con, "fca005");
        
        enumMetas = meta.getColumnMetaDatas();
        while (enumMetas.hasMoreElements() == true) {
            columnMeta = (ColumnMetaData) enumMetas.nextElement();
            System.out.println(columnMeta);
        }
    }
}
