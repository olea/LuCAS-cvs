package com.echiceros.www.tools;

import java.util.*;
import com.echiceros.lang.*;

public class URLNormalizer {
    
    /** Holds value of property root. */
    protected String root;    

    /** Holds value of property file. */
    protected String file;
    
    /** Compone la lista de par�metros. */
    protected MultivalueHashtable params;
    
    public URLNormalizer(String root, String file) {

        this.params = new MultivalueHashtable();
        this.normalize(root, file);
    }

    protected void normalize(String proot, String pfile) {
      String root;
      String file;
      int pos;
      
      root = proot.replace('\\', '/'); 
      file = pfile.replace('\\', '/');
      // Elimina un posible "/" final en root.
      if (root.endsWith("/") == true) {
          root = root.substring(0, root.length()-1);
      }
      // Elimina el ./ al inicio
      while (file.startsWith("./") == true) {
          file = file.substring("./".length());
      }
      // Modificamos la carpeta mientras el patr�n comienza por ../
      while (file.startsWith("../") == true) {
            file = file.substring("../".length());
            root = root.substring(0, (root.lastIndexOf("/")==-1) ? 0 : root.lastIndexOf("/"));
      }
      // A�adimos al path el patr�n indicado.
      pos = file.lastIndexOf('/');
      if (pos != -1) {
          root = root + "/" + file.substring(0,pos);
          file = file.substring(pos+1);
      }
      // Movemos la parte correspondiente al file que haya en el root.
      if (root.indexOf("//") > -1) {
          pos = root.indexOf("/", root.indexOf("//")+2);
          if (pos > -1) {
              file = (file.length()==0) ? 
                     root.substring(pos) : root.substring(pos) + "/" + file;
              root = root.substring(0,pos);
          }
      }

      this.root = root;
      this.file = file;
    }
    
    /** Getter for property root.
     * @return Value of property root.
     */
    public String getRoot() {
        return root;
    }
    
    /** Getter for property file.
     * @return Value of property file.
     */
    public String getFile() {
        return file;
    }
    
    /** @returns las parejas par�metro/valor. Por ejemplo:
     *           nombre=javi&nick=ciberado.
     */
    public String getParams() {
        StringBuffer res;
        Iterator keys;
        Iterator values;
        String name, value;
        
        res = new StringBuffer();
        keys = this.params.keys();
        
        while (keys.hasNext() == true) {
            name = (String) keys.next();
            values =  this.params.get(name);
            
            while (values.hasNext() == true) {
                value = (String) values.next();
                res.append(name + "=" + value + "&");
            }
        }
        
        if (res.length() > 0) {
            res.setLength(res.length()-1);
        }
        
        
        return res.toString();
    }
        
    /** Agrega un par�metro a la url que se esta componiendo. */
    public void addParam(String name, String value) {
        String encodedValue;
        
        encodedValue = java.net.URLEncoder.encode(value);
        this.params.put(name, encodedValue);
    }
    
    /** Retorna la suma de root + file + params. */
    public String getURL() {
        String url;
        String paramString;
        
        if ((root.endsWith("/") == true) && 
            (file.startsWith("/") == true)) {
          url = this.root + this.file.substring(1);
        }
        else if ((root.endsWith("/") == false) && 
            (file.startsWith("/") == false) &&
            (file.length() != 0)) {
          url = this.root + "/" + this.file;
        }
        else {
          url = this.root + this.file;
        }
        
        paramString = this.getParams();
        if (paramString.length() > 0) {
            url = url + "?" + paramString ;
        }
        
        return  url;
    }
    
    
    public String toString() {
        return getRoot() + "#" + getFile();
    }
        
    protected static void test(String root, String file) {
        System.out.println("Comprobando: " + root + "#" + file + ".");
        System.out.println(new URLNormalizer(root, file));
    }
    
    public static void main(String[] args) throws Exception {
        URLNormalizer norm;
        
        test("http://www.wop.com/test/sip/", "../index.html");
        test("c:/archivos de programa", "aok2/empires2.exe");
        test("c:/archivos de programa", "../empires2.exe");
        test("c:/archivos de programa", "../../empires2.exe");
        test("c:/archivos de programa", "./empires2.exe");
        test("c:/archivos de programa", "./../empires2.exe");        
        test("http://www.wop.com/test", "./../nexor/index.html");
        test("http://www.wop.com/test/index.html",  "");
        
        System.out.println("***********************************************");

        norm = new URLNormalizer("http://127.0.0.1:8080/examples/jsp/snp", "snoop.jsp");
        norm.addParam("id", "384732AK34");
        norm.addParam("hashcode", "DKJDF34KLJ322823JKJHKJ23H4HKJ23H42");
        
        System.out.println();
        
        test("http://127.0.0.1/wop", "index.html");
        norm = new URLNormalizer("http://127.0.0.1/wop", "index.html");
        norm.addParam("wop", "xxx");
        norm.addParam("wap", "yyy");
        System.out.println(norm);
        
        System.out.println(norm.getURL());
        
        System.exit(0);
        java.net.URL url;
        java.net.HttpURLConnection con;
        java.io.BufferedReader in;
        String line;
        
        url = new java.net.URL(norm.getURL());
        con = (java.net.HttpURLConnection) url.openConnection();
        in = new java.io.BufferedReader(new java.io.InputStreamReader(con.getInputStream()));
        do {
            line = in.readLine();
            if (line != null) {
                System.out.println(line);
            }
        } while (line != null);
        con.disconnect();
    }
}