/*
 * OutputWriterStream.java
 *
 * Created on 21 de noviembre de 2001, 16:32
 */

package com.echiceros.io;


import java.io.*;

/**
 *
 * Permite enlazar un outputstream con un writer, de manera
 * inversa a OutputStreamReader. Muy �til en los servlets que
 * ya han utilizado el writer y por lo tanto no pueden acceder
 * al stream.
 *
 * @author jv
 */
public class OutputWriterStream extends java.io.OutputStream {

    private java.io.Writer out = null;
    
    /** Creates new OutputWriterStream */
    public OutputWriterStream(Writer out) {
        this.out = out;
    }

    public void close() throws java.io.IOException {
        out.close();
    }
    
    public void flush() throws java.io.IOException {
        out.flush();
    }
    
    public void write(byte[] values) throws java.io.IOException {
        out.write(new String(values).toCharArray());
    }
    
    public void write(int param) throws java.io.IOException {
        out.write(param);
    }
    
    public void write(byte[] values, int param, int param2) throws java.io.IOException {
        String aux;
        
        aux = new String(values).substring(param,param2-param);
        out.write(aux.toCharArray());
    }
    
}
