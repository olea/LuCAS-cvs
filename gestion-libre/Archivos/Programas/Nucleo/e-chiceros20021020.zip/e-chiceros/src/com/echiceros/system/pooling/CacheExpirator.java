/*
 * CacheExpirator.java
 *
 * Created on 30 de octubre de 2001, 11:28
 */

package com.echiceros.system.pooling;


import java.util.*;

/**
 * Este proceso recorre cada cierto tiempo todas la cach�s tratando 
 * de liberar los elementos caducados.
 *
 * Agrega un handler de shutdown que invoca el destroy de cada 
 * cach� cuando finaliza la aplicaci�n.
 *
 * @author  jv
 */
public class CacheExpirator implements Runnable {

    /** Tiempo que estar� durmiendo el expirador entre limpieza y
     *  limpieza. 5 minutos.
     */
    static final int SLEEP_TIME = 1000 * 60 * 1;
    
    /** Instancia del cacheExpirator. */
    static CacheExpirator defaultExpirator = null;

    Thread runner;
    
    /** Creates new CacheExpirator */
    protected CacheExpirator() {
        runner = null;
    }

    /** Retorna la instancia del expirator. Su estado inicial es
     *  desactivado (hay que invocar start si no se ha hecho antes).
     */
    public static CacheExpirator getDefault() {
        if (defaultExpirator == null) {
            Runtime.getRuntime().addShutdownHook(new CacheExpirator.ShutdownHook());
            defaultExpirator = new CacheExpirator();
        }
        
        return defaultExpirator;
    }
    
    /** Inicia el servicio. */
    public void start() {
        if (runner == null) {
            // System.out.println("[DEBUG] expirator: Iniciando expirador.");
            runner = new Thread(this);
            runner.setPriority(Thread.MIN_PRIORITY);
            runner.start();
        }
    }
    
    public void stop() {
        runner = null;
    }
    
    public void run() {
        Iterator keys;
        Cache currentCache;
        
        while (runner != null) {
           try { runner.sleep(SLEEP_TIME); }
           catch (InterruptedException e) {}
           keys = Cache.getDefaultCache().getIdentifiers();
           while (keys.hasNext() == true) {
               currentCache = Cache.getCache(keys.next());
               currentCache.expire();
           }
        }
    }
    
    
    /** Recorre todas las caches invocando sus m�todos destroy(). */
    static class ShutdownHook extends Thread {
        public void run() {
            Iterator keys;
            Cache currentCache;

            keys = Cache.getDefaultCache().getIdentifiers();
            while (keys.hasNext() == true) {
               currentCache = Cache.getCache(keys.next());
               currentCache.destroy();
            }
        }
    }
}
