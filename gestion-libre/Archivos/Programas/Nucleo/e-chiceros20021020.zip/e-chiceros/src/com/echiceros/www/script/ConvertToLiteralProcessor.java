package com.echiceros.www.script;



import java.util.*;
import java.io.*;
import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import com.echiceros.io.*;

/** �til para convertir un texto cualquiera en literales.
 *  Entrecomilla cada l�nea del stream de entrada y le agrega un +
 *  (cuidado con la �ltima).
 *  Utiliza el car�cter indicado como par�metro quoteChar (" por defecto).
 */
public class ConvertToLiteralProcessor extends StreamProcessor {
    
    public ConvertToLiteralProcessor() {
        super();
    }
    
    public ConvertToLiteralProcessor(Reader in, Writer out) {
        super(in,out);
    }
    
    public void transform()  throws IOException {
        String quoteChar;
        
        quoteChar = this.getParam("quoteChar");
        if (quoteChar == null) {
            quoteChar = "\"";
        }
        transformImp(quoteChar);
    }

    /** Realiza la operaci�n de delimitaci�n, utilizando para
     *  ello el car�cter indicado como par�metro.
     *  @param quoteChar car�cter de delimitaci�n.
     */
    public void transformImp(String quoteChar)  throws IOException {
        String line;
        int pos;
        BufferedReader reader;
        
        reader = new BufferedReader(this.in);
        do {
            line = reader.readLine();
            if (line != null) {
                pos = indexOfFirstNonSpace(line);
                pos = (pos == -1) ? 0 : pos;
                line = line.substring(0, pos) +
                       quoteChar +
                       line.substring(pos) +
                       quoteChar + " +";
                out.write(line + "\n");
            }
        } while (line != null);               
        
    }
    
    /** @returns la posici�n del primer car�cter diferente de espacio. 
     *           -1 si no lo encuentra. 
     */
    protected int indexOfFirstNonSpace(String line) {
        int idx;
        
        idx = 0;
        while ((idx < line.length()) && (line.charAt(idx) == ' ')) {
            idx = idx + 1;
        }
        
        return (idx == line.length()) ? -1 : idx;
    }

}