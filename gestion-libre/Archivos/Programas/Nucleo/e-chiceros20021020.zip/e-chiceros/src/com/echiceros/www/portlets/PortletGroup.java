/*
 * PortletGroup.java
 *
 * Created on 12 de julio de 2001, 1:46
 */

package com.echiceros.www.portlets;

import java.util.*;

/**
 *  Esta clase implementa la funcionalidad necesaria para almacenar
 *  una colecci�n de portlets que deben, en principio, presentarse
 *  de forma agrupada.
 *
 *  Permite ordenarlos por t�tulo o fecha, as� como presentar un
 *  n�mero finito de los mismos o solo aquellos que se encuentren
 *  en un rango de tiempo determinado.
 *
 *  [ATENCI�N] Clase deprecada. Mantenimiento discontinuado ;).
 * 
 * @author  jv
 * @version 1.0
 */
public class PortletGroup {

    /** Ning�n orden en especial. */
    public static final int SORTBY_NOTHING = -1;
    /** Ordenados alfab�ticamente por t�tulo. */
    public static final int SORTBY_TITLE_ASC = 1;
    /** Ordenados alfab�ticamente por t�tulo. */
    public static final int SORTBY_TITLE_DESC = 2;
    /** Ordenados por fecha. */
    public static final int SORTBY_DATE_ASC = 3;
    /** Ordenados por fecha. */
    public static final int SORTBY_DATE_DESC = 4;
    
    /** No se desea especificar un l�mite de portlets... */
    public static final int UNDEFINED = -1;
       
    
    /** Nombre del grupo. De esta forma se podr� hacer referencia
     *  a �l desde distintas situaciones.
     */
    private String groupName;
    
    /** Holds value of property portlets. */
    private Vector portlets;
    
    
    
    /** Creates new PortletGroup */
    public PortletGroup() {
        super();
        this.portlets = new Vector();
    }

    /** Getter for property groupName.
     * @return Value of property groupName.
     */
    public String getGroupName() {
        return groupName;
    }
    
    /** Setter for property groupName.
     * @param groupName New value of property groupName.
     */
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
    
    /** Indexed getter for property portlets.
     * @param index Index of the property.
     * @return Value of the property at <CODE>index</CODE>.
     */
    public Portlet getPortlet(int index) {
        return (Portlet) portlets.elementAt(index);
    }
    
    /** Indexed setter for property portlets.
     * @param index Index of the property.
     * @param portlets New value of the property at <CODE>index</CODE>.
     */
    public void setPortlet(int index, Portlet portlet) {
        this.portlets.setElementAt(portlets, index);
    }
    
   
    /** Agrega un portlet. */
    public void addPortlet(Portlet portlet) {
        this.portlets.addElement(portlet);
    }
    
    /** Crea un nuevo portlet y lo agrega. */
    public void addPortlet(String sourcePath, int topMaxLength) {
        Portlet portlet;
        
        portlet = new Portlet(sourcePath, topMaxLength);
        this.addPortlet(portlet);
    }
    
    /** Crea un nuevo portlet a partir de una conexi�n al recurso 
     *  y lo agrega al grupo.
     */
    public void addPortlet(java.net.URLConnection con, 
                           String sourcePath,
                           int topMaxLength) 
    {
        Portlet portlet;
        
        portlet = new Portlet(con, sourcePath, topMaxLength);
        this.addPortlet(portlet);
     }
    
    /** Genera el html necesario para presentar los portlets. 
     *  Utiliza la ordenaci�n actual del vector, pero permite
     *  especificar un n�mero m�ximo de portlets y un intervalo
     *  de fechas.
     *
     *  @param appendBefore se agregara antes de cada portlet.
     *  @param appendAfter  se agregara a continuacion de cada portlet.
     *  @param howMany cuantos portlets queremos (o UNDEFINED).
     *  @param orderBy orden a imponer (o ORDERBY_NOTHING).
     *  @param dateFrom a partir de que fecha (O UNDEFINED).
     *  @param dateUntil hasta que fecha (o UNDEFINED).
     *
     */
    public String getHtml(String appendBefore, String appendAfter,     
                          int howMany, int sortBy,
                          int dateFrom, int dateUntil) { 
        StringBuffer res;
        int idx; 
        int count;
        Enumeration portlets;
        Portlet current;
        
        res = new StringBuffer();
        
        idx = 0;
        count = 0;
        portlets = this.getPortlets(howMany, sortBy, dateFrom, dateUntil);
        while (portlets.hasMoreElements() == true) {
          current = (Portlet) portlets.nextElement();
          res.append(appendBefore);
          res.append(current.getHtml());
          res.append(appendAfter);
        }
        
        return res.toString();
    }
    
    /** Retorna una enumeraci�n con todos los portlets del grupo
     *  que cumplen el criterio indicado.
     *
     *  @param howMany cuantos portlets queremos (o UNDEFINED).
     *  @param orderBy orden a imponer (o ORDERBY_NOTHING).
     *  @param dateFrom a partir de que fecha (O UNDEFINED).
     *  @param dateUntil hasta que fecha (o UNDEFINED).
     *
     */
    public Enumeration getPortlets(int howMany, int sortBy,
                                   int dateFrom, int dateUntil) { 
        Vector res;
        int idx; 
        int count;
        Portlet current;
        
        res = new Vector();
        
        idx = 0;
        count = 0;
        while (((howMany == UNDEFINED) || (count < howMany)) &&
                (idx < portlets.size()))
        {
            current = (Portlet) portlets.elementAt(idx);
            if (((dateFrom == UNDEFINED) || (current.getDate()>=dateFrom)) &&
                ((dateUntil == UNDEFINED) || (current.getDate()<=dateUntil)))
            {  res.addElement(current);
               count = count + 1;
            }
            
            idx = idx +1;
        }
        
        if (sortBy != SORTBY_NOTHING) {
          java.util.Collections.sort(res, new Portlet.PortletComparator(sortBy));
        }
        return res.elements();
    }
        
    
    public static void main(String[] args) {
       PortletGroup group;
       String name;
       
       group = new PortletGroup();
       name = "/usr/local/tomcat4b5/webapps/sinnombre/"+
                        "test/portlets/portlet";
       
       group.addPortlet(name+"1.jsp", 180);
       group.addPortlet(name+"2.jsp", 180);
       group.addPortlet(name+"3.jsp", 180);
       group.addPortlet(name+"4.jsp", 180);
       group.addPortlet(name+"5.jsp", 180);
       group.addPortlet(name+"6.jsp", 180);
       
       System.out.println(group.getHtml("<tr><td>", "</td></tr>", 
                                        5, SORTBY_NOTHING,
                                        UNDEFINED, UNDEFINED));
    }
       
}
