/*
 * ServletTools.java
 *
 * Created on 4 de septiembre de 2001, 18:41
 */

package com.echiceros.www.tools;

import java.util.*;
import javax.servlet.http.*;

/**
 * Esta clase ofrece una serie de servicios enfocados a facilitar
 * la implementaci�n de servlets y jsps. 
 *
 * @author  jv
 * @version 1.0
 */
public class ServletTools {

    /** Retorna el nombre de la aplicaci�n de la request (primera carpeta 
     *  del path de la misma.
     */
    public static String getAppName(HttpServletRequest request) {
        String url;
        String appName;
        
        url = getAppURL(request);
        appName = url.substring(url.lastIndexOf("/")+1);
        
        return appName;
    }

    /** Calcula la URL de la aplicaci�n, por ejemplo:
     *
     *    http://www.e-chiceros.com:8888/reuters
     *
     *  @param request La request de la jsp o el servlet que desea
     *         conocer la url.
     *  @returns La URL de aplicaci�n correspondiente a dicha request.
     */
    public static String getAppURL(HttpServletRequest request) {
        String url;
        int idx;
        
        url = javax.servlet.http.HttpUtils.getRequestURL(request).toString();
        idx = url.indexOf('/', "http://".length() + 1);
        idx = url.indexOf('/', idx + 1);
        
        return url.substring(0, idx);
    }
       
    /** @returns la url hasta el nivel de �ltima carpeta. Por ejemplo,
     *           http://xxx/yyy/zzz/wop.xml --> http://xxx/yyy/zzz
     *           Se basa en la existencia de un punto en el nombre del
     *           recurso para decidir si la url termina con un archivo
     *           o no. Es decir, http://xxx/yyy/zzz retornar� la misma
     *           url.
     */
    public static String getRequestFolder(HttpServletRequest request) {
        String res;
        String url;
        
        url = javax.servlet.http.HttpUtils.getRequestURL(request).toString();
        
        return getRequestFolder(url);
    }
    
    /** @returns la url hasta el nivel de �ltima carpeta. Por ejemplo,
     *           http://xxx/yyy/zzz/wop.xml --> http://xxx/yyy/zzz
     *           Se basa en la existencia de un punto en el nombre del
     *           recurso para decidir si la url termina con un archivo
     *           o no. Es decir, http://xxx/yyy/zzz retornar� la misma
     *           url.
     */
    public static String getRequestFolder(String url) {
        String res;
        String urlSpec;

        urlSpec = url.replace('\\', '/');
        if (urlSpec.lastIndexOf('/') > urlSpec.lastIndexOf('.')) {
            res = urlSpec;
        }
        else {
            res = urlSpec.substring(0,urlSpec.lastIndexOf('/'));
        }
        
        return res;
    }
    
    /**  @param resource El path del recurso a convertir en absoluto. 
     *   @param request  La request utilizada.
      *  @returns El recurso indicado convertido en una URL absoluta. 
     */
    public static String getAbsolutePath(String resource, HttpServletRequest request) {
        String res;
        
        if (resource.startsWith("http:") == true) {
            res = resource;
        }
        else if (resource.startsWith("/") == true) {
            res = ServletTools.getAppURL(request) + resource;
        }
        else {
            res = ServletTools.getRequestFolder(request) + "/" + resource;
        }

        return res;
    }

    /** @param una url absoluta (http://www.google.com/wop/index.html
     *  @returns la direci�n f�sica del recurso indicado (c:/wwwroot/index.html).
     */
    public static String getRealPathFromURL(String url, HttpServletRequest request) {
        String res;
        String appURL;
        String resourcePath;
        
        appURL = getAppURL(request);
        resourcePath = url.substring(appURL.length());
        
        return request.getRealPath(resourcePath);
    }
    
    /** Convierte un path absoluto en una url absoluta de la webapp a la
     *  que pertenece el request.
     *
     *  @param path Path absoluto del recurso.
     *  @parma request request de la webapp.
     *  @returns url absoluta correspondiente al path.
     */
    public static String getURLFromPath(String path, HttpServletRequest request) {
        String res;
        String appRootPath;
        
        appRootPath = request.getRealPath("/");
        res = path.substring(appRootPath.length());
        res = getAppURL(request) + "/" + res;
        
        return res;
    }
    
    /** Elimina todo el contenido de la sesi�n del usuario. 
     *  @param request El request con la sesi�n. 
     */
    public static void removeSession(HttpServletRequest request) {
        HttpSession session;
        Enumeration enum;
        String name;
        
        session = request.getSession();
        enum = session.getAttributeNames();
        while (enum.hasMoreElements() == true) {
            name = (String) enum.nextElement();
            session.removeAttribute(name);
        }
    }
    
    public static void main(String[] args) throws Exception {
        System.out.println(
          getRequestFolder(
             "http://127.0.0.1:8080/vincere/introduccion/news/presentation.xsl.jsp"));
    }
}
