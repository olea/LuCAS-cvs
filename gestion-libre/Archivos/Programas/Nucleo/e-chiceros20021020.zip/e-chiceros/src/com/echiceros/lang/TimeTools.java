/*
 * TimeTools.java
 *
 * Created on 31 de enero de 2002, 16:11
 */

package com.echiceros.lang;

import java.util.*;
import java.text.*;

/**
 * Diversas herramientas para trabajar sobre el tiempo de una
 * forma c�moda.
 *
 * @author  jv
 */
public class TimeTools {

    
  static java.text.SimpleDateFormat shortDateFormat = null;
  static java.text.SimpleDateFormat longDateFormat = null;
  
  public static long getShortTime(Date date) {
      if (shortDateFormat == null) {
          shortDateFormat = new SimpleDateFormat("yyyyMMdd");
      }
      
      return Integer.parseInt(shortDateFormat.format(date));
  }

  public static long getLongTime(Date date) {
      if (longDateFormat == null) {
          longDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
      }
      
      return Long.parseLong(longDateFormat.format(date));
  }
  
  public static void main(String[] args) {
      System.out.println(getShortTime(new Date()));
      System.out.println(getLongTime(new Date()));
  }
}
