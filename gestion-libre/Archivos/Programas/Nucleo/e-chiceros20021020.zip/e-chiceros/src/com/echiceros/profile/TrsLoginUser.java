/*
 * TrsLoginUser.java
 *
 * Created on 19 de febrero de 2002, 16:08
 */

package com.echiceros.profile;

import java.io.*;
import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.system.pooling.*;
import com.echiceros.lang.StringTools;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;
import com.echiceros.system.*;

/**
 * Contrasta la definici�n con la base de datos para comprobar
 * si un usuario existe realmente y su password corresponde
 * con la indicada.
 *
 * El formato de definici�n esperado es:
 *
 *      <data>
 *        <cache>datasourcename</cache>
 *        <storexpath>//coco:9998/webapps/vincere/rsessions/3kj34jka</storexpath>
 *        <username>ciberado</username> 
 *        <password>Glorita</properties>
 *      </data>
 *
 *  El elemento cach� es opcional. 
 *  Si se especifica storexpath conectar� con el servidor de 
 *  configuraci�n y almacenar� bajo el mismo la propiedad username.
 *  Por ejemplo, en el caso anterior quedar�a
 *
 *       /webapps/vincere/resessions/dkj34jka/username == javito
 * 
 *  En caso de que el username/password sea correcto retornar� un documento
 *  con la trustedkey de la contrase�a (que puede utilizarse para confirmar
 *  que el usuario est� ya validado). Es muy importante que dicha key no
 *  llegue al documento visible por el usuario. 
 *
 *      <transactionresponse>
 *       <type>success</type>
 *       <data>
 *          <trustedkey>qQWqoYeiCMqmKaQA</trustedkey>
 *       </data>
 *     </transactionresponse>
 *
 *  Si por el contrario no encontramos el usuario o su password no
 *  es correcto la salida ser�:
 *
 *           <serviceResponse>
 *             <type>error</type>
 *             <data>
 *               <code>1000</code>
 *               <description>Login failed.</description>
 *             </data>
 *           </serviceResponse>
 *     
 *
 *  La transacci�n tambi�n fallar� si no se indican los par�metros
 *  username y password (c�digos 1010 y 1020 respectivamente).
 *
 * @author  jv
 */
public class TrsLoginUser extends com.echiceros.bd.trs.TrsAdapter {
    
    /** Creates a new instance of TrsLoginUser */
    public TrsLoginUser() {
        super();
    }
    
    public String getSQL() {
        String sql;
        
        sql = "SELECT * FROM userinfo " + 
              "WHERE username='" + getParam("username") + "'";
        
        return sql;
    }
    
    /** Comprueba que los par�metros de entradas sean aceptables. */
    protected void checkParameters() throws IllegalArgumentException {
        Category.getInstance(getClass()).debug(
            "Username: " + getParam("username") + 
            ", Password: " + getParam("password") + ".");
        if (this.getParam("username") == null) {
            throw new IllegalArgumentException(
              "[1010] username is a mandatory parameter.");
        }
        if (this.getParam("password") == null) {
            throw new IllegalArgumentException(
              "[1011] password is a mandatory parameter.");
        }
    }
    
    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        String cacheName;
        Cache cache = null;
        Connection con = null;
        String result = null;
        String errCode;
        ConfigEngine localConfig;
        ConfigClient client;
        String storexpath;
                
        try {           
          checkParameters();
          // Ejecutamos la transacci�n.
          cacheName = definition.getChildText("cache");
          cache = CacheFinder.getInstance().getCacheWithTable(cacheName, "userinfo");
          con = (Connection) cache.get(true);
          result = this.executeImp(con);
          // si se ha completado con �xito la almacenamos en la configuraci�n.
          storexpath = this.getParam("storexpath");
          if ((storexpath != null) && (result.indexOf("<type>success</type>") != -1)) {              
              ConfigClient.setPropertyByURL(storexpath+"/username", getParam("username"));
          }
        }
        catch (IllegalArgumentException e) {
            errCode = StringTools.extract(e.getMessage(), "[", "]");
            result = TransactionEngine.createErrorXML(errCode, e.toString());
        }
        catch (SQLException e) {
            Category.getInstance(getClass()).warn("Error: " + e.getMessage());
            throw new TrsException(e.getMessage());
        }
        finally {
          write(result);
          if (con != null) { 
              cache.put(con); 
          }
        }
    }
    
    /** Ejecuta la consulta. 
     *  @returns el xml de respuesta.
     */
    public String executeImp(Connection con) throws SQLException {
        String result;
        boolean success;
        Statement stmt = null;
        ResultSet rs = null;
        String defDigest = null;
        String realDigest = null;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(this.getSQL());
        if (rs.next() == true) {
            realDigest = rs.getString("passDigest");
            defDigest = StringTools.fastDigest(this.getParam("password"), 
                                               realDigest.length());
            if (realDigest.equals(defDigest) == true) {
                success = true;
            } else {
                success = false;
            }
        } else {
            success = false;
        }
        if (success == true) {
            result = TransactionEngine.createSuccessXML(
                        "   <trustedkey>" + realDigest + "</trustedkey>\n");
        } else {
            result = TransactionEngine.createErrorXML("1000", "Login Failed.");
        }
        
        return result;
    }
    
    public static void main(String[] args) throws Exception {
        TrsLoginUser trs;
        String xml;
        Connection con;
        
        Class.forName("org.gjt.mm.mysql.Driver").newInstance();
        con = DriverManager.getConnection(
                              "jdbc:mysql://127.0.0.1/vincere?" + 
                              "user=root&password=Hemoglorita&" + 
                              "autoReconnect=true");
        
        Cache.createCache("demoDataSource", 20).put(con);
        
        xml = "<data>\n" +
              "  <username>javivi</username>\n" +
              "  <password>Gloria</password>\n" +
              "</data>\n";        
        trs = new TrsLoginUser();
        trs.setDefinition(xml);
        trs.setOut(new PrintStream(System.out));
        trs.execute();
        
        System.out.flush();
        System.exit(0);
    }
}
