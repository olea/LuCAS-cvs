/*
 * MySQLTableGenerator.java
 *
 * Created on 1 de abril de 2002, 16:59
 */

package com.echiceros.bd.trs.idgen;

import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.system.pooling.*;
import com.echiceros.bd.*;

/**
 * Genera identificadores �nicos utilizando para ello una base
 * de datos como backend.
 *
 * B�sicamente se conecta a la tabla "idents" y la bloquea.
 * Obtiene el m�ximo almacenado en su campo value para la
 * clave correspondiente y lo incremente. Desbloquea la
 * tabla y retorna este valor.
 *
 * Puede utilizarse directamente o a traves del transactionengine.
 *
 * [Pendiente] Reinginer�a para facilitar la inclusi�n de 
 * soporte para m�s sgbd.
 *
 * @author  jv
 */
public class DatabaseGenerator implements IdGenerator {

    /** Creates a new instance of MySQLTableGenerator */
    public DatabaseGenerator() {
        super();
    }

    /** Retorna un identificador nuevo y �nico para la clave correspondiente.  
     *  null si no lo ha conseguido.
     */
    public String getIdentifier(String key) {
        String id = null;
        Cache cache;
        Connection con;
        DatabaseMetaData meta;
        String product;
        
        cache = CacheFinder.getInstance().getCacheWithTable("idents");
        con = (Connection) cache.get(true);
        try {
            meta = con.getMetaData();
            product = meta.getDatabaseProductName();
            Category.getInstance(getClass()).debug("Driver: " + product);
            if (product.equalsIgnoreCase("mysql") == true) {
                id = getIdentifierMySQL(con, key);
            } else if (product.equalsIgnoreCase("db2400") == true) {
                id = getIdentifierDB2400(con, key);
            }
        }
        catch (SQLException e) {
            id = null;
            Category.getInstance(getClass()).warn(e.getMessage());
            cache.put(con);
        }
        
        return id; 
    }
    
    /** Retorna un identificador nuevo y �nico para la clave correspondiente.  
     *  null si no lo ha conseguido. Implementaci�n para MySQL.
     */
    public String getIdentifierMySQL(Connection con, String key) 
    throws SQLException {
        long id = -1;
        DatabaseMetaData meta;
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        stmt.execute("LOCK TABLE idents WRITE;");            

        rs = stmt.executeQuery("SELECT max(id) " +
                               "FROM   idents " + 
                               "WHERE  name = '" + key + "'");            
        if (rs.next() == false) {
            id = 0;
        } else {
            id = rs.getInt(1);
        }
        rs.close();

        stmt.execute("DELETE FROM idents WHERE id = '" + id + "';");
        id = id + 1;
        stmt.execute("INSERT INTO idents (name, id) "+ 
                     "VALUES ('" + key + "', '" + id + "')");

        stmt.execute("UNLOCK TABLES;"); 

        stmt.close();
        
        return (id==-1) ? null :  String.valueOf(id);
    }
    
    /** Retorna un identificador nuevo y �nico para la clave correspondiente.  
     *  null si no lo ha conseguido. Implementaci�n para db2/400.
     */
    public String getIdentifierDB2400(Connection con, String key) 
    throws SQLException {
        long id = -1;
        DatabaseMetaData meta;
        Statement stmt;
        ResultSet rs;
        boolean autoCommit;
        
        autoCommit = con.getAutoCommit();
        con.setAutoCommit(false);
        stmt = con.createStatement();        
        stmt.execute("LOCK TABLE idents IN EXCLUSIVE MODE");            

        rs = stmt.executeQuery("SELECT max(id) " +
                               "FROM   idents " + 
                               "WHERE  name = '" + key + "'");            
        if (rs.next() == false) {
            id = 0;
        } else {
            id = rs.getInt(1);
        }
        rs.close();

        stmt.execute("DELETE FROM idents WHERE id = '" + id + "';");
        id = id + 1;
        stmt.execute("INSERT INTO idents (name, id) "+ 
                     "VALUES ('" + key + "', '" + id + "')");

        stmt.execute("UNLOCK TABLES;"); 

        stmt.close();
        
        con.commit();
        con.setAutoCommit(autoCommit);
        
        return (id==-1) ? null :  String.valueOf(id);
    }
    
    public static void main(String[] args) throws Exception {
        DatabaseGenerator gen;
        Cache cache;
        Connection con;
        String id;
        
        Class.forName("org.gjt.mm.mysql.Driver").newInstance(); 
        cache = Cache.createCache("testDataSource", 5);
        for (int i=0; i < 5; i++) {
            con = DriverManager.getConnection("jdbc:mysql://localhost/vincere/user=root&password=Hemoglorita");
            cache.put(con);
        }
        
        gen = new DatabaseGenerator();
        id = gen.getIdentifier("test");
        System.out.println(id);
        
        System.exit(0);
        
    }
    
}
