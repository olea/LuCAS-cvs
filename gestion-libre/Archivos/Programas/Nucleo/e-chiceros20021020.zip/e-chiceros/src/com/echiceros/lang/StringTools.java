package com.echiceros.lang;

import java.util.*;

/** Implementa rutinas �tiles para el tratamiento de Strings. Ya sabes... por no derivar
    String.
 */
public class StringTools implements java.io.Serializable {

  /** Pasa la primera letra de cada palabra a may�sculas, y el resto a min�sculas. */
  public static String toMiddleCase(String source) {
    StringBuffer dest;
        
    dest = new StringBuffer();
    
    if (source.length() > 0) {
      dest.append (source.substring(0,1).toUpperCase());
    }
    
    for (int i=1; i < source.length(); i++) {
      if (source.charAt(i-1) == ' ') {
        dest.append(source.substring(i,i+1).toUpperCase());
      } 
      else {
        dest.append(source.substring(i,i+1).toLowerCase());
      } 
    }
    
    return dest.toString();
  }
  
  /* Un substring que no lanza excepci�n si el �ltimo �ndice est� m�s all�
     del final del string.
  */
  public static String substring(String source, int first, int last) {
      String s;
      
      if (source == null) {
        s = null;
      }
      else if (source.length() > last) {
        s = source.substring(0,last);
      }
      else {
        s = source;
      }
      
      return s;
  }
  
  /** Retorna n caracteres empezando por la izquierda. */
  public static String left(String source, int len) {
    return StringTools.substring(source, 0, len-1);
  }

  /** Convierte un GregorianCalendar en un string con el formato
      yyyyMMddhhmmss, que facilita el tratamiento de rangos.
      
      Si el par�metro es null, retorna null.
   */
  public static String cal2str(GregorianCalendar cal) {
    String res;
    java.text.SimpleDateFormat sdf = null;
    
    if (cal == null) {
      res = null;
    }
    else {
      sdf = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
      res = (cal == null) ? "" : sdf.format(cal.getTime());
    }
    
    return res;
  }
  
  /** Convierte un string de la forma yyyyMMddhhmmss en un  
      GregorianCalendar.
      
      Si el par�metro es null, retorna null.
   */
  public static GregorianCalendar str2cal(String s) {
    GregorianCalendar cal = null;
    java.text.SimpleDateFormat sdf = null;
    
    if (s == null) {
      cal = null;
    }
    else {
      cal = new GregorianCalendar();
      try {    
        sdf = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
        cal.setTime(sdf.parse(s));
      }
      catch (java.text.ParseException e) {
        System.err.println(e);
      }
    }
    
    return cal;
  }
  
  /** Reemplaza todas las apariciones de una subcadena por otra en un String. 
   *  @param source El string sobre el que trabajamos.
   *  @param oldValue Cadena a reemplazar.
   *  @param ignoreCase true ssi se quiere reemplazar sin tener en cuenta
   *         may�sculas y min�sculas.
   *
   */
  public static String replace(String source, 
                               String oldValue, String newValue) {
      return replace(source, oldValue, newValue, false);                                   
  }
  
  /** Reemplaza todas las apariciones de una subcadena por otra en un String. 
   *  Ignora may�sculas / min�sculas en el patr�n de reemplazo.
   *  @param source El string sobre el que trabajamos.
   *  @param oldValue Cadena a reemplazar.
   *  @param ignoreCase true ssi se quiere reemplazar sin tener en cuenta
   *         may�sculas y min�sculas.
   *
   */
  public static String replaceIgnoreCase(String source, 
                                         String oldValue, String newValue) {
      return replace(source, oldValue, newValue, true);                                   
  }
  
  /** Reemplaza todas las apariciones de una subcadena por otra en un String. 
   *  @param source El string sobre el que trabajamos.
   *  @param oldValue Cadena a reemplazar.
   *  @param newValue Cadena de reemplazo.
   *  @param ignoreCase true ssi se quiere reemplazar sin tener en cuenta
   *         may�sculas y min�sculas.
   *
   */
  public static String replace(String source, 
                               String oldValue, String newValue,
                               boolean ignoreCase) {
    String preparedSource;                               
    String preparedOldValue;
    StringBuffer res;
    int iLast;
    int iNext;
    
    preparedSource = (ignoreCase == false) ? source : source.toUpperCase();
    preparedOldValue = (ignoreCase == false) ? oldValue : oldValue.toUpperCase();
    res = new StringBuffer();
    iLast = 0;
    iNext = 0;
    while (iNext != -1) {
      iNext = preparedSource.indexOf(preparedOldValue, iLast);
      if (iNext == -1) {
        res.append(source.substring(iLast, iLast + source.length() - iLast));
      }
      else {
        res.append(source.substring(iLast, iNext));
        res.append(newValue);
        iLast = iNext + oldValue.length();
      }
    }
    
    return res.toString();
  }
  
  /** Cuenta la similitud de la primera con la segunda cadena.
      Se mide en cuantas letras coiniciden exactamente desde
      el principio.
  
      Si ambas cadenas son EXACTAMENTE iguales, retorna 
      Integer.MAX_VALUE
   */
  public static int countSimilitude(String s1, String s2) {
    int res;
    
    if (s1.equals(s2) == true) {
      res = Integer.MAX_VALUE;
    }
    else {
      res = 0;
      while ((res < s1.length()) && 
             (res < s2.length()) && 
             (s1.charAt(res) == s2.charAt(res))) {
        res++;
      }
    }
    
    return res;
  }
  
  /** Retorna la posici�n de la �ltima aparici�n del car�cter a buscar
   *  en el StringBuffer.
   *  @param source cadena en la que se buscar�.
   *  @param chr car�cter a buscar.
   *  @returns el �ndice encontrado o -1 si no existe el car�cter 
   *           a buscar.
   */
  public static int lastIndexOf(StringBuffer s, char c) {
    int idx;
    
    idx = s.length();
    while ((idx > 0) && (s.charAt(idx-1) != c)){
        idx = idx - 1;
    }
    
    return idx-1;
  }
  
  /** @param source Cadena original en la que deseamos buscar.
   *  @left  cadena de caracteres que inicia la delimitaci�n.
   *  @right cadena de caracteres que finaliza la delimitaci�n.
   *  @from  �ndice de source a partir del cu�l empezar a buscar.
   *
   *  @return la subcadena contenida entre los dos delimitadores 
   *          o null si no existe.
   *  
   */
  public static String extract(String source, 
                               String left, String right, int from) {
     String res;
     int pos0;
     int posf;
     
     res = null;
     pos0 = source.indexOf(left, from);
     if (pos0 != -1) {
         posf = source.indexOf(right, pos0+left.length()+1);
         if (posf != -1) {
            res = source.substring(pos0 + left.length(), posf);
         }
     }
     
     return res;
  }
  
  /** @param source Cadena original en la que deseamos buscar.
   *  @left  cadena de caracteres que inicia la delimitaci�n.
   *  @right cadena de caracteres que finaliza la delimitaci�n.
   *  @from  �ndice de source a partir del cu�l empezar a buscar.
   *
   *  @return la subcadena contenida entre los dos delimitadores 
   *          o null si no existe.
   *  
   */
  public static String extract(String source, 
                               String left, String right) {
     return extract(source,left,right,0);
  }
    
 
  /** Retorna el par�metro de entrada una vez compactados los
   *  espacios m�ltiples y los retornos de carro.
   */
  public static String collapseWhites(String value) {
        StringBuffer res;
        boolean wasWhite;
        
        res = new StringBuffer();
        wasWhite = false;
        for (int i=0; i < value.length(); i++) {
            if (value.charAt(i) == ' ') {
                if (wasWhite == false) {
                    res.append(" ");
                }
                wasWhite = true;
            }
            else if (value.charAt(i) == '\n') {
                res.append(" ");
                wasWhite = true;
            }
            else {
                res.append(value.charAt(i));
                wasWhite = false;
            }            
        }
        
        return res.toString();
  }
  
  /** Retorna un digest (derivaci�n). Nivel de seguridad bajo.
   *
   *  @param message String a derivar.
   *  @param len N�mero de caracteres del string resultante.
   *  @result el digest generado.
   *
   */
  public static String fastDigest(String message) {
      java.security.MessageDigest digester;
      byte[] messageDigested;
      String res = null;
      
      try {
          digester = java.security.MessageDigest.getInstance("SHA");
          messageDigested = digester.digest(message.getBytes());
          for (int i=0; i < messageDigested.length; i++) {
              messageDigested[i] = (byte) (Math.abs(messageDigested[i]) % 26*2);
              messageDigested[i] = (byte) (messageDigested[i] + 65);
          }
          res = new String(messageDigested);

      }
      catch (java.security.NoSuchAlgorithmException e) {}
      
      return res;
  }
  
  public static String fastDigest(String message, int len) {
      String res;
      
      res = fastDigest(message);
      while (res.length() < len) {
          res = res + res;
      }
      res = res.substring(res.length()-len); 
      
      return res;
  }  
  
  /** Escapea la cadena de caracteres para que se inserte como un
   *  sql v�lido.
   */
  public static String escapeToSQL(String msg) {
      StringBuffer temp;
      String res;
      
      if (msg == null) {
          res = null;
      }
      else {
          if (msg.indexOf('\'') == -1) {
              res = msg;
          }
          else {
              temp = new StringBuffer();
              for (int i=0; i < msg.length(); i++) {
                  temp.append( (msg.charAt(i)=='\'') ? "''" : msg.substring(i,i+1));
              }
              res = temp.toString();
          }
      }      
      return res;
  }
  
  /** Convierte el array en un string separando sus elementos por sep.
   *  Ignora los elementos nulos.
   *  @param array Array a convertir, de Objects.
   *  @param sep separador utilizado.
   *  @result El toString() de los elementos separados por comas.
   */
  public static String arrayToString(Object[] array, String sep) {
      StringBuffer res;
      
      res = new StringBuffer();
      for (int i=0; i < array.length; i++) {
          if (array[i] != null) {
             res.append(array[i].toString());
             res.append(sep);
          }
      }
      if (res.length() > 0) {
          res.setLength(res.length()-sep.length());
      }
      
      return res.toString();
  }
  
  /** Convierte el array en un string separando sus elementos por ", ".
   *  Ignora los elementos nulos.
   *  @param array Array a convertir, de Objects.
   *  @result El toString() de los elementos separados por comas.
   */
  public static String arrayToString(Object[] array) {
      return arrayToString(array, ", ");
  }  
  
  /** Convierte el vector en un string separando sus elementos por ", ".
   *  Ignora los elementos nulos.
   *  @param v Vector a convertir, de Objects.
   *  @param sep Separador utilizado.
   *  @result El toString() de los elementos separados por comas.
   */
  public static String vectorToString(Vector v, String sep) {
      return arrayToString(v.toArray(), sep);
  }
  
  /** Convierte el vector en un string separando sus elementos por ", ".
   *  Ignora los elementos nulos.
   *  @param v Vector a convertir, de Objects.
   *  @result El toString() de los elementos separados por comas.
   */
  public static String vectorToString(Vector v) {
      return arrayToString(v.toArray());
  }
  
  /** Utilizado en split(...). */
  protected static int TOKEN_FOUND = -1;
  
  /** Crea un array a partir de un string dividiendo sus
   *  elementos seg�n los tokens indicados. Resulta m�s
   *  c�modo de utilizar que el StringTokenizer.
   *
   *  @param source La cadena de caracteres a trocear.
   *  @param spliters Un array de strings, siendo cada uno de ellos
   *                  un separador. Por ejemplo {" ", ".", "->"}.
   *
   *  @returns Un array con los tokens obtenidos.
   */
  public static String[] split(String source, String[] spliters) {
      Vector res;             // Almacenamos los tokens que vamos encontrando
      StringBuffer current;   // Token en composici�n
      int pos;                // Car�cter de source que estamos tratando
      int spIdx = 0;          // N�mero de spliter en tratamiento o bien TOKEN_FOUND
      int spLen;              // Longitud del spliter actual
      
      res = new Vector();
      
      pos = 0;
      current = new StringBuffer();
      // para todos los caracteres orginales
      while (pos < source.length()) {
          spIdx = 0;
          // para cada spliter disponible mientras no coincida ninguno
          while ((spIdx != TOKEN_FOUND) && (spIdx < spliters.length)) {
              spLen = spliters[spIdx].length();
              // si la posici�n actual en source marca el inicio de un spliter
              if ((pos + spLen -1 < source.length()) &&
                  (source.substring(pos, pos + spLen).equals(spliters[spIdx]))) {
                  if (current.length() > 0) {
                      res.addElement(current.toString());
                      current.setLength(0);
                  }
                  // actualiza pos para adelantar el cursor tras el spliter
                  pos = pos + spLen -1 ;
                  spIdx = TOKEN_FOUND; // finaliza el bucle interno.
              } else {
                  // probamos suerte con el siguiente
                  spIdx = spIdx + 1;
              }
          }
          // si ning�n spliter ha coincidido a�adimos el car�cter al token
          if (spIdx != TOKEN_FOUND) {
            current.append(source.charAt(pos));
          }
          pos = pos +1;
      }
      
      // �hemos a�adido el �ltimo token?
      if ((current.length() > 0) && (spIdx != TOKEN_FOUND)) {
          res.addElement(current.toString());
      }
      
      return (String[]) (res.toArray(new String[0]));
  }
  
  
  public static final int LEFT  = 1;
  public static final int RIGHT = 2;
  public static final int BOTH  = 3;
 
  /** Elimina los caracteres indicados del inicio o del final de la cadena.
   *   @param source cadena a retocar
   *   @param chars sucesi�n de caracteres a eliminar.
   *   @param direction LEFT, RIGHT,  BOTH: direcci�n del trim.
   *   @returns la cadena modificada.
   */
  public static String trim(String source, String chars, int direction) {
      int pos0, posf;
      
      pos0 = 0;
      posf= source.length()-1;
      
      if ((direction == LEFT) || (direction == BOTH)) {
          while ((pos0 < source.length()) && 
                 (chars.indexOf(source.charAt(pos0)) != -1)) {
             pos0 = pos0 + 1;
          }
      }
      
      if ((direction == RIGHT) || (direction == BOTH)) {
          while ((posf > pos0) && 
                 (chars.indexOf(source.charAt(posf)) != -1)) {
             posf = posf - 1;
          }
      }
      
      return source.substring(pos0, posf+1);      
  }
  
  public static void main(String[] args){
      String source;
      
      source = "00000234234.00";
      
      System.out.println(trim(source, "0", LEFT));
      System.out.println(trim(source, "0", RIGHT));
      System.out.println(trim(source, "0", BOTH));
  }
}