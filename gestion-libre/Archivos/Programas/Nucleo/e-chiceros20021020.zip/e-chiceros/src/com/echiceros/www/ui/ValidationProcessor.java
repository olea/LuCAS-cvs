package com.echiceros.www.ui;



import java.util.*;
import java.io.*;
import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import com.echiceros.io.*;

public class ValidationProcessor extends StreamProcessor {
    
    static final String TRIGGERS_JS_LIBRARY_PATH = "../js/triggers.js";
    
    Vector triggers;
    
    public ValidationProcessor() {
        super();
        triggers = new Vector();
    }
    
    public ValidationProcessor(Reader in, Writer out) {
        this();
        setIn(in);
        setOut(out);
    }
    

    public void transform()  throws IOException {
        SAXBuilder builder;
        XMLOutputter putter;
        Document doc;
        Element root;
         
        try {
            builder = new SAXBuilder();
            doc = builder.build(in);
        }
        catch (JDOMException e) {
            throw new IllegalArgumentException(
              getClass().getName() + ".transform(): " + e);
        }
        root = doc.getRootElement();
        
        preprocess();
        processElement(root);
        Collections.sort(triggers);
        postprocess();
        
        putter = new XMLOutputter();
        putter.setEncoding("iso-8859-1");
        putter.setOmitDeclaration(true);
        putter.output(doc, out);
    }
    
    protected void preprocess() throws IOException {
        out.write("<script language='javascript' src='" +
                    TRIGGERS_JS_LIBRARY_PATH + 
                    "'></script>\n");
    }
    
    protected void postprocess() throws IOException {
        Iterator iterator;
        Trigger trigger;
        String msg;
        String[] modes;
        String componentName;
        
        out.write("<script language='javascript'>\n");
        
        iterator = triggers.iterator();
        while (iterator.hasNext() == true) {
            trigger = (Trigger) iterator.next();
            msg = (trigger.getMessage()==null) ? 
                  null : "\"" + trigger.getMessage() + "\"";
            modes = trigger.getModes();
            for (int idx=0; idx < modes.length; idx++) {
                out.write("registerTrigger(" + 
                            "\"" + modes[idx] + "\", " +
                            "\"" + trigger.getComponent() + "\", " +
                            "\"" + trigger.getAction() + "\", " +
                            msg + 
                            ");\n");
            }
        }
        
        out.write("</script>\n");
    }
    
    protected void processElement(Element element) {
        Iterator children;
        
        if ((element.getName().equalsIgnoreCase("input") == false) &&
            (element.getName().equalsIgnoreCase("select") == false))
        {
          children = element.getChildren().iterator();
          while (children.hasNext() == true) {
              this.processElement((Element) children.next());
          }
        }
        else {
            this.processInputElement(element);
        }
    }
    
    protected void processInputElement(Element element) {
        Iterator children;
        Element current;
        String handler;
        
        children = element.getChildren("trigger").iterator();
        while (children.hasNext() == true) {
          current = (Element) children.next();
          this.processTriggerElement(element, current);
        }
        
        handler = (element.getAttributeValue("onchange"));
        if (handler == null) {
            handler = "";
        } 
        else if (handler.endsWith(";") == false) {
            handler = handler + "; ";
        }
        handler = handler + "return fireTriggers('change', this.name);";
        element.setAttribute("onchange", handler);
        element.removeChildren("trigger");
    }
    
    protected void processTriggerElement(Element inputElem, Element triggerElem) {
        Trigger trigger;
        String componentName;
        String action;
        String msg;
        String mode;
        
        componentName = inputElem.getAttributeValue("name");
        action = this.getTriggerAction(inputElem, triggerElem);        
        msg = this.getTriggerMessage(triggerElem);
        mode = triggerElem.getChildTextTrim("mode");
        trigger = new Trigger(componentName, action, msg, mode);
        
        this.triggers.addElement(trigger);
    }
    
    protected String getTriggerAction(Element inputElem, Element triggerElem) {
        StringBuffer action;
        Iterator params;
        Element currentParam;
        
        params = triggerElem.getChildren("param").iterator();
        action = new StringBuffer(triggerElem.getChildTextTrim("action"));
        action.append("(");
        action.append("'" + inputElem.getAttributeValue("name") + "', ");
        while (params.hasNext() == true) {
            currentParam = (Element) params.next();
            action.append(currentParam.getTextTrim());
            action.append(", ");
        } 
        action.setLength(action.length()-2);
        action.append(");");
        
        return action.toString();
    }
    
    protected String getTriggerMessage(Element triggerElem) {
        String value;
        String res;
        
        value = triggerElem.getChildTextTrim("errmsg");
        res = (value == null) ? 
              null : com.echiceros.lang.StringTools.collapseWhites(value);
        
        return res;
    }
    
    public String toString() {
        StringBuffer res;
        Iterator iterator;
        
        res = new StringBuffer();
        iterator = triggers.iterator();
        while (iterator.hasNext() == true) {
          res.append(iterator.next().toString());
          res.append(" ");
        }
        if (res.length() > 0) {
            res.setLength(res.length()-1);
        }
        
        return res.toString();
    }
    
    class Trigger implements java.lang.Comparable {
        String component;
        String action;
        String msg;
        String[] modes;
        
        public Trigger(String component, String action, String msg, String modes) {
            super();
            setComponent(component);
            setAction(action);
            setMessage(msg);
            setModes(modes);
        }
        
        public void setComponent(String component) { 
            this.component = component;  
        }
        
        public void setMessage(String msg) {
            this.msg = msg;
        }
        
        public void setAction(String action) {
            this.action  = action;
        }
        
        public void setModes(String modes) {
            Vector tmp;
            StringTokenizer tk;
            
            tmp = new Vector();
            tk = new StringTokenizer(modes, ", ");
            while (tk.hasMoreTokens() == true) {
                tmp.addElement(tk.nextToken());
            }
            this.modes = (String[]) tmp.toArray(new String[0]);
        }
        
        public String getComponent() { return component; }
        
        public String getAction() { return action; }
        
        public String getMessage() { return msg; }
        
        public String[] getModes() { return modes; }
        
        public int compareTo(java.lang.Object obj) {
            Trigger other;
            other = (Trigger) obj;
                        
            return this.getComponent().compareTo(other.getComponent());
        }
        
        public boolean equals(java.lang.Object obj) {
            return this == obj;
        }
        
        
        public String toString() {
            return "(" + component + " | " + action + " | " + msg + ")";
        }
                
    }
    
    public static void main(String[] args) throws Exception{
        FileReader xmlSource;
        ValidationProcessor tester;
        
        xmlSource = new FileReader(
          "C:/tomcat3/webapps/classes/com/echiceros/www/ui/FormFilterCreatorSource.xml");
        
        tester = new ValidationProcessor(xmlSource, new OutputStreamWriter(System.out));
        tester.transform();
        System.out.flush();
        System.out.println();
        System.out.println(tester);
    }
}