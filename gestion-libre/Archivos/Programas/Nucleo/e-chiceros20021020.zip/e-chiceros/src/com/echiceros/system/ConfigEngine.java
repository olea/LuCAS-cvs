/*
 * ConfigEngine.java
 *
 * Created on 6 de noviembre de 2001, 17:24
 */

package com.echiceros.system;

import java.util.*;
import java.io.*;
import org.jdom.*;
import org.jdom.input.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 * Carga la configuraci�n guardada en un archivo xml. En el archivo
 * de configuraci�n pueden existir elementos de dos tipos,
 *
 *  Transacciones a ejecutar con el siguiente formato:
 *
 *    <requestService>
 *      <name>com.echiceros.bd.TrsCreateDataSourceCache</name>
 *      <data>
 *        <name>mainDataSource</name>
 *        <limit>20</limit>
 *        <class>org.gjt.mm.mysql.Driver</class>
 *        <url>
 *          jdbc:mysql://127.0.0.1/vincere?user=trsengine&password=trs3ng1n3&autoReconnect=true
 *        </url>
 *      </data>
 *    </requestService> 
 *
 *  Propiedades a fijar:
 *
 *     <property name="tomcat_home" value="c:/tomcat3"/>
 *  
 *  Las propiedades se almacenar�n en el espacio de nombres indicado
 *  en el elemento config como root. Por ejemplo:
 *
 *  <config root="/tomcats/usersessions">
 *       .... requestServices y properties ...
 *       <property name="port" value="8888"/>
 *  <config/>
 *
 *  har� que la property /tomcats/usersessions/port valga 8888.
 *  
 *  20020618 : requestService y requestTransaction son ahora sin�nimos.  
 *  20020915 : a�adido el soporte multivalor.
 *
 *  [PENDIENTE] Soporte completo para xpath (integraci�n con xindice o jdom).
 *
 * @author  jv
 * @version 1.0
 */
public class ConfigEngine {
    /** Instancia de configuraci�n com�n a la m�quina virtual. */
    static ConfigEngine defaultInstance = null;
    
    /** Elemento bajo el que se almacenar�n las propiedades. */
    String root; 
    
    /** Tabla de propiedades cargadas. */
    static Hashtable properties = null;
    
    /** Crea un nuevo ConfigEngine. No carga configuraci�n.
     */
    public ConfigEngine() {
        super();
        if (properties == null) {
            properties = new Hashtable();
        }
        if (this.defaultInstance == null) {
            this.defaultInstance = this;
        }
    }
    
    /** Creates new ConfigEngine 
     *  @param filePath path completo del archivo de configuraciones,
     *         por ejemplo c:/app/info.xml
     */
    public ConfigEngine(String filePath) {
        this();
        loadFromFile(filePath);
        Category.getInstance(getClass()).debug(   
            "Instancia por defecto: " + this.getInstance().getRoot());
    }
    
    /** Agrega la configuracion almacenada en un archivo. */
    public void loadFromFile(String filePath) {
        org.jdom.input.SAXBuilder builder;
        Document doc;
        String root;
        
        try {
            Category.getInstance(getClass()).info("instanciado.");
            builder = new SAXBuilder();
            doc = builder.build(new java.io.FileReader(filePath));
            root = doc.getRootElement().getAttributeValue("root");
            Category.getInstance(getClass()).debug("Root: " + root);
            this.setRoot(root);
            this.loadConfig(doc);
        }
        catch (JDOMException e) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " + e);
        }
        catch (IOException e) {
            throw new IllegalArgumentException(
              getClass().getName() + ": " + e);
        }
    }
    
    /** Fija la ra�z del ConfigEngine. */
    public void setRoot(String root) {
        if (root != null) {
            this.root = root;
        } else {
            this.root = "/";
        }
    }
    
    /** Retorna la ra�z del configEngine. */
    public String getRoot() {
        return this.root;
    }
    
    /** Recorre los elementos del xml cargando la configuraci�n. */
    protected void loadConfig(Document doc) {
        Element rootElement;
        Iterator iter;
        List children;
        Element current;
        
        rootElement = doc.getRootElement();
        children = rootElement.getChildren();
        iter = children.iterator();
        while (iter.hasNext() == true) {
            current = (Element) iter.next();
            if ((current.getName().equalsIgnoreCase("requestService")) ||
                (current.getName().equalsIgnoreCase("requestTransaction")))
            {
                try {
                    this.loadTransaction(current);
                }
                catch (TrsException e) {
                    System.out.println(getClass().getName() + ": " + e);
                }
            }
            else if (current.getName().equalsIgnoreCase("property")) {
                this.loadProperty(current);
            }
        }
    }

    /** Ejecuta una transacci�n. */
    protected void loadTransaction(Element trsDesc) throws TrsException {
        TransactionEngine.executeTransaction(trsDesc, 
                                             new PrintStream(System.out));
    }

    /** Carga la propiedad indicada en la tabla de propiedades. */
    protected void loadProperty(Element trsDesc)  {
        String name;
        String value;
        
        name = "/" + trsDesc.getAttributeValue("name");
        if (this.root != null) {
            name = root + name;
        }
        value= trsDesc.getAttributeValue("value");
        
        Category.getInstance(getClass()).debug("property " + name + " = " + value +".");
        
        this.setProperty(name.toUpperCase(), value);
    }
    
    /** Convierte el par�metro en un xpath absoluto. */
    protected String normalizeXPath(String xpath) {
        String res;
        
        res = (xpath.charAt(0) != '/') ?  this.root + "/" + xpath : xpath;
        res = res.toUpperCase();
        
        return res;
    }
    
    /** Retorna el primer valor de una propiedad como un string. Si 
     *  existen varios valores retorna el primero de ellos.
     *
     *  @args xpath puede ser un nombre absoluto o relativo. Si es absoluto
     *        se indicar� con una / (por ejemplo, "/port" o "/tomcats/port") o
     *        relativo, en cuyo caso se le prefijar� autom�ticamente con this.root.
     *  @returns El primer valor contenido en el xpath indicado.
     */
    public String getProperty(String xpath) {
        String normalizedXPath;
        String[] values;

        normalizedXPath  = normalizeXPath(xpath);
        values = (String[]) properties.get(normalizedXPath.toUpperCase());
        
        return (values == null) ? null : values[0];
    }
    
    /** Retorna todos los valores de una propiedad
     *
     *  @args xpath puede ser un nombre absoluto o relativo. Si es absoluto
     *        se indicar� con una / (por ejemplo, "/port" o "/tomcats/port") o
     *        relativo, en cuyo caso se le prefijar� autom�ticamente con this.root.
     *  @returns Todos los valores contenidos en el xpath indicado.
     */
    public String[] getPropertyTexts(String xpath) {
        String normalizedXPath;
        String[] values;

        normalizedXPath  = normalizeXPath(xpath);
        values = (String[]) properties.get(normalizedXPath.toUpperCase());
        
        return values;
    }
    
    /** Agrega un valor a los de la propiedad indicada. Lo inserta como
     *  primero de la lista de forma que ser� retornado por un 
     *  getProperty(...).
     *
     *  @param xpath puede ser un nombre absoluto o relativo. Si es absoluto
     *  se indicar� con una / (por ejemplo, "/port" o "/tomcats/port") o
     *  relativo, en cuyo caso se le prefijar� autom�ticamente con this.root.
     *  @param value valor a fijar.
     */
    public void setProperty(String xpath, String value) {
        String normalizedXPath;
        String[] oldValues;
        String[] newValues;

        normalizedXPath  = normalizeXPath(xpath);
        oldValues = (String[]) properties.get(normalizedXPath);
        if (oldValues == null) {
            newValues = new String[1];
        } else {
            newValues = new String[oldValues.length + 1];
            System.arraycopy(oldValues, 0, newValues, 1, oldValues.length);
        }
        newValues[0] = value;
        

        properties.put(normalizedXPath, newValues);        
    }

    /** Fija una propiedad, sustituyendo cualquier otra con el mismo xpath.
     *  @param xpath puede ser un nombre absoluto o relativo. Si es absoluto
     *  se indicar� con una / (por ejemplo, "/port" o "/tomcats/port") o
     *  relativo, en cuyo caso se le prefijar� autom�ticamente con this.root.
     *  @param value valor a fijar.
     */
    public void setProperty(String xpath, int value) {
        this.setProperty(xpath, String.valueOf(value));
    }
    
    
    /** Retorna el valor de una propiedad como un int, o Integer.MAX_VALUE
     *  si no exist�a. 
     */
    public int getIntProperty(String xpath) {
        String value;
        
        value = this.getProperty(xpath); 
        
        return (value==null) ? Integer.MIN_VALUE : Integer.parseInt(value);
    }
    
    /** Retorna una enumeraci�n con el xpath de los elementos que se encuentran
     *  en el xpath indicado.
     *  @param xpath xpath sobre el que buscar. se considera relativo
     *         this.root si no empieza por "/".
     */
    public Enumeration getPropertyPaths(String xpath) {
        Vector container;
        String normalizedXPath;
        Enumeration keys;
        String key;
        
        normalizedXPath = this.normalizeXPath(xpath);
        container = new Vector();
        keys = this.properties.keys();
        while (keys.hasMoreElements() == true) {
            key = (String) keys.nextElement();
            if (key.startsWith(normalizedXPath) == true) {
                container.addElement(key);
            }            
        }
        
        return container.elements();
    }
    
    /** Elimina todos los elementos contenidos en el indicado
     *  por el xpath de par�metro.
     *  @param xpath identificaci�n del elemento a eliminar junto
     *         con sus hijos.
     */
    public void removeProperties(String xpath) {
        Enumeration keys;
        
        keys = this.getPropertyPaths(xpath);
        while (keys.hasMoreElements() == true) {
            this.properties.remove(keys.nextElement());
        }
    }
    
    public static ConfigEngine getInstance(String root) {
        ConfigEngine res;
        
        res = new ConfigEngine();
        res.setRoot(root);
        
        return res;
    }
    
    public static ConfigEngine getInstance() {
        ConfigEngine engine;
        
        if (defaultInstance == null) {
           engine = getInstance("/");
            
        } else {
           engine = defaultInstance;
        }
        
        return engine;
    }
    
    public static void main(String[] args) throws Exception {
        ConfigEngine engine;
        Enumeration paths;
        
        engine = ConfigEngine.getInstance("/tomcat");
        engine.setProperty("/tomcat/instance0/home", "c:/tomcat");
        engine.setProperty("instance0/port", 8080);
        engine.setProperty("instance0/port", 80);
        engine.setProperty("/tomcat/instance1/home", "c:/tomcat2");
        engine.setProperty("/tomcat/instance1/port", 8081);

        System.out.println(engine.getProperty("instance0/home"));
        System.out.println(engine.getProperty("instance0/port"));
        System.out.println(engine.getPropertyTexts("instance0/port")[1]);
        System.out.println(engine.getProperty("/tomcat/instance1/home"));
        System.out.println(engine.getProperty("/tomcat/instance1/port"));
        System.out.println();
        
        paths = engine.getPropertyPaths("/");
        while (paths.hasMoreElements() == true) {
            System.out.println(paths.nextElement());
        }
        System.out.println();
        
        engine.removeProperties("/tomcat/instance0");
        
        System.out.println(engine.getProperty("instance0/home"));
        System.out.println(engine.getProperty("instance0/port"));
        System.out.println(engine.getProperty("/tomcat/instance1/home"));
        System.out.println(engine.getProperty("/tomcat/instance1/port"));
        System.out.println();
    }
}
