/*
 * XSLApplyTag.java
 *
 * Created on 26 de agosto de 2001, 20:05
 */

package com.echiceros.www.xsl;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import org.apache.log4j.*;
import com.echiceros.io.*;
import com.echiceros.www.tools.*;

/**
 *
 * Permite aplicar una xsl-t a un documento xml. El documento debe
 * encontrarse en el interior del elemento delimitado por el tag.
 * La transformaci�n se realizara utilizando el documento cuya url
 * se indica como atributo del tag.
 *
 * NUEVO: La xsl se recupera mediante conexi�n http. Esto tiene
 * como �nico inconveniente el que debe residir en el espacio
 * p�blico de acceso del servidor. Como contrapartida �podemos
 * utilizar toda la potencia de las jsp en la hoja de estilo!
 *
 * Adem�s, la xsl recibir� como par�metros todos aquellos que
 * hayan sido fijados en este tag (mediante <gen:param .../>)
 * y todos los almacenados en la request (los primeros tienen
 * prioridad sobre los segundos).
 *
 * El tag incluye tambi�n de forma autom�tica en la invocaci�n
 * de la xsl el par�metro URLBase que har� referencia a la URI
 * carpeta del recurso que est� siendo procesado. Por ejemplo:
 * http://servet/vincere/introduccion
 *
 * @author  jv
 * @version 1.1
 */
public class XSLApplyTag extends BodyTagSupport {

    /** URL del documento que contiene la xsl. */
    String URL;
    
    public void setURL(String value) { 
      this.URL = value;
    }
    
    public String getURL() {
        return this.URL;
    }
    
    /* ****************************************************** */
    
    /** Creates new XSLApplyTag */
    public XSLApplyTag() {
        super();
    }

    /**
     * 
     * @exception JspException if a JSP error occurs
     */
    public int doStartTag() throws JspException {
       return (EVAL_BODY_TAG);
    }
    
    /**
     * Obtiene el transformador, ejecuta la transformaci�n y
     * escribe el resultado.
     *
     * @exception JspException if a JSP error has occurred
     */
    public int doAfterBody() throws JspException {
       InputStream xslIn;
       TransformerFactory tFactory;
       Transformer transformer;
       
       try {
           Category.getInstance(getClass()).debug("Iniciando transformaci�n");
           xslIn = openXSLStream();
           tFactory = TransformerFactory.newInstance();
           transformer = tFactory.newTransformer(new StreamSource(xslIn));

           transformer.transform
                (new StreamSource(this.bodyContent.getReader()), 
                 new StreamResult(new WriterWithoutFlush(this.getPreviousOut())));

           xslIn.close();
       }
       catch (TransformerConfigurationException e) {
           throw new JspException("XSLApplyTag.doAftertTag(): " + e.getMessage());
       }
       catch (TransformerException e) {
           throw new JspException("XSLApplyTag.doAftertTag(): " + e.getMessage());
       }
       catch (IOException e) {
           throw new JspException("XSLApplyTag.doAftertTag(): " + e.getMessage());
       }
       return (SKIP_BODY);

    }
    
    /** Abre un stream para recuperar la xsl a partir del atributo
     *  url que la especifica.
     */
    protected InputStream openXSLStream() 
    throws IOException {
        URLNormalizer norm;
        HttpServletRequest request;
        String urlSpec;
        URL url;
        String path;
        InputStream in;
        Enumeration enum;
        String paramName;
        String paramValue;

        request = (HttpServletRequest) pageContext.getRequest();
        if (getURL().startsWith("http://") == true) {
            norm = new URLNormalizer(this.getURL(), "");
        }
        else if (getURL().startsWith("/") == true) {
            norm = new URLNormalizer(ServletTools.getAppURL(request), 
                                     this.getURL().substring(1));
        }
        else {
            norm = new URLNormalizer(ServletTools.getRequestFolder(request), getURL());
        }
        
        // A�adimos los par�metros del request
        enum = request.getParameterNames();
        while (enum.hasMoreElements() == true) {
            paramName = (String) enum.nextElement();
            paramValue= request.getParameter(paramName);
            norm.addParam(paramName, paramValue);
        }
        // A�adimos los par�metros fijados con <param...>
        enum = this.getValues();
        if (enum != null) {
            while (enum.hasMoreElements() == true) {
                paramName = (String) enum.nextElement();
                paramValue= (String) this.getValue(paramName);
                norm.addParam(paramName, paramValue);
            }
        }
        // Y por �ltimo, URLBase
        norm.addParam("URLBase", ServletTools.getRequestFolder(request));
        urlSpec = norm.getURL();
        
        url = new URL(urlSpec);
        in = new BufferedInputStream(url.openConnection().getInputStream());
        
        Category.getInstance(getClass()).debug("URL de xsl: " + url.toString() + ".");
        return in;
    }
    
    public java.lang.String toString() {
        return "XSLApplyTag instance.";
    }
        
}
