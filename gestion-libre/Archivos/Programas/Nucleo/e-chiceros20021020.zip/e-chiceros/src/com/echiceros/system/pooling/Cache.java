/*
 * Cache.java
 *
 * Created on 27 de septiembre de 2001, 15:59
 */

package com.echiceros.system.pooling;

import java.util.*;
import org.apache.log4j.*;

/**
 * Implementa funciones de cach� y pool. Incluye la posibilidad de liberar
 * elementos cuando alcancen una determinada cantidad o cuando 
 * caduquen.
 *
 * La pol�tica de reutilizaci�n es lifo.
 *
 * cambios: 
 *       a�adido getItsId(...).
 *       agregado el m�todo destroy() que ser� invocado cuando
 *       finalice la aplicaci�n (@see CacheExpirator).
 *
 * @author  jv
 * @version 1.2
 */
public class Cache implements Cacheable {

    /** Contiene el resto de las cach�s. */
    static Cache defaultCache = null;
    
    /** Indica que esta cach� no tiene fijado un m�ximo. */
    public static final int UNLIMITED = Integer.MAX_VALUE;
    
    /** Id de esta cach�. */
    Object id;
    
    /** N�mero de instancias m�ximo. Por encima de este n�mero
     *  no se aceptar�n m�s objetos.
     */
    int limit;
    
    /** Guarda referencias a los objetos. Utilizada para la 
     *  pol�tica de lifo. */
    Stack stack;
    
    /** Guarda la referencia indexada. Utilizada cuando preguntamos
     *  por un objeto en concreto.
     */
    Hashtable hashtable;
   
    /** Handler encargado de liberar los elementos de la cach� 
     *  cuando esta es destru�da. 
     */
    CacheDestroyer destroyer;
    
    /** Creates new Cache 
     *  @param limit m�ximo n�mero de instancias aceptable por la cach�.
     */
    public Cache(Object id, int limit) {
        super();
        this.id = id;
        this.limit = limit;
        this.stack = new Stack();
        this.hashtable = new Hashtable();
        this.destroyer = null;
        Category.getInstance(getClass().getName()).info(
           "Cach� " + id + " creada.");
    }
    
    /** Indica cu�ntos objetos tenemos en cach�. */
    public int getSize() {
        return stack.size();
    }
    
    /** @returns El m�ximo n�mero de objetos que puede almacenar la cach�. */
    public int getLimit() {
        return this.limit;
    }
    
    /** Retorna los identificadores de todos los elementos que
     *  contiene esta cach�.
     */
    public Iterator getIdentifiers() {
        return hashtable.keySet().iterator();
    }
    
    /** Retorna el identificador de esta cach�. */
    public Object getItsId() {
        return this.id;
    }
    
    /** Fija el destructor encargado de eliminar los objetos contenidos
     *  en la cach�.
     */
    public void addCacheDestroyer(CacheDestroyer destroyer) {
        this.destroyer = destroyer;
    }
    
    /**
     *  @param exclusive true si deseamos retirar el objeto de la 
     *         cach� (actuar� como un pool).
     *
     *  @return El primer objeto de la pila, o null si size == 0. */ 
    public synchronized Object get(boolean exclusive) {
        Object res;
        Cacheable cacheable;
        
        res = null;
        while ((getSize() > 0) && (res == null)) {
           res = (exclusive == true) ? stack.pop() : stack.peek();
           if (res instanceof Cacheable) {
               cacheable = (Cacheable) res;
               if (exclusive == true) {
                 hashtable.remove(cacheable.getIdentifier());
               }
               if (cacheable.hasExpired() == true) {
                   cacheable.destroy();
                   stack.remove(cacheable);
                   hashtable.remove(cacheable);
                   res = null;
               }
           }           
        }
        
        Category.getInstance(getClass().getName()).debug(
           "Cach� " + id + " accedida (get). Quedan " + getSize() + " instancias.");
        return res;
    }
    
    /** 
     *  @param identifier El identificador del objeto a retornar.
     *  @param exclusive Si debe retirarse el objeto de la cach�.
     *
     *  @return El objeto cuyo identificador coincide con el pedido, o null
     *          si no existe.
     */
    public synchronized Object get(Object identifier, boolean exclusive){
       Object res;
       Cacheable cacheable;
        
       res = hashtable.get(identifier);
       if ((res != null) && (exclusive == true)) {
           stack.remove(res);
           hashtable.remove(res);
       }
       if (res instanceof Cacheable) {
           cacheable = (Cacheable) res;
           if (cacheable.hasExpired() == true) {
               cacheable.destroy();
               stack.remove(cacheable);
               hashtable.remove(cacheable);
               res = null;
           }
       }

       Category.getInstance(getClass().getName()).debug(
           "Cach� " + id + " accedida (get). Quedan " + getSize() + " instancias.");
       return res;
    }

    /** Guarda un objeto. Si es Cacheable utiliza su identificador
     *  para indexarlo.
     */
    public synchronized void put(Object obj) {
        Cacheable cacheable;
        
        if (this.getSize() < this.limit) {
            stack.remove(obj);
            stack.push(obj);
            if (obj instanceof Cacheable) {
               cacheable = (Cacheable) obj;
               hashtable.remove(cacheable.getIdentifier());
               hashtable.put(cacheable.getIdentifier(), cacheable);
            }
        }
        else if (obj instanceof Cacheable) {
            cacheable = (Cacheable) obj;
            cacheable.destroy();
        }
        
        Category.getInstance(getClass().getName()).debug(
           "Cach� " + id + " accedida (put). Quedan " + getSize() + " instancias.");
    }
    
    /** Guarda un objeto por el identificador que se indica. */
    public synchronized void put(Object identifier, Object obj){
        Cacheable cacheable;
        
        if (this.getSize() < this.limit) {
            stack.remove(obj);
            stack.push(obj);
            hashtable.remove(obj);
            hashtable.put(identifier, obj);
        }
        else if (obj instanceof Cacheable) {
            cacheable = (Cacheable) obj;
            cacheable.destroy();
        }
    }
        
    /** Retorna la cach� principal (la que contiene el resto. */
    public static synchronized Cache getDefaultCache() {
        if (defaultCache == null) {
            defaultCache = new Cache("DefaultCache", UNLIMITED);
            CacheExpirator.getDefault().start();
        }
        
        return defaultCache;
    }
    
    /**
     *  Utilizado para acceder de forma c�moda a una cach�
     *  del sistema.
     *  @return el cach� cuyo identificador se indica. 
     */
    public static Cache getCache(Object identifier) {
        Cache res;
        
        res = (Cache) getDefaultCache().get(identifier, false);
        
        return res;
    }
    
    /** Utilizado para agregar una cach� de sistema, o para
     *  reperarla asegur�ndonos de que existe. 
     *  @param identifier El identificador por el que se almacena
     *         la cach�.
     *  @return La cach� requerida.
     */
    public static Cache createCache(Object identifier) {
        Cache res;
        
        res = createCache(identifier, UNLIMITED);
        
        return res;
    }
    
    /** Utilizado para agregar una cach� de sistema. Si la cach�
     *  ya existia, la retorna.
     *  @param identifier El identificador por el que se almacena
     *         la cach�.
     *  @param limit M�ximo n�mero de objetos que podr� almacenar.
     *  @return La cach� reci�n creada.
     */
    public static Cache createCache(Object identifier, int limit) {
        Cache res;
        
        res = (Cache) getDefaultCache().get(identifier, false);
        if (res == null) {
            res = new Cache(identifier, limit);
            getDefaultCache().put(identifier, res);
        }
        
        return res;
    }
     
    /** Ejecuta la expiraci�n de todos aquellos elementos
     *  expirables.
     */
    public void expire() {
        Iterator elements;
        Object currentElement;
        Cacheable cacheableElement;
        Vector expirables;
        
        elements = stack.iterator();
        // System.out.println("[DEBUG] cache expirando.");
        expirables = new Vector();
        // Buscamos todos los elementos eliminables...
        while (elements.hasNext() == true) {
            currentElement = elements.next();
            if (currentElement instanceof Cacheable) { 
                cacheableElement = (Cacheable) currentElement;
                if (cacheableElement.hasExpired() == true) {
                    expirables.addElement(cacheableElement);
                }
            }
        }
        // ... y los eliminamos. 
        // System.out.println("[DEBUG] cache : eliminables " + expirables.size());
        for (int i=0; i < expirables.size(); i++) {
            cacheableElement = (Cacheable) expirables.elementAt(i);
            // System.out.println("[DEBUG] cache: Expirando " + cacheableElement);
            cacheableElement.destroy();
            stack.remove(cacheableElement);
            hashtable.remove(cacheableElement);
        }
        // System.out.println("[DEBUG] cache " + this.getIdentifiers() + " fin.");
    }
    
    /** Retorna el identificador del objeto, es decir un nombre por
     *  el que ser� conocido.
     */
    public Object getIdentifier() {
        return this.getItsId();
    }
    
    /** True si el objeto ya no es �til y en lugar de ser retornado
     *  debe eliminarse.
     */
    public boolean hasExpired() {
        return false;
    }
    
    /** Invocado al finalizar la aplicaci�n. Deberia liberar los
     *  recursos de la cach�.
     */
    public void destroy() {
        Category.getInstance(getClass()).info
              ("Destruyendo la cach� " + this.getItsId() + ".");
        if (this.destroyer == null) {
            this.destroyer = new DefaultDestroyer();
        }
        destroyer.destroy(this);
    }
    
    class DefaultDestroyer implements CacheDestroyer {
        public void destroy(Cache cache) {
            Object currentElement;
            Cacheable cacheableElement;

            while (cache.getSize() > 0) {
                currentElement = cache.get(true);
                if (currentElement instanceof Cacheable) {
                    cacheableElement = (Cacheable) currentElement;
                    cacheableElement.destroy();
                } 
                Category.getInstance(getClass()).debug(
                   "Elemento " + (cache.getSize() + 1) + " de " +
                   cache.getItsId() + " liberado.");
            }
            Category.getInstance("com.echiceros.system.pooling.Cache").info(
               "Cach� " + cache.getItsId() + " vaciada correctamente.");
        }
    }
}
