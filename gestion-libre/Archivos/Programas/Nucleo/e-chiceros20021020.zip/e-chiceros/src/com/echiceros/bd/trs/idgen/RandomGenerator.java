/*
 * RandomGenerator.java
 *
 * Created on 18 de junio de 2002, 12:33
 */

package com.echiceros.bd.trs.idgen;

/**
 *
 * Genera identificadores al azar. �til para hacer pruebas.
 *
 * @author  ciberado
 */
public class RandomGenerator implements com.echiceros.bd.trs.idgen.IdGenerator {
    
    /** Retorna un identificador nuevo y �nico para la clave correspondiente.  */
    public String getIdentifier(String key) {
        int id;
        
        id = (int) (Math.random()*1000);
        return "ID " + id;
    }    
    
    
}
