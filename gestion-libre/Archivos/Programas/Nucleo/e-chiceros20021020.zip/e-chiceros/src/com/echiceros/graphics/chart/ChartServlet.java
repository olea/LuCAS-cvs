/*
 * ChartServlet.java
 *
 * Created on 13 de febrero de 2002, 13:49
 */
 
package com.echiceros.graphics.chart;           

import javax.servlet.*;
import javax.servlet.http.*;

/** 
 *
 * Aunque ser�a recomendable utilizar TransactionServlet para
 * generar l�s gr�ficas en ocasiones no resulta pr�ctico instalar
 * todo el framework. Este servlet puede ser considerado una
 * alternativa al actuar directamente como envoltorio de 
 * TrsChartGenerator.
 *
 * @author  jv
 * @version 1
 */
public class ChartServlet extends HttpServlet {
   
    /** Initializes the servlet.
    */  
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

    }

    /** Destroys the servlet.
    */  
    public void destroy() {

    }

    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        ServletOutputStream out;
        TrsChartGenerator trs;
        
        response.setContentType("image/gif");
        
        try {
            out = response.getOutputStream();        
            trs = new TrsChartGenerator();
            trs.setDefinition(request.getParameter("xml"));
            trs.setOut(new java.io.PrintStream(out));
            trs.execute();
        }
        catch (com.echiceros.bd.trs.TrsException e) {
            throw new IllegalArgumentException(e.toString());
        }
        
        out.close();
    } 

    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }

}
