/*
 * AxeAlpha.java
 *
 * Created on 8 de febrero de 2002, 12:34
 */

package com.echiceros.graphics.chart;

import java.util.*;
import java.text.*;
import com.echiceros.util.*;

/**
 * Un eje de coordenadas alfanum�rico. 
 *
 * @author  jv
 */
public class AxeAlpha extends Axe{

    /** Valores que componen el eje, ordenados. */    
    ArrayList values;
    
    /** Creates a new instance of AxeNumeric */
    public AxeAlpha(String name, Object[] values) {
        super(name);
        setValues(values);
    }

    /** Creates a new instance of AxeNumeric */
    public AxeAlpha(String name, List values) {
        super(name);
        setValues(values.toArray());
    }
    
    
    public void setValues(Object[] values) {
        this.values = new ArrayList();
        for (int i=0; i < values.length; i++) {
          this.values.add(values[i]);
        }
    }
    
    /** Retorna el factor correspondiente al punto indicado.
     * @param El punto a situar. Por ejemplo, "Enero".
     * @returns Un n�mero del 0 al 1 indicando a qu�
     *          distancia del eje debe situarse el punto.
     */
    public float getPointDistance(Object point) {
        float res;
        int idx;
        
        idx = values.indexOf(point);
        res = (float) idx / values.size();
        res = res + (1.0f / (values.size()*2)); // Corregimos para centrar
        
        return res;
    }
    
    /** Retorna una hashtable con la distancia a la que se debe
     *  dibujar cada punto de la escala (key: punto, value: distancia).
     *  El punto se almacena como un string con dos decimales.
     */
    public java.util.Hashtable getLabelsDistances() {
        Hashtable res;
        Object current;
        float distance;
        
        res = new Hashtable();
        for (int i=0; i < values.size(); i++) {
            current = values.get(i);
            distance = this.getPointDistance(current);
            res.put(this.getLabelValue(current), new Float(distance));
        }
        Runtime.getRuntime().gc();
        
        return res;
    }
    
    /** Retorna el ordinal (valor num�rico) correspondiente a un
     *  determinado punto sobre el eje. 
     *  @param point El punto sobre el eje. Normalmente ser� la
     *               componente de un punto sobre el mismo.
     */
    public double getOrdinalValue(Object obj) {
        double res;
        
        res = this.getPointDistance(obj);
        
        return res;
    }
    
    /** Retorna el valor del punto indicado como un label susceptible
     *  de ser presentado como texto en pantalla. Se limita a convertir
     *  el objeto en un String.
     */
    public String getLabelValue(Object obj) {
        String text;
        
        text = obj.toString();
        
        return text;
    }
    
    /** Retorna una enumeraci�n con los puntos ordenados seg�n el
     *  criterio del eje. Ordena ignorando el eje de las x.
     *  NO se garantiza que el el orden de los elementos del
     *  par�metro de entrada quede sin alteraciones.
     *
     * @param points una Collection con los CharPoints a ordenar.
     * @returns Una enumeraci�n con los puntos ordenados.
     */
    public Enumeration getOrderedPoints(List points) {
        Enumeration retValue;
        
        Collections.sort(points, new PartialPointComparator());
        retValue = new WrappedEnumeration(points.iterator());

        return retValue;
    }
    
    /** Retorna la distancia que existe entre los dos puntos m�s
     * cercanos de la enumeraci�n indicada.
     * @param points Los puntos que queremos comprobar.
     * @returns la distancia l�gica.
     */
    public double getMinDistance(List points) {
        double minDist;
        Enumeration enum;
        
        enum = this.getOrderedPoints(points);
        minDist = calcMinDist(enum);

        return minDist;
    }
    
    class PartialPointComparator implements java.util.Comparator {
        
        public int compare(Object obj, Object obj1) {
            int res;
            ChartPoint one;
            ChartPoint other;

            one   = (ChartPoint) obj;
            other = (ChartPoint) obj1;
            res = one.getZ().compareTo(other.getZ());
            if (res == 0) {
                if (values.indexOf(one.getX()) < values.indexOf(other.getX())){
                    res = -1;
                } else if (values.indexOf(one.getX()) > values.indexOf(other.getX())){
                    res = +1;
                }
            }
            if (res == 0) {
                res = one.getY().compareTo(other.getY());
            }

            return res;        
        }
        
    }
    
}
