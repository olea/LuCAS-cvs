/*
 * Axe.java
 *
 * Created on 6 de febrero de 2002, 12:27
 */

package com.echiceros.graphics.chart;

import java.util.*;
import com.echiceros.util.OrderedEnumeration;

/**
 * Mantiene la informaci�n de un eje de coordenadas.
 *
 * @author  jv
 */
public abstract class Axe {
    public static final int X = 0;
    public static final int Y = 1;
    public static final int Z = 2;

    
    /** Nombre del eje. */
    private String name;
    
    /** Creates a new instance of Axe */
    public Axe(String name) {
        this.setName(name);
    }
    
    /** Retorna el factor correspondiente al punto indicado.
     *  @param El punto a situar. 
     *  @returns Un n�mero del 0 al 1 indicando a qu�
     *           distancia del eje debe situarse el punto.
     */
    public abstract float getPointDistance(Object point);

    /** Retorna una hashtable con la distancia a la que se debe
     *  dibujar cada punto de la escala (key: punto, value: distancia).
     */
    public abstract java.util.Hashtable getLabelsDistances();
    
    /** Retorna la distancia que existe entre los dos puntos m�s
     *  cercanos de la enumeraci�n indicada.
     *  @param points Los puntos que queremos comprobar.
     *  @returns la distancia l�gica.
     */
    public abstract double getMinDistance(List points);
    
    
    /** Calcula la distancia l�gica m�nima que hay entre dos puntos 
     *  de la gr�fica. Se presupone que los puntos se encuentran ordenados.
     *  Puede utilizarse para implementar getMinDistance(...).
     *
     *  ATENCI�N: la actual implementaci�n funciona solo sobre el
     *  eje de las x. Es decir, ejecutar este m�todo en un Axe que
     *  no sea el horizontal producir� resultados err�neos. En
     *  cualquier caso esto no supone un problema a menos que
     *  deseemos intercambiar los ejes X e Y.
     */
    protected double calcMinDist(Enumeration points) {
        double res;
        ChartPoint old;
        ChartPoint current;
        double dist;
        
        res = Double.MAX_VALUE;
        old = null;
        while (points.hasMoreElements() == true) {
            current = (ChartPoint) points.nextElement();
            if ((old != null) && (old.getZ().equals(current.getZ()))) {
               dist = this.getOrdinalValue(current.getX()) - 
                      this.getOrdinalValue(old.getX());
               if (res > dist) {
                   res = dist;
               }
            }
            old = current;
        }
        
        return res;
    }

    /** Retorna el ordinal (valor num�rico) correspondiente a un
     *  determinado punto sobre el eje. 
     *  @param point El punto sobre el eje. Normalmente ser� la
     *               componente de un punto sobre el mismo. 
     */
    public abstract double getOrdinalValue(Object obj);

    /** Retorna el valor del punto indicado como un label susceptible
     *  de ser presentado como texto en pantalla.
     */
    public abstract String getLabelValue(Object obj);
    
    /** Retorna una enumeraci�n con los puntos ordenados seg�n el 
     *  criterio del eje. Por defecto, utiliza la ordenaci�n impl�cita
     *  de CharPoint.
     *  NO se garantiza que el el orden de los elementos del 
     *  par�metro de entrada quede sin alteraciones.
     *
     *  @param points una Collection con los CharPoints a ordenar.
     *  @returns Una enumeraci�n con los puntos ordenados.
     */
    public Enumeration getOrderedPoints(List points) {
        Enumeration res;
      
        res = new OrderedEnumeration(points.iterator());
        
        return res;
    }
    
    /** Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return this.name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
}
