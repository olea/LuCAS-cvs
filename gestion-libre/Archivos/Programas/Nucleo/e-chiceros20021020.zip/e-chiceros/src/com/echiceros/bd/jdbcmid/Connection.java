/*
 * Connection.java
 *
 * Created on 30 de junio de 2002, 15:39
 */

package com.echiceros.bd.jdbcmid;

import java.util.*;
import java.sql.*;
import com.echiceros.bd.jdbcmid.transformers.*;

/**
 *
 * @author  jv
 */
public class Connection implements java.sql.Connection {
    
    java.sql.Connection realConnection;
    Vector queryTransformations;
    Vector updateTransformations;


    /** Creates a new instance of Connection */
    public Connection(java.sql.Connection realConnection) {
        this.realConnection = realConnection;
        queryTransformations = new Vector();
        updateTransformations = new Vector();
    }
    
    java.util.Enumeration getQueryTransformations() {
        return queryTransformations.elements();
    }
    
    java.util.Enumeration getUpdateTransformations() {
        return updateTransformations.elements();
    }
    
    public void addQueryTransformation(SQLTransformation  trans) {
        this.queryTransformations.addElement(trans);
    }
    
    public void addUpdateTransformation(SQLTransformation  trans) {
        this.updateTransformations.addElement(trans);
    }
    
    public void clearWarnings() throws SQLException {
        this.realConnection.clearWarnings();
    }
    
    public void close() throws SQLException {
        this.realConnection.close();
    }
    
    public void commit() throws SQLException {
        this.realConnection.commit();
    }
    
    public java.sql.Statement createStatement() throws SQLException {
        java.sql.Statement stmt;
        
        stmt = this.realConnection.createStatement();
        return new Statement(this, stmt);
    }
    
    public java.sql.Statement createStatement(int param, int param1) 
    throws SQLException {
        return this.realConnection.createStatement(param, param1);
    }
    
    public boolean getAutoCommit() throws SQLException {
        return this.realConnection.getAutoCommit();
    }
    
    public String getCatalog() throws SQLException {
        return this.realConnection.getCatalog();
    }
    
    public DatabaseMetaData getMetaData() throws SQLException {
        return this.realConnection.getMetaData();
    }
    
    public int getTransactionIsolation() throws SQLException {
        return this.realConnection.getTransactionIsolation();
    }
    
    public java.util.Map getTypeMap() throws SQLException {
        return this.realConnection.getTypeMap();
    }
    
    public SQLWarning getWarnings() throws SQLException {
        return this.realConnection.getWarnings();
    }
    
    public boolean isClosed() throws SQLException {
        return this.realConnection.isClosed();
    }
    
    public boolean isReadOnly() throws SQLException {
        return this.realConnection.isReadOnly();
    }
    
    public String nativeSQL(String str) throws SQLException {
        return this.realConnection.nativeSQL(str);
    }
    
    public CallableStatement prepareCall(String str) throws SQLException {
        return this.realConnection.prepareCall(str);
    }
    
    public CallableStatement prepareCall(String str, int param, int param2) throws SQLException {
        return this.realConnection.prepareCall(str, param, param2);
    }
    
    public PreparedStatement prepareStatement(String str) throws SQLException {
        return this.realConnection.prepareStatement(str);
    }
    
    public PreparedStatement prepareStatement(String str, int param, int param2) throws SQLException {
        return this.realConnection.prepareStatement(str, param, param2);
    }
    
    public void rollback() throws SQLException {
        this.realConnection.rollback();
    }
    
    public void setAutoCommit(boolean param) throws SQLException {
        this.realConnection.setAutoCommit(param);
    }
    
    public void setCatalog(String str) throws SQLException {
        this.realConnection.setCatalog(str);
    }
    
    public void setReadOnly(boolean param) throws SQLException {
        this.realConnection.setReadOnly(param);
    }
    
    public void setTransactionIsolation(int param) throws SQLException {
        this.realConnection.setTransactionIsolation(param);
    }
    
    public void setTypeMap(java.util.Map map) throws SQLException {
        this.realConnection.setTypeMap(map);
    }
    
    /* jdk1.4 **********************************************************
     
    public java.sql.Statement createStatement(int param, int param1, int param2) throws java.sql.SQLException {
        return this.realConnection.createStatement(param, param1, param2);
    }
    
    public int getHoldability() throws java.sql.SQLException {
        return this.realConnection.getHoldability();
    }
    
    public java.sql.CallableStatement prepareCall(String str, int param, int param2, int param3) throws java.sql.SQLException {
        return this.realConnection.prepareCall(str, param, param2, param3);
    }
    
    public java.sql.PreparedStatement prepareStatement(String str, int param) throws java.sql.SQLException {
        return this.realConnection.prepareStatement(str, param);
    }
    
    public java.sql.PreparedStatement prepareStatement(String str, int[] values) throws java.sql.SQLException {
        return this.realConnection.prepareStatement(str, values);
    }
    
    public java.sql.PreparedStatement prepareStatement(String str, String[] str1) throws java.sql.SQLException {
        return this.realConnection.prepareStatement(str, str1);
    }
    
    public java.sql.PreparedStatement prepareStatement(String str, int param, int param2, int param3) throws java.sql.SQLException {
        return this.realConnection.prepareStatement(str, param, param2, param3);
    }
    
    public void releaseSavepoint(java.sql.Savepoint savepoint) throws java.sql.SQLException {
        this.realConnection.releaseSavepoint(savepoint);
    }
    
    public void rollback(java.sql.Savepoint savepoint) throws java.sql.SQLException {
        realConnection.rollback(savepoint);
    }
    
    public void setHoldability(int param) throws java.sql.SQLException {
    }
    
    public java.sql.Savepoint setSavepoint() throws java.sql.SQLException {
        return this.realConnection.setSavepoint();
    }
    
    public java.sql.Savepoint setSavepoint(String str) throws java.sql.SQLException {
        return this.realConnection.setSavepoint(str);
    }
    
     ********************************************************** */
}
