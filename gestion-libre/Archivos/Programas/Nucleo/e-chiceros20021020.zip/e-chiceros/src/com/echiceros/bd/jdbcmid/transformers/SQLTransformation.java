/*
 * SQLTransformation.java
 *
 * Created on 4 de julio de 2002, 13:03
 */

package com.echiceros.bd.jdbcmid.transformers;

/**
 *
 * @author  Administrador
 */
public interface SQLTransformation {
        public String transformSql(String sql);
}
