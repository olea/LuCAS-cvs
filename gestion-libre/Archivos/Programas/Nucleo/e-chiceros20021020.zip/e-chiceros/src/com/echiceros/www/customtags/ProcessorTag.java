/*
 * IncludeTag.java
 *
 * Created on 23 de septiembre de 2001, 12:13
 */

package com.echiceros.www.customtags;

import java.util.*;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import com.echiceros.io.StreamProcessor;

/**
 * Permite aplicar Streamprocessors al body del tag. Si se trata de un
 * TagStreamProcessor lo trata de forma ligeramente diferente de manera
 * que se permite la cancelaci�n de la evaluaci�n del body.
 *
 * Los par�metros aceptados son:
 *
 *    className - Nombre de la clase del StreamProcessor
 *    xml       - Par�metro con informaci�n adicional.
 *
 * Por supuesto, si eval�a el body (un TagStreamProcessor puede evitarlo)
 * es posible pasar par�metros adicionales mediante <gen:param/>. Todos
 * ellos ser�n recibidos por el processor.
 *
 * @author  jv
 * @version 
 */
public class ProcessorTag extends BodyTagSupport {

    /** Nombre de la clase a instanciar como Streamprocessor. */
    private String className;    
    
    /** Holds value of property name. */
    private String name = null;    
    
    /** Par�metros prebody indicados como atributo. */
    private String params = null;
    
    /** El procesador. */
    StreamProcessor processor;
    
    public ProcessorTag() {
        super();
    }

    public int doStartTag() throws JspTagException {
       int res;
       TagStreamProcessor processorAsTSP;
       
       res = this.EVAL_BODY_TAG;
       try {
           processor = (StreamProcessor) Class.forName(getClassName()).newInstance();
           if (this.getParams() != null) {
             processor.setParam("xml", getParams());
           }
           
           if (processor instanceof TagStreamProcessor) {
               processorAsTSP = (TagStreamProcessor) processor;
               processorAsTSP.setRequest((HttpServletRequest) pageContext.getRequest());
               if (processorAsTSP.cancelBodyEvaluation() == true) {
                   res = this.SKIP_BODY;
               }
           }
       }
       catch (ClassNotFoundException e) {
          throw new JspTagException(
            getClass().getName() + ".doStartTag(): "  + e);
       }
       catch (IllegalAccessException e) {
          throw new JspTagException(
            getClass().getName() + ".doStartTag(): "  + e);
       }
       catch (InstantiationException e) {
          throw new JspTagException(
            getClass().getName() + ".doStartTag(): "  + e);
       }
       
       return res;
    }    
    
    public int doAfterBody() throws JspTagException {
       StringWriter out;
       Enumeration enum;
       String name;
       
       try {
           out = new StringWriter();
           processor.setIn(this.getBodyContent().getReader());
           processor.setOut(out);
           processor.setName(getName());
           enum = this.getValues();
           if (enum != null) {
               while (enum.hasMoreElements() == true) {
                   name = (String) enum.nextElement();
                   processor.setParam(name, (String) this.getValue(name));
               }
           }
           processor.transform();
           this.getPreviousOut().write(out.getBuffer().toString()); 
           out.close();
       }
       catch (IOException e) {
          throw new JspTagException(
            getClass().getName() + ".doAfterBody(): "  + e);
       }
       getBodyContent().clearBody();
       
       return SKIP_BODY;
    }
   
    public int doEndTag() throws JspException {
        return this.EVAL_PAGE;  
    }
    
    /** Getter for property className.
     * @return Value of property className.
     */
    public String getClassName() {
        return className;
    }
    
    /** Setter for property className.
     * @param className New value of property className.
     */
    public void setClassName(String className) {
        this.className = className;
    }
    
    /** Getter for property name.
     * @return Value of property name.
     */
    public String getName() {
        return name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    public void setParams(String value) {
        this.params = value;
    }
    
    public String getParams() {
        return this.params;
    }
    
}
