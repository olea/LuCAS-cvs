/*
 * Pooleable.java
 *
 * Created on 27 de septiembre de 2001, 16:22
 */

package com.echiceros.system.pooling;

/**
 * Los objetos que se almacene en pools pueden implementar
 * esta interface para mejorar su manejo.
 *
 * @author  jv
 * @version 
 */
public interface Pooleable {
    
    /** Ejecutado al volver al pool. */
    void recycle();
    
}

