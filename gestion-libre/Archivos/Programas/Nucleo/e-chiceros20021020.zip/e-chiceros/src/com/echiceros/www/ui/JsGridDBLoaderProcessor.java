/*
 * JsGridCreatorProcessor.java
 *
 * Created on 16 de agosto de 2001, 10:32
 */

package com.echiceros.www.ui;           

import java.util.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;


/** Esta clase permite generar el javascript necesario para dibujar
 *  un grid enlazado a datos en un navegador. Actualmente funciona
 *  correctamente con IE y asume la disponibilidad de una librer�a
 *  tipo grid.js cargada.
 *
 *  [ATENCI�N] Esta clase se considera beta y esta sujeta a revisi�n.
 *
 *  @version beta 0.1
 */
public class JsGridDBLoaderProcessor implements TrsSQLSelect.Processor {
    String divName;
    String[] labels;
    String[] columns;
    boolean editable;
    String submitFunction;
    
    /** 
     *  @param divName Nombre del division HTML que almacena la grid.
     *  @param labels  Etiquetas para la primera fila de la rejilla.
     *  @param columns Nombre de las columnas en la base de datos.
     *  @param editable true si debe generarse un grid con capacidad
     *                  de edici�n de datos.
     *  @param submitFunction Nombre de la funci�n javascript que el
     *                  grid ejecutara si deben actualizarse datos.
     *                  Esta funci�n recibir� dos par�metros: el grid
     *                  y el gridModel.
     */
    public JsGridDBLoaderProcessor(String divName, 
                                   String[] labels, String[] columns, 
                                   boolean editable, String submitFunction) {
        this.divName = divName;
        this.labels = labels;
        this.columns = columns;
        this.editable = editable;
        this.submitFunction = submitFunction;
    }
    
    public void preProcess(PrintStream out) {
        StringBuffer line;
        String functionName;

        functionName = "loadGrid" + 
                       this.divName.substring(0,1).toUpperCase() +
                       this.divName.substring(1);
        line = new StringBuffer();
        line.append("<script language='javascript'>");
        line.append("  function " + functionName + "() { ");
        line.append("    var model;");
        line.append("    var grid;");
        line.append("    model = new GridModel(new Array(");
        for (int i=0; i < this.labels.length; i++) {
            line.append("'" + this.labels[i] + "', ");
        }
        line.setLength(line.length()-2);
        line.append("));");
        out.println(line);
    }

    public void postProcess(PrintStream out) {
        StringBuffer script;

        script = new StringBuffer();
        script.append("grid = new Grid('" + this.divName +"',");
        script.append("model, " + this.editable );
        if (this.submitFunction != null) {
          script.append(", "  + this.submitFunction);
        }
        script.append(");");

        script.append("    grid.write();");
        script.append("  }");
        script.append("</script>");

        out.println(script.toString());
    }

    public void processRecord(PrintStream out, MetaData meta, ResultSet rs) 
    throws SQLException {
        StringBuffer line;
        ResultSetMetaData slowMeta;
        int columnIdx;
        String value;
        boolean isAlfa;
        boolean isBoolean;


        slowMeta = rs.getMetaData();
        line = new StringBuffer();
        line.append("model.addElement(new Array(");
        for (int i=0; i < this.columns.length; i++) {
          columnIdx = meta.getIndex(this.columns[i]);
          isAlfa = ((slowMeta.getColumnType(columnIdx) == Types.CHAR) ||
                    (slowMeta.getColumnType(columnIdx) == Types.VARCHAR));
          value = rs.getString(columnIdx);
          if (isAlfa == true) { 
              line.append("'");
          }
          line.append(value.trim().replace('\'', '�'));
          if (isAlfa == true) { 
              line.append("'");
          }
          line.append(", ");
        }
        line.setLength(line.length()-2);
        line.append("));\n");
        out.println(line.toString());
    }
}    

