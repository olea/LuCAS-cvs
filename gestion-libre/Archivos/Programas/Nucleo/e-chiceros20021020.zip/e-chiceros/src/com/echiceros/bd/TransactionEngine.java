package com.echiceros.bd;

import java.io.*;
import java.net.*;
import org.jdom.*;
import org.jdom.input.*;
import org.apache.log4j.*;
import org.python.core.*;
import org.python.util.*;
import com.echiceros.lang.*;
import com.echiceros.system.*;
import com.echiceros.system.pooling.*;
import com.echiceros.io.*;
import com.echiceros.bd.trs.*;

/** 
 *  Activa un servicio socket por el que puede recibir
 *  peticiones para procesar transacciones en formato
 *  xml y retornar el resultado de las mismas. En ese
 *  sentido el concepto es similar al de SOAP, pero 
 *  simplificado al m�ximo.
 *
 *  Una petici�n t�pica tendr� la siguiente forma:
 *
 *   <requestService>
 *     <name>TestTransaction</name>
 *     <data>
 *        <username>ciberado</username>
 *        <record table="customer">
 *           <field name="id" value="A3423K" />
 *           <field name="address" value="Rovellat 5" />
 *        </record>
 *        <record table="customer">
 *           <field name="id" value="3C42AK" />
 *           <field name="address" value="Alegr�a 3" />
 *        </record>
 *     </data>
 *   </requestService> 
 *
 *   B�sicamente el motor instanciara la transacci�n cuyo
 *   nombre se indica y fijar� como su definition el elemento
 *   data. 
 *
 *   La t�pica select trabajar� sobre subclases de TrsSQLSelect.
 *   Dichas subclases se limitar�n a fijar el processor y se
 *   invocar�n de la siguiente forma:
 *
 *   <requestService>
 *     <name>TrsGetColumns</name>
 *     <data>
 *        <query>SELECT * FROM xxx</query>
 *        <cache>DEFAULTCONNECTIONPOOL</cache>
 *     </data>
 *   </requestService> 
 *
 *   El motor de configuraciones deber�a definir la variable
 *   transactionEngine.port indicando el n�mero de puerto a
 *   utilizar.
 *   
 *   La invocaci�n del engine puede generar el siguiente error:
 *
 *     -1   : xml no v�lido.
 *
 *
 *   20020618: ya no es necesario colocar una l�nea en blanco tras
 *             el xml para marcar su fin si no se cierra el socket.
 *     
 *   20020912: ��wowww!! las transacciones pueden escribirse en
 *             python. Para ello basta con dar el nombre del 
 *             script en el elemento name. P. ej:
 *                 <name>jython:d:/scripts/TrsWop.py</name>        
 *
 */
public class TransactionEngine extends com.echiceros.io.BasicServer { 
    
   /** Crea la instancia pero NO lanza el servicio. 
    *  Obtiene el path de configuraci�n de la variable de 
    *  entorno TEConfigPath.
    */
   public TransactionEngine() {
     this(System.getProperty("TEConfigPath"));
   }
   
   /* Crea la instancia pero NO lanza el servicio.
    * @param configPath par�metro con el path de la configuraci�n
    *        del gestor de transacciones.
    */
   public TransactionEngine(String configPath) {
     super(configPath);
   }
    
   /** Deber�a procesar la conexi�n que se indica como par�metro.
    * puede utilizar como base la clase BasicServer.Service.
    */
   protected void newService(Socket sck) {
       new TransactionEngineService(sck);
   }
   
   /** Genera el xml correspondiente a transacci�n err�nea.
    *  @param errCode un codigo de error.
    *  @param description la descripci�n del error.
    */
   public static String createErrorXML(String errCode, String description) {
       return 
            "<serviceResponse>\n" +
            "  <type>error</type>\n" +
            "  <data>\n" +
            "    <code>" + errCode + "</code>\n" +
            "    <description>" + description + "</description>\n" +
            "  </data>\n" +
            "</serviceResponse> \n";
   }
   
   /** Genera el xml correspondiente a transacci�n correcta.
    *  @param data elementos a agregar en el interior del elemento
    *         data.
    */
   public static String createSuccessXML(String data) {
       return 
            "<serviceResponse>\n" +
            "  <type>success</type>\n" +
            "  <data>\n" +
            data + 
            "  </data>\n" +
            "</serviceResponse> \n";
   }
   
   /** Implementa la clase encargada de gestionar una conexi�n. */
   class TransactionEngineService extends BasicServer.Service {
       
       /** Trata un nuevo servicio, leyendo el xml que lo
        * describe y lanzando la transacci�n correspondiente.
        * @param sck El socket que ha abierto la conexi�n y a trav�s
        * del cu�l se nos indicar� el servicio a ejecutar.
        */       
       public TransactionEngineService(Socket sck) {
           super(sck);
       }
       
       /** Ejecuta la transacci�n indicada desde el socket.
        * Se ejecuta en un nuevo thread (no en el del engine)
        * para permitir la concurrencia.
        *
        */       
       public void run() {
           Document doc;
           BufferedReader in = null;
           PrintStream out = null;
           String response;

           try {
               Category.getInstance(this.getClass()).info("Nueva petici�n.");
               in = new BufferedReader(
                                new InputStreamReader(
                                sck.getInputStream()));
               out = new PrintStream(sck.getOutputStream());
               doc = this.createJDOM(in);
               this.executeTransaction(doc, out);
           }
           catch (IOException e) {
             Category.getInstance(this.getClass()).warn(e); 
           }
           catch (JDOMException e) {
               out.println(createErrorXML("-1", e.getMessage()));
               Category.getInstance(this.getClass()).warn(e); 
           }
           catch (TrsException e) {
               out.println(createErrorXML("-1", e.getMessage()));
               Category.getInstance(this.getClass()).info(e); 
           }
           finally {
               if (sck != null) {
                   try { sck.close(); } 
                   catch (IOException e) {
                       Category.getInstance(this.getClass()).warn(e); 
                   }
               }
           }
       }
       
       /** Lee desde el reader el documento xml que especifica la
        * transacci�n y la convierte en un documento xml tipo jdom.
        * @param in canal del socket por el que recibiremos el xml.
        * @throws IOException Si se produce un error al recuperar el xml.
        * @throws JDOMException Si se produce un error de parseado del xml.
        * @return El documento jdom creado.
        */       
       protected Document createJDOM(BufferedReader in) 
       throws IOException, JDOMException {
           SAXBuilder builder;
           Document doc;
           StringBuffer msg;
           String line;
           
           msg = new StringBuffer();
           do {
               line = in.readLine();
               if (line!=null) {
                 msg.append(line);
               }               
           } while ((line != null) && 
                    (line.toLowerCase().indexOf("</requestservice>") == -1) &&
                    (line.toLowerCase().indexOf("</requesttransaction>") == -1)
                   );
           builder = new SAXBuilder();
           return builder.build(new java.io.StringReader(msg.toString()));
       }
       
       /** A partir del documento jdom obtiene el nombre del servicio
        * deseado, lo instancia, fija la definici�n con el elemnto
        * "data" del xml, fija como canal de salida el del mismo
        * socket por el que hemos recibido el xml y la ejecuta.
        * @param doc Documento con los datos de la transacci�n.
        * @param out Canal de salida (la transacci�n proporcionar�
        * informaci�n a trav�s de �l).
        * @throws TrsException Si se produce cualquier error en la ejecuci�n
        * de la transacci�n.
        */       
       protected void executeTransaction(Document doc,
                                         PrintStream out) 
       throws TrsException {
           TransactionEngine.this.executeTransaction(doc.getRootElement(), out);
       }
   }
   
   /** A partir del documento jdom obtiene el nombre del servicio
    * deseado, lo instancia, fija la definici�n con el elemnto
    * "data" del xml, fija como canal de salida el del mismo
    * socket por el que hemos recibido el xml y la ejecuta.
    *
    * @param root ra�z del documento con los datos de la transacci�n.
    * @param out Canal de salida (la transacci�n proporcionar�
    * informaci�n a trav�s de �l).
    *
    * @throws TrsException Si se produce cualquier error en la ejecuci�n
    * de la transacci�n.
    */       
   public static void executeTransaction(Element root, PrintStream out) 
   throws TrsException {
       String protocolName = null;
       String className = null;
       Element data;

       className = root.getChildTextTrim("name");
       if (className.indexOf(":") != -1) {
           protocolName = className.substring(0,className.indexOf(":"));
           className = className.substring(className.indexOf(":")+1);
       } else {
           protocolName = "java";
       }
       Category.getInstance("com.echiceros.bd.TransactionEngine").info("ejecutando " + className + ".");
       data = root.getChild("data");

       if (protocolName.equalsIgnoreCase("java") == true) {
           executeTransactionJava(className, data, out);
       } else if (protocolName.equalsIgnoreCase("jython") == true) {
           executeTransactionJython(className, data, out);
       }
   }

   /** Ejecuta una transacci�n escrita en java.
    */
   protected static void executeTransactionJava(String className, Element data,
                                         PrintStream out) 
   throws TrsException {
       Trs transaction;
       
       try { 
           transaction = (Trs) Class.forName(className).newInstance();
           transaction.setDefinition(data);
           transaction.setOut(out);
           transaction.execute();
       }
       catch (ClassNotFoundException e) {
           throw new TrsException("TrsAdapter [" + className+ "]: " + e);
       }
       catch (InstantiationException e) {
           throw new TrsException("TrsAdapter [" + className+ "]: " + e);
       }
       catch (IllegalAccessException e) {
           throw new TrsException("TrsAdapter [" + className+ "]: " + e);
       }
   }
   
   /** Ejecuta una transacci�n escrita en jython.
    */
   protected static void executeTransactionJython(String scriptName, 
                                                  Element data,
                                                  PrintStream out) 
   throws TrsException {
        Trs transaction;
        String path;
        
        path = scriptName;
        
        try {
            transaction = (Trs) JythonInstantiator.newInstance(path, Trs.class);

            if (transaction !=  null) {
                transaction.setDefinition(data);
                transaction.setOut(out);
                transaction.execute();
            }
            else {
                throw new TrsException("Script not found at :" + path);
            }
        } catch (PyException e) {
            Category.getInstance("com.echiceros.bd.TransactionEngine").warn(e.getMessage());
            throw new TrsException(e.getMessage());
        }
    }
   
   /** Utilizada para comprobar que el engine funciona
    * correctamente.
    */   
   public static class TrsTest 
   extends com.echiceros.bd.trs.TrsSQLSelect 
   implements com.echiceros.bd.trs.TrsSQLSelect.Processor {
       
       public TrsTest() {
           this.setProcessor(this);
       }
       
       public void processRecord(PrintStream out, 
                                 MetaData meta, java.sql.ResultSet rs) 
       throws java.sql.SQLException {
           StringBuffer line;
           
           line = new StringBuffer();
           for (int i=0; i < meta.getColumnCount(); i ++) {
               line.append(rs.getString(i+1) + " ");
           }
           
           System.out.println("\t" + line.toString());
       }
       
       public void preProcess(PrintStream out) {
       }
       
       public void postProcess(PrintStream out) {
       }
       
   }
   
   public static void main(String[] args) throws Exception {     
      TransactionEngine engine;
      
      BasicConfigurator.configure();
      
      if (args.length != 1) {
          System.err.println("Sintaxis incorrecta.");
      } else {
          System.setProperty("TEConfigPath", args[0]);
    //    Ejemplo: "d:/userinfo/projects/echidemo/WEB-INF/trsengine.xml");
          Category.getRoot().info("Iniciando Transaction Engine.");
          engine = new TransactionEngine();
          Category.getRoot().info("Lanzando motor.");
          engine.setStatus(true);
      }
   }
   
}