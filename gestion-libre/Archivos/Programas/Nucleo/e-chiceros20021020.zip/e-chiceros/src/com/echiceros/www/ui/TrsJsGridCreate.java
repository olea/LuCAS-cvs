/*
 * TrsCreateJsGrid.java
 *
 * Created on 4 de enero de 2002, 16:18
 */

package com.echiceros.www.ui;

import java.util.*;
import java.io.*;
import java.sql.*;
import org.jdom.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 * Esta transacci�n permite generar el c�digo html necesario
 * para incrustar un grid (ver grid.js) en cualquier p�gina.
 * Para ello recibir� una serie de par�metros con el 
 * siguiente formato:
 *
 *   <data>
 *      <gridname>ranking</gridname>
 *      <editable>true</editable>
 *      <datasource>
 *         <name>java:fca005.trs.TrsDatosMesDataSource</name>
 *         <data>...</data>
 *      </datasource>
 *      <datasource>
 *         <name>java:fca005.trs.TrsDatosMesDataUpdate</name>
 *         <destination>trsresult.jsp</destination>
 *         <data>...</data>
 *      </datasource>
 *   </data>
 *
 * gridname indica el nombre con el que se crear� la capa en la que 
 *          se escribir� la tabla.
 *
 * datasource contiene un elemento name que admite por el momento un 
 *            protocolo (java:) y que ser� el nombre de la clase encargada 
 *            de generar el  javascript necesario para crear el modelo de 
 *            datos de la tabla. Cualquier par�metro que se desee pasar
 *            a la transacci�n
 *
 * editable podr� ser false (solo visionar) o true (activar edici�n de datos).
 *
 * datadestination si el grid es editable las modificaciones podr�n enviarse
 *                 a un destinatario para su procesamiento. Este destinatario
 *                 se especificar� en este elemento. De momento se soporta un
 *                 protocolo (java:) seguido del nombre de la clase que debe
 *                 recibir los datos. Funciona de manera similar a datasource.
 *                 Tambi�n puede especificarse una <destination> a la que 
 *                 se redireccionar� el resultado.
 *
 * @author  jv
 * @version 0.9
 *
 */
public class TrsJsGridCreate extends com.echiceros.bd.trs.TrsAdapter {

    /** Creates a new instance of TrsCreateJsGrid */
    public TrsJsGridCreate() {
        Category.getInstance(getClass().getName()).info(
           "Creada." );
    }

    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        String gridname;
        Element datasource;
        String editable;
        Element datadestination;
        
        gridname = super.definition.getChildTextTrim("gridname");
        datasource = super.definition.getChild("datasource");
        datadestination = super.definition.getChild("datadestination");
        editable = super.definition.getChildTextTrim("editable");
        editable = (editable == null) ? "false" : editable;
        
        this.createGrid(gridname, datasource, 
                        editable.equalsIgnoreCase("true"), datadestination);
        Category.getInstance(getClass().getName()).info(
           "Completada." );
                        
    }
    
    /** Instancia la transacci�n encargada de generar el modelo y 
     *  escribe el javascript necesario para crear la grid.
     */
    protected void createGrid(String gridName, Element dataSource,
                              boolean editable, Element dataDestination) 
    throws TrsException {
        TrsDataSource trsDataSource;
        String name;
        
        try {
            name = dataSource.getChildTextTrim("name");
            if (name.indexOf("java:") == 0) {
                name = name.substring("java:".length());
            }
            trsDataSource = (TrsDataSource) Class.forName(name).newInstance();
            trsDataSource.setOut(out);
            if (dataSource.getChild("data") != null) {
              trsDataSource.setDefinition(dataSource.getChild("data"));
            }
            trsDataSource.setGridName(gridName);
            trsDataSource.setEditable(editable);
            trsDataSource.setDataDestination(dataDestination);
            trsDataSource.execute();
        }
        catch (ClassNotFoundException e) {
            Category.getInstance(getClass().getName()).debug(e);
            throw new TrsException(getClass().getName() + ": " + e);
        }
        catch (IllegalAccessException e) {
            Category.getInstance(getClass().getName()).debug(e);
            throw new TrsException(getClass().getName() + ": " + e);
        }
        catch (InstantiationException e) {
            Category.getInstance(getClass().getName()).debug(e);
            throw new TrsException(getClass().getName() + ": " + e);
        }
        
        
    }
    
    

    public static abstract class TrsDataSource 
    extends TrsSQLSelect implements TrsSQLSelect.Processor {
        String gridName;
        boolean editable;
        Element dataDestination;
        
        public TrsDataSource() {
            super();
            this.setProcessor(this);
        }
        
        public void setGridName(String gridName) {
            this.gridName = gridName;
        }
        
        public void setEditable(boolean editable) {
            this.editable = editable;
        }
        
        public void setDataDestination(Element dataDestination) {
            this.dataDestination = dataDestination;
        }
        
        protected abstract String[] getColumnHeaders();
        
        /** Retorna como un string los elementos *inclu�dos* en el
         *  elemento <data>.
         */
        protected String getDataElements() {
            StringBuffer xml;
            Iterator iter;
            Element current;
            
            xml = new StringBuffer();
            if (dataDestination.getChild("data") != null) {
                iter = this.dataDestination.getChild("data").getChildren().iterator();
                while (iter.hasNext() == true) {
                    current = (Element) iter.next();
                    xml.append("<" + current.getName() + ">");
                    xml.append(current.getContent().get(0));
                    xml.append("</" + current.getName() + ">");
                }
            }
            
            return xml.toString();
        }
        
        public void preProcess(PrintStream out) throws IOException {
            String functionName;
            String dataDestinationName;
            String dataElements;
            String destinationURL;

            if (dataDestination == null) {
                dataDestinationName = "";
                dataElements = "";
                destinationURL  = "";
            } else {
                dataDestinationName = this.dataDestination.getChildTextTrim("name");
                dataElements = this.getDataElements();
                destinationURL = this.dataDestination.getChildTextTrim("destination");
                destinationURL = (destinationURL==null) ? null : destinationURL;
            }            
            out.println("<script language='javascript'>");
            out.println("  var model; ");
            out.println("  var grid; ");

            out.println("function submitGrid(grid, model) {");
            out.println("  transactionSubmitXML(model, " + 
                                                "\"" +  dataDestinationName + "\", " + 
                                                "\"" +  dataElements + "\", " + 
                                                "\"" +  destinationURL + "\"" + 
                                                ");");
            out.println("");
            out.println("}");
            functionName = "createGrid" + 
                           this.gridName.substring(0,1).toUpperCase() + 
                           this.gridName.substring(1);
            out.println("function " + functionName + "() {");
            // Genera:
            // model = new GridModel(new Array("radical", "nom", "centre", "gestor", "import"));  

            out.print("model = new GridModel(new Array(");
            for (int i=0; i < this.getColumnHeaders().length; i++) {
                out.print("\"" + getColumnHeaders()[i] + "\"");
                if (i != this.getColumnHeaders().length -1) {
                    out.print(", ");
                }
            }
            out.println("));");
        }

        public void postProcess(PrintStream out) throws IOException {
            out.println("grid = new Grid(\"" + gridName + "\", model, " + editable + ", submitGrid);");
            out.println("grid.write();");
            out.println("}");
            out.println("</script>");
        }    

        public void processRecord(PrintStream out, MetaData meta, ResultSet rs) throws IOException, SQLException {
            StringBuffer array;
            String current;
            
            array = new StringBuffer();
            array.append("new Array(");
            for (int i=0; i < meta.getColumnCount(); i++) {
                current = rs.getString(i+1);
                current = (current == null) ? "" : current;
                // Si es alfanum�rico le a�adimos las comillas
                // Si es num�rico y vac�o ("") lo pasamos a cero.
                if (meta.getColumnMetaData(i).isAlfa() == true) {
                    current = "\"" + current + "\"";
                } else if (current.length() == 0) {
                    current = "0";
                }
                array.append(current + ", ");
            }
            if (array.length() > 0) { array.setLength(array.length()-2); }
            array.append(")");
            
            out.println("model.addElement(" + array.toString() + ");");
        }    
    }
    
        
    /** Testea la clase.
     */    
    public static void main(String[] args) throws Exception {
        TrsConfigLog4j trsLog;
        Connection con;
        com.echiceros.system.pooling.Cache cache;
        TrsJsGridCreate trs;
        String xml;
        
        xml = 
          "    <data>"+
          "      <configPath>d:/userinfo/tomcat3/webapps/vincere/web-inf/log4jconfig.xml</configPath>"+
          "    </data>";
        
        trsLog = new TrsConfigLog4j();
        trsLog.setDefinition(xml);
        trsLog.execute();

        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        con = DriverManager.getConnection("jdbc:odbc:fca005-0");
        cache = com.echiceros.system.pooling.Cache.createCache(Trs.DEFAULT_CONNECTION_CACHE_NAME, 4);
        cache.put(con);
        
        xml = 
         "   <data>" + 
         "      <gridname>ranking</gridname>" + 
         "      <datasource>java:com.echiceros.www.ui.fools.TrsDemoDataSource</datasource>" + 
         "      <editable>true</editable>" + 
         "      <datadestination>java:com.echiceros.www.ui.fools.TrsDemoDataUpdate</datadestination>" + 
         "      <trsdestination>trsresult.jsp</trsdestination>" + 
         "   </data>";
        trs = new TrsJsGridCreate();
        trs.setDefinition(xml);
        trs.setOut(new PrintStream(System.out));
        trs.execute();
        
        System.exit(0);
    }
}


