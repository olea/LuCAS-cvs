/*
 * TrsXMLUpdate.java
 *
 * Created on 21 de septiembre de 2001, 12:21
 */

package com.echiceros.bd.trs;

import java.util.*;
import java.sql.*;
import org.jdom.*;
import org.apache.log4j.*;
import com.echiceros.bd.*;
import com.echiceros.lang.*;
import com.echiceros.system.pooling.Cache;

/**
 * Permite actualizar la base de datos a partir de un documento
 * xml en el que se especifican los registros que deben ser
 * insertados o actualizados. Puede espcificarse un pool de 
 * conexiones por defecto (elemento "defaultcache")  y una
 * tabla predeterminada (defaulttable). Tambi�n pueden mapearse
 * los nombres utilizados en los campos con la cache/tabla/columna
 * correspondiente.
 *
 *         <data>      
 *           <defaultcache>mainDataSource</defaultcache>
 *           <defaulttable>fca005</defaulttable>
 *           <map name="radical" column="fca005.rcraci"/>
 *           <map name="data"    column="fca005.fcdtev"/>
 *           <map name="client"  column="fca005.rcnom"/>
 *           <record>    
 *             <field name= "RADICAL" value="444444" />    
 *             <field name= "DATA" value="20010101"/>    
 *             <field name= "CLIENT" value="Javier Moreno\" original="Javi" />    
 *           </record>    
 *           <record>    
 *             <field name= "RADICAL" value="55555" />    
 *             <field name= "DATA" value= "20010101" />    
 *             <field name= "CLIENT" value= "Gloria Cruz" original="glo"/>    
 *           </record>     
 *         </data>  
 * 
 *  En caso de que la transacci�n (en su conjunto) se realice correctamente
 *  se generar� un mensaje xml de success. Si falla en cualquiera de los
 *  registros se proceder� al rollback de *todas* las operaciones ya 
 *  efectuadas, se escribir� un mensaje de error y se lanzar� una 
 *  TrsException.
 *
 *      <serviceResponse>
 *        <type>success</type>
 *        <data>
 *      <code>0</code>
 *      <description>com.echiceros.bd.trs.TrsXMLUpdate: 2 updates done.</description>
 *        </data>
 *      </serviceResponse> 
 *
 *      <serviceResponse>
 *         <type>error</type>
 *         <data>
 *            <code>-1</code>
 *            <description>java.sql.SQLException: [Microsoft][ODBC SQL Server Driver][SQL Server]L�nea 1: sintaxis incorrecta cerca de '='.</description>
 *          </data>
 *      </serviceResponse> 
 * 
 * [PENDIENTE] Agregar autonum�ricos.
 * [PENDIENTE] Agregar soporte para maestro/detalle.
 * [PENDIENTE] Agregar soporte multitabla por registro (�merece la pena?)
 *
 * @author  jv
 * @version 1.3 (no liberada)
 * 
 */
public class TrsXMLUpdate extends TrsAdapter {
    /** Si el mapeo no especifica una tabla, se toma esta por defecto. */
    String defaultTableName;
    /** Si el mapeo no especifica una cache, se toma esta por defecto. */
    String defaultCacheName;
    /** Mapeo field/name --> cache, tabla, columna. */
    Hashtable fieldMapping;
    
    PreparedStatement stmtInsert;
    PreparedStatement stmtUpdate;
    
    /** Creates new TrsXMLUpdate */
    public TrsXMLUpdate() {
        super();
        this.fieldMapping = new Hashtable();
    }
    
    /** Crea un nuevo TrsXMLUpdate fijando su definici�n.
     * @param xml Los datos a actualizar.
     */
    public TrsXMLUpdate(String xml) {
        this();
        this.setDefinition(xml);
    }
            
    /** Crea el mapeo y comienza el procesamiento de los registros. */
    public void execute() throws TrsException {
        MultivalueHashtable generators;
        String result = null;
        
        try {
            Category.getInstance(getClass()).info("Ejecutando.");
            this.createMapping();
            generators = this.createGenerators();
            this.executeImp(generators);
            result = TransactionEngine.createSuccessXML(
                        "<code>0</code>\n" + 
                        "<description>" +
                           getClass().getName() + ": " +
                           generators.getSize() + " updates done." +
                        "</description>\n");
        }
        catch (SQLException e) {
            Category.getInstance(getClass()).info("Error: " + e + ".");
            // Ya lo hace el transactionengine!!
            // result = TransactionEngine.createErrorXML("-1", e.toString());
            throw new TrsException(getClass().getName() + ": " + e);
        }
        finally {
            Category.getInstance(getClass()).info("Fin de ejecuci�n.");
            out.println(result);
        }
    }
    
    /** Crea el mapeo. Fija cache y tabla por defecto. */
    protected void createMapping() {
        Iterator iter;
        Element current;
        
        iter = this.definition.getChildren("map").iterator();
        while (iter.hasNext() == true) {
            current = (Element) iter.next();
            this.addMapping(
                     current.getAttributeValue("name"),
                     current.getAttributeValue("column"));
        }
        this.defaultCacheName = definition.getChildTextTrim("defaultcache");
        this.defaultTableName = definition.getChildTextTrim("defaulttable");
    }
    
    /** Agrega un nuevo mapeo a los existentes. */
    public void addMapping(String name, String column) {
        FieldMap fieldMap;
        
        fieldMap = new FieldMap(name, column);
        this.fieldMapping.put(fieldMap.getName().toUpperCase(), fieldMap);
    }
    
    /** Fija la tabla por defecto. */
    public void setDefaultTableName(String value) {
        this.defaultTableName = value;
    }
    
    /** Fija la cach� por defecto. */
    public void setDefaultCacheName(String value) {
        this.defaultCacheName = value;
    }
    
    /** @returns el FieldMap del field cuyo name se indica (null si no existe). */
    protected FieldMap getFieldMap(String fieldName) {
        FieldMap map;
        
        map = (FieldMap) fieldMapping.get(fieldName.toUpperCase());
        if (map == null) {
            Category.getInstance(getClass()).debug(
                  "FieldMap not found (" + fieldName + ").");
        }
        
        return map;
    }
    
    /** Analiza la definici�n (los registros) los clasifica seg�n
     * la tabla a la que correspondan y crea los UpdateSQLGenerators
     * necesarios para insertarlos.
     *
     * @throws SQLException Si la creaci�n de un generator falla.
     */    
    protected MultivalueHashtable createGenerators() throws SQLException {
      MultivalueHashtable generators;
      Iterator iter;
      Element currentRecord;
      UpdateSQLGenerator gen;
            
      generators = new MultivalueHashtable();
      iter = definition.getChildren("record").iterator();
      while (iter.hasNext() == true) {
          currentRecord = (Element) iter.next();
          gen = getGenerator(currentRecord);
          generators.put(gen.getTable(), gen);
      }
      
      return generators;
    }      
    
    protected UpdateSQLGenerator getGenerator(Element record) 
    throws SQLException {
        UpdateSQLGenerator gen;
        Iterator iter;
        Element field;
        String name, table, column, value, original;
        FieldMap map;
        
        
        field = record.getChild("field");
        name = field.getAttributeValue("name");
        map = (FieldMap) this.getFieldMap(name);
        table = map.getTable();
        table = (table == null) ? this.defaultTableName : table;
        
        gen = new UpdateSQLGenerator(table);
        iter = record.getChildren("field").iterator();
        while (iter.hasNext() == true) {
           field = (Element) iter.next();
           name = field.getAttributeValue("name");
           map = getFieldMap(name);
           column = map.getColumn();
           value = field.getAttributeValue("value");
           original = field.getAttributeValue("original");
           gen.addValue(column, value, original);
        } 
        
        gen.close();
        return gen;
    }
    
    protected void executeImp(MultivalueHashtable generators) 
    throws SQLException {
        Vector connections = null;
        Connection con;
        Statement stmt;
        Iterator tableKeys;
        Iterator genIter;
        UpdateSQLGenerator gen = null;
        int conIdx;
        String errMsg = null;
        
        try {
            connections = executeImpCreateConns(generators);        
            tableKeys = generators.keys();
            conIdx = 0;
            while (tableKeys.hasNext() == true) {
                genIter = generators.get(tableKeys.next());
                con = (Connection) connections.elementAt(conIdx);
                stmt  = con.createStatement();
                while (genIter.hasNext() == true) {
                    gen = (UpdateSQLGenerator) genIter.next();
                    try {
                        stmt.executeUpdate(gen.getInsert());
                    } 
                    catch (SQLException e) {
                        stmt.executeUpdate(gen.getUpdate());
                    }
                }
                conIdx = conIdx + 1;
            }
            Category.getInstance(getClass()).info(
                "N�mero de actualizaciones: " + conIdx + ".");
        }
        catch (SQLException e) {
            errMsg = e.getMessage() + ":\n\t"  + 
                     gen.getInsert() + "\n\t" + gen.getUpdate();
            throw e;
        }
        finally {               
            if (connections != null) {
              executeImpFreeConns(generators, connections, errMsg == null);
            }
        }
    }
    
    protected Vector executeImpCreateConns(MultivalueHashtable generators)  
    throws SQLException {   
        Vector connections;
        Connection con;
        Iterator keys;
        String table;
        Cache cache;
              
        connections = new Vector();
        keys = generators.keys();
        while (keys.hasNext() == true) {
            table = (String) keys.next();
            cache = CacheFinder.getInstance().getCacheWithTable(table);
            if (cache == null) {
                cache = Cache.getCache(this.defaultCacheName);
            }
            con = (Connection) cache.get(true);
            con.setAutoCommit(false);
            connections.addElement(con);
        }
        
        Category.getInstance(getClass()).debug(
            "Reservadas " + connections.size() + " conexiones.");
        
        return connections;
    }
    
    protected void executeImpFreeConns(MultivalueHashtable generators,  
                                         Vector connections, boolean commit) {  
        Iterator keys;
        Cache cache;
        Connection con;
        String table;
        int conIdx;
        
        keys = generators.keys();
        conIdx = 0;
        while (keys.hasNext() == true) {
            table = (String) keys.next();
            cache = CacheFinder.getInstance().getCacheWithTable(table);
            con = (Connection) connections.elementAt(conIdx);
            try {
                if (commit == true) {
                    con.commit();
                }
                else {
                    con.rollback();
                }
            }
            catch (SQLException e) {
            }
            try {
              con.setAutoCommit(true);
            }
            catch (SQLException e) {
            }
            cache.put(con);
            conIdx = conIdx + 1;
        }
        Category.getInstance(getClass()).debug(
            "Liberadas " + conIdx + " conexiones.");
    }
    
    class FieldMap {

        /** Holds value of property name. */
        private String name;
                
        /** Holds value of property column. */
        private String column;
        
        public FieldMap(String name, String column) {
            setName(name);
            setColumn(column);
        }
        
        /** Getter for property name.
         * @return Value of property name.
         */
        public String getName() {
            return this.name;
        }
        
        /** Setter for property name.
         * @param name New value of property name.
         */
        public void setName(String name) {
            this.name = name;
        }
                
        /** Retorna la parte del name correspondiente a la tabla
         *  (antes del .) o null si no existe.
         * @return Value of property table.
         */
        public String getTable() {
            int pos;
            String table;
            
            pos = column.indexOf('.');
            if (pos != -1) {
                table = column.substring(0, pos);
            } else {
                table = null;
            }
            
            return table;
        }
        
        /** Getter for property column.
         * @return Value of property column.
         */
        public String getColumn() {
            int pos;
            String column;
            
            pos = this.column.indexOf('.');
            if (pos != -1) {
                column = this.column.substring(pos+1);
            } else {
                column = null;
            }
            
            return column;
        }
        
        /** Setter for property column.
         * @param column New value of property column.
         */
        public void setColumn(String column) {
            this.column = column;
        }
        
    }
            
    public static void main(String[] args) throws Exception {                
        String xml;
        Connection con;
        Cache cache;
        TrsXMLUpdate trs;
        
        xml =
           "<data>"+      
             "<defaulttable>fca005</defaulttable>"+
             "<map name=\"radical\" column=\"fca005.fcraci\"/>"+
             "<map name=\"data\"    column=\"fca005.fcdtev\"/>"+
             "<map name=\"client\"  column=\"fca005.fcnomc\"/>"+
             "<record>    "+
               "<field name= \"RADICAL\" value=\"55555\" />    "+
               "<field name= \"DATA\" value= \"20010111\" />    "+
               "<field name= \"CLIENT\" value= \"Gloria Cruz\" />    "+
             "</record>     "+
             "<record>    "+
               "<field name= \"RADICAL\" value=\"444444\" />    "+
               "<field name= \"DATA\" value=\"20010111\"/>    "+
               "<field name= \"CLIENT\" value=\"Javier Moreno\" />    "+
             "</record>    "+
           "</data>  ";
         
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        cache = Cache.createCache("mainDataSource", 20);
        for (int i=0; i < 5; i++) {
            con = DriverManager.getConnection("jdbc:odbc:fca005-0");
            cache.put(con);
        }
        trs = new TrsXMLUpdate();
        trs.setOut(System.out);
        trs.setDefinition(xml);
        trs.execute();
        System.exit(0);
    }
    
    
}
