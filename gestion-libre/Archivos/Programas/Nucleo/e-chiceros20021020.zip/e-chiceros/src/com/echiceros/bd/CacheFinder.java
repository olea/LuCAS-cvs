/*
 * CacheFinder.java
 *
 * Created on 8 de enero de 2002, 15:41
 */

package com.echiceros.bd;

import java.util.*;
import java.sql.*;
import com.echiceros.system.pooling.*;

/**
 *
 * Permite localizar qu� cach� de conexiones a base de datos
 * posee la conexi�n adecuada para acceder a una determinada tabla.
 * Solo resulta �til para nombres de tabla �nicos.
 *
 * @author  jv
 */
public class CacheFinder {
    /** Instancia por defecto. */
    static CacheFinder defaultInstance = null;
    
    /** Tablas ya localizadas asociadas a su cach�. */
    Hashtable memory;
    
    /** Creates a new instance of CacheFinder */
    public CacheFinder() {
        this.memory = new Hashtable();
    }
    
    /** Localiza la cach� que contiene conexiones a una tabla. 
     *  @param tableName Nombre de la tabla a buscar.
     *  @returns la cach� que contiene la tabla o null si no se encuentra.
     */
    public Cache getCacheWithTable(String tableName) {
        Cache res;
        
        res = (Cache) this.memory.get(tableName.toUpperCase());
        if (res == null) {
            res = getCacheWithTableImp(tableName);
        }
        
        return res;
    }
    
    /** Localiza la cach� que contiene conexiones a una tabla. 
     *  Trata de localizarla primero en la cach� cuyo nombre se indica.
     *
     *  @param lookAt Id de la cach� en la que deber�a mirarse en 
     *                primer lugar. Si es null o no se encuentra la tabla
     *                en ella se contin�a con el resto.
     *  @param tableName Nombre de la tabla a buscar.
     *  @returns la cach� que contiene la tabla o null si no se encuentra.
     */
    public Cache getCacheWithTable(Object lookAt, String tableName) {
        Cache res;
        
        // Trata de localizarla en la memoria.
        res = (Cache) this.memory.get(tableName.toUpperCase());
        if (lookAt != null) {
            // Si no se ha encontrado o no es la cach� que hemos pedido...
            if ((res == null) || (res.getItsId().equals(lookAt) == false)) {
                res = Cache.getCache(lookAt);
                if (res != null) {
                    if (this.existsTable(res, tableName) == false) {
                        res = null;
                    }
                } 
            }
        }
        if (res == null) {
            res = this.getCacheWithTable(tableName);
        }
        
        return res;
    }
    
    /** Localiza la cach� que contiene conexiones a una tabla. */
    protected Cache getCacheWithTableImp(String tableName) {
        Cache res;
        Cache rootCache;
        Iterator iter;
        Object currentId;
        Cache currentCache;
        Object currentElement;
        
        rootCache = Cache.getDefaultCache();
        iter = rootCache.getIdentifiers();
        res = null;
        while ((res == null) && (iter.hasNext() == true)) {
            currentId = iter.next();
            currentCache = (Cache) rootCache.getCache(currentId);
            currentElement = currentCache.get(false);
            if (currentElement instanceof java.sql.Connection) {
                if (existsTable(currentCache, tableName) == true) {
                    res = currentCache;
                }
            }
        }
        
        if (res != null) {
            this.memory.put(tableName.toUpperCase(), res);
        }
        
        return res;
    }
    
    /** Comprueba si en una conexi�n de la cach� indicada existe la
     *  tabla requerida. La actual implementaci�n se basa en realizar
     *  un select count(*), pero podria utilizarse el metadata.
     */
    protected boolean existsTable(Cache cache, String tableName) {
        boolean res;
        Connection con;
        Statement stmt;
        
        res = false;
        try {
            con = (Connection) cache.get(true);
            stmt = con.createStatement();
            stmt.executeQuery("SELECT count(*) FROM " + tableName);
            stmt.close();
            cache.put(con);
            res = true;
        }
        catch (SQLException e) {
        }
        
        
        return res;
    }
    
    /** Retorna la instancia por defecho. */
    public static CacheFinder getInstance() {
        if (defaultInstance == null) {
            defaultInstance = new CacheFinder();
        }
        
        return defaultInstance;
    }

}
