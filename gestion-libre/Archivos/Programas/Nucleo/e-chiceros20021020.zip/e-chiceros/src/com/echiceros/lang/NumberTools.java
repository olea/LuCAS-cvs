/*
 * NumberTools.java
 *
 * Created on 7 de febrero de 2002, 10:44
 */

package com.echiceros.lang;

import java.text.*;

/**
 * Caj�n de sastre para rutinas relacionadas con n�meros.
 *
 * @author  jv
 */
public class NumberTools {

   
    static DecimalFormat decformat2d = null;
    /** @returns el valor redondeado a dos decimales, como un string. */
    public static String format2d(double value) {
        if (decformat2d == null) {
            decformat2d = new DecimalFormat("#,##0.00");
        }
        return decformat2d.format(value);
    }
}
