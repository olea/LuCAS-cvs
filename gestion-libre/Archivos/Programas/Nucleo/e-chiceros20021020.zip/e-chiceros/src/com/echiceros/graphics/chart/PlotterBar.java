/*
 * PlotterPoint.java
 *
 * Created on 7 de febrero de 2002, 10:11
 */

package com.echiceros.graphics.chart;

import java.util.*;
import java.awt.*;
import java.awt.Graphics.*;
import com.echiceros.util.OrderedEnumeration;

/**
 *
 * @author  Administrador
 */
public class PlotterBar extends com.echiceros.graphics.chart.Plotter {
    
    /** Creates a new instance of PlotterPoint */
    public PlotterBar() {
        super(false);
    }
    
    public PlotterBar(boolean drawLabels) {
        super(drawLabels);
    }

    /** Dibuja los puntos en un lienzo.
     *
     * @param Ejes de coordenadas.
     * @param Puntos a dibujar.
     * @param Lienzo.
     * @param Tama�o de lienzo.
     * @param M�rgenes del lienzo.
     */
    public void drawPoints(Graphics graphics, Dimension size, Insets insets, 
                           Axe[] axes, ArrayList points) {
        Enumeration enum;    // Recorremos los puntos con �l.
        ChartPoint cpoint;   // Punto l�gico actual.
        Point fpoint;        // Punto f�sico (de graphics) actual.
        String text;         // Texto de la leyenda
        double y0;           // Altura de y==0.
        double barHeight;    // Altura de la barra hasta punto actual
        double barWidth;     // Ancho de la barra 
        double minDist;      // Distancia m�nima entre dos X de la gr�fica 
        int    minDistPx;    // P�xels m�nimos entre dos puntos de la gr�fica 
        Vector zValues;      // Valores diferentes del eje de las z, ordenados
        int    zOrder;       // Posici�n ocupada por Z en zValues
        double x;            // D�nde dibujar la barra
        Color color;         // Color primario a utilizarba
        
        minDist = axes[Axe.X].getMinDistance(points);
        if (Double.MAX_VALUE - minDist <= 0.1) {
            minDistPx = 50;
        } else {
            minDistPx = (int) ((size.width - insets.left - insets.right) *  minDist);
        }
        zValues = calcDiffZValues(points.iterator());
        barWidth = minDistPx / zValues.size();
        enum = axes[Axe.X].getOrderedPoints(points);
        while (enum.hasMoreElements() == true) {
            cpoint = (ChartPoint) enum.nextElement();
            fpoint = getPoint(size, insets, axes, cpoint);
            zOrder = zValues.indexOf(cpoint.getZ());
            color = this.getPointColor(axes, cpoint, zOrder);
            barHeight = size.height - insets.bottom - fpoint.getY();
            y0 = size.height-insets.bottom - barHeight; 
            graphics.setColor(color.darker());
            x = fpoint.x - (minDistPx / 2) + (barWidth * zOrder) + 5;
            graphics.fillRect((int) x-4, (int) y0-2, 
                              (int) barWidth-3, (int) barHeight+2);
            graphics.setColor(color);
            graphics.fillRect((int)x-6, (int) y0, 
                              (int) barWidth-3, (int) barHeight);
            if (super.drawLabels == true) {
                text = axes[Axe.Y].getLabelValue(cpoint.getY());
                super.drawLabel(graphics, (int) (x + (barWidth-12)/2), 
                                fpoint.y, text);
                if (axes[Axe.Z] != null) {
                    text = axes[Axe.Z].getLabelValue(cpoint.getZ());
                    super.drawLabel(graphics, (int) (x + (barWidth-12)/2), 
                                    fpoint.y-12, text);
                }
            }
            graphics.setColor(Color.orange);
            graphics.fillOval(fpoint.x-3, size.height-insets.bottom-2, 5, 5);
        }
    }
    
    
}
