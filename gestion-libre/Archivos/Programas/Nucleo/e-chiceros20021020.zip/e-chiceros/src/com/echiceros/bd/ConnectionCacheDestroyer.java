/*
 * ConnectionCacheDestroyer.java
 *
 * Created on 14 de agosto de 2002, 14:39
 */

package com.echiceros.bd;

import java.sql.*;
import org.apache.log4j.*;
import com.echiceros.system.pooling.*;

/**
 *
 * @author  jv
 */
public class ConnectionCacheDestroyer implements CacheDestroyer {
    
    public void destroy(Cache cache) {
        Connection con;
        
        while (cache.getSize() > 0) {
            try {
                con = (Connection) cache.get(true);
                con.close();
                Category.getInstance(getClass()).debug(
                "Conexi�n " + (cache.getSize() + 1) + " de " +
                cache.getItsId() + " liberada.");
            }
            catch (SQLException e) {
                Category.getInstance(getClass()).warn(e.getMessage());
            }
        }
        Category.getInstance("com.echiceros.system.pooling.Cache").info(
        "Cach� " + cache.getItsId() + " vaciada correctamente.");
    }
}

