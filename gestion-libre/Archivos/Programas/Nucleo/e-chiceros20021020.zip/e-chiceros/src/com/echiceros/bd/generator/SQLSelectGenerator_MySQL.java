/*
 * MySQLSelectGenerator.java
 *
 * Created on 25 de agosto de 2002, 17:47
 */

package com.echiceros.bd.generator;

/**
 *
 * @author  jv
 */
public class SQLSelectGenerator_MySQL extends SQLSelectGenerator {
    
    /** Creates a new instance of MySQLSelectGenerator */
    public SQLSelectGenerator_MySQL() {
        super();
    }
    
    public String getSentence() {
        StringBuffer sentence;
        
        sentence = new StringBuffer(super.getSentence());
        
        if (this.howMany != -1) {
            sentence.append(" LIMIT " + howMany);
        }
        
        return sentence.toString();
    }
    
}
