package com.echiceros.math;


/** Diversas operaciones matem�ticas no implementadas en las 
    librear�as est�ndar.

    @author Javi
    @version 16/08/99    
 */
public class Operations implements java.io.Serializable {
  public static double PRECISION = 0.001;
  
    /** Redondea un double hasta dejarlo en el n�mero de decimales
      indicados.

      @param value El double a redondear.
      @param decimals N�mero de decimales que deseamos.
      @result Un double en el que se ha efectuado el redondeo.
  */
  public static String roundStr(double value, int decimals) {
    java.text.DecimalFormat df;
    StringBuffer format;
    String formated;
    
    format = new StringBuffer();
    format.append("0.");
    
    for (int i=0; i < decimals; i++) { 
        format.append("0");
    }
    
    df = new java.text.DecimalFormat(format.toString());
    formated = df.format(value);
    
    formated = com.echiceros.lang.StringTools.replace(formated, ",", ".");
    
    return formated;
  }
  
  /** Redondea un double hasta dejarlo en el n�mero de decimales
      indicados.

      @param value El double a redondear.
      @param decimals N�mero de decimales que deseamos.
      @result Un double en el que se ha efectuado el redondeo.
  */
  public static double round(double value, int decimals) {
    double res;
    String formated;
    
    formated = roundStr(value, decimals);
    res = Double.parseDouble(formated);
    
    if (Math.abs(res) < 0.0001) { res = 0.0; }
    
    return res;
  }

  /** Retorna el n�mero de cifras del que consta un n�mero. */
  public static int length(long value) {
    int res;

    res = 0;
    while (value > 0) {
      res = res +1;
      value = value / 10;
    }

    return res;
  }

  /** Retorna el resultado de dividir ambos par�matros, o 0.0 si
   *  el segundo par�metro vale 0.0.
   */
  public static double safeDiv(double a, double b) {
    double res;
    
    res =  (Math.abs(b) < PRECISION) ? +0.0 : a/b;
    return res;
  }


  public static void main(String args[]) {
     System.out.println(roundStr(0.0, 2));

  }

}