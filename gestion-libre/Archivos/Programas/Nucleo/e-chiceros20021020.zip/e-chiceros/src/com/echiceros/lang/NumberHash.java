package com.echiceros.lang;

import java.util.*;

public class NumberHash extends java.lang.Object {

    double[] vals;
    Hashtable names;
    int firstFree;
    
    public NumberHash() {
        this.vals = new double[50];
        this.names = new Hashtable();
        firstFree = 0;
    }
    
    public void put(String key, double value) { 
      Integer idx;
      
      idx = (Integer) names.get(key);
      
      if (idx == null) {
        idx = new Integer(this.firstFree);
        this.incFirstFree();
      }
      names.put (key, idx);
      vals[idx.intValue()] = value;
    }
    
    public double getDouble(String key) {
      Integer idx;
      
      idx = (Integer) names.get(key);
      if (idx == null) {
        throw new IllegalArgumentException("NumberHash.getDouble('"+key+"')");
      }
      
      return vals[idx.intValue()];
    }

    public int getInt(String key) {
      Integer idx;
      
      idx = (Integer) names.get(key);
      if (idx == null) {
        throw new IllegalArgumentException("NumberHash.getInt('"+key+"')");
      }
      
      return (int) vals[idx.intValue()];
    }
    
    public void inc(String key, double value) {
      Integer idx;
      
      idx = (Integer) names.get(key);
      if (idx == null) {
        this.put(key, value);
      }
      else {
        vals[idx.intValue()] += value;
      }
    } 
    
    public boolean exists(String key) {
        return (names.get(key) != null);
    }
    
    
    public Enumeration getKeys() {
      return names.keys();
    }
    
    protected void incFirstFree() {
      double[] tmp = null;
        
      this.firstFree = this.firstFree + 1;
      if (firstFree >= vals.length) {
        tmp = new double[vals.length+50];
        for (int i=0; i < vals.length; i++) {
          tmp[i] = vals[i];
        }        
        this.vals = tmp;
      }
    }
    
    public String toString() {
        StringBuffer res;
        Enumeration keys;
        String name;
        double value;
        
        res = new StringBuffer();
        keys = getKeys();
        while (keys.hasMoreElements() == true) {
          name = (String) keys.nextElement();
          value = getDouble(name);
          res.append(name + " = " + value + ", ");          
        }
        if (res.length() > 0) { res.setLength(res.length()-2); }
        
        return res.toString();
    }
    
    public static void main(String[] args) { 
      NumberHash t;
      
      t = new NumberHash();
      
      t.inc("fctar006e", 2);
      t.inc("fctar006e", 2);
      t.inc("fctar006e", 2);
      
      System.out.println(t.getDouble("fctar006e"));
      
    }
}
