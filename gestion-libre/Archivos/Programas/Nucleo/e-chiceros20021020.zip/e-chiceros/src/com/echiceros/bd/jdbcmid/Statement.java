/*
 * Statement.java
 *
 * Created on 30 de junio de 2002, 15:50
 */

package com.echiceros.bd.jdbcmid;

import java.util.*;
import java.sql.*;
import com.echiceros.bd.jdbcmid.transformers.*;

/**
 *
 * com.echiceros.bd.jdbcmid.Connection retorna este tipo de statements,
 * lo que permite interceptar la invocaci�n de sus m�todos para, por ejemplo,
 * modificar la sql antes de que se llegue a ejecutar.
 *
 * Ser�a interesante reescribir el nombre de los argumentos de algunos
 * de los m�todos para que tuviesen alguna l�gica :|
 *
 * @author  jv
 */
public class Statement implements java.sql.Statement {
    com.echiceros.bd.jdbcmid.Connection con;
    java.sql.Statement realStatement;
    
    
    /** Creates a new instance of Statement */
    public Statement(Connection con, java.sql.Statement realStatement) {
        super();
        this.con = con;
        this.realStatement = realStatement;
    }
    
    protected String transformSQL(String sql, Enumeration transformers) {
        SQLTransformation trans; 
        String transformedSQL; 
        
        transformedSQL = sql;
        while (transformers.hasMoreElements() == true) {
            trans = (SQLTransformation) transformers.nextElement();
            transformedSQL = trans.transformSql(transformedSQL);
        }
        
        return transformedSQL;
    }
    
    public void addBatch(String str) throws SQLException {
        this.realStatement.addBatch(str);
    }
    
    public void cancel() throws SQLException {
        this.realStatement.cancel();
    }
    
    public void clearBatch() throws SQLException {
        this.realStatement.clearBatch();
    }
    
    public void clearWarnings() throws SQLException {
        this.realStatement.clearWarnings();
    }
    
    public void close() throws SQLException {
        this.realStatement.close();
    }
    
    public boolean execute(String str) throws SQLException {
        return this.realStatement.execute(str);
    }
       
    public int[] executeBatch() throws SQLException {
        return this.realStatement.executeBatch();
    }
    
    public ResultSet executeQuery(String sql) throws SQLException {
        String transformedSQL;
        
        transformedSQL = this.transformSQL(sql, con.getQueryTransformations());
        
        return this.realStatement.executeQuery(transformedSQL);
    }
    
    public int executeUpdate(String sql) throws SQLException {
        String transformedSQL; 
                
        transformedSQL = this.transformSQL(sql, con.getUpdateTransformations());
        
        return this.realStatement.executeUpdate(transformedSQL);
    }    
    
    public java.sql.Connection getConnection() throws SQLException {
        return con;
    }
    
    public int getFetchDirection() throws SQLException {
        return this.realStatement.getFetchDirection();
    }
    
    public int getFetchSize() throws SQLException {
        return this.realStatement.getFetchSize();
    }
    
    public int getMaxFieldSize() throws SQLException {
        return this.realStatement.getMaxFieldSize();
    }
    
    public int getMaxRows() throws SQLException {
        return this.realStatement.getMaxRows();
    }
    
    public boolean getMoreResults() throws SQLException {
        return this.realStatement.getMoreResults();
    }
    
    public int getQueryTimeout() throws SQLException {
        return this.realStatement.getQueryTimeout();
    }
    
    public ResultSet getResultSet() throws SQLException {
        return this.realStatement.getResultSet();
    }
    
    public int getResultSetConcurrency() throws SQLException {
        return this.realStatement.getResultSetConcurrency();
    }
    
    public int getResultSetType() throws SQLException {
        return this.realStatement.getResultSetType();
    }
    
    public int getUpdateCount() throws SQLException {
        return this.realStatement.getUpdateCount();
    }
    
    public SQLWarning getWarnings() throws SQLException {
        return this.realStatement.getWarnings();
    }
    
    public void setCursorName(String str) throws SQLException {
        this.realStatement.setCursorName(str);
    }
    
    public void setEscapeProcessing(boolean param) throws SQLException {
        this.realStatement.setEscapeProcessing(param);
    }
    
    public void setFetchDirection(int param) throws SQLException {
        this.realStatement.setFetchDirection(param);
    }
    
    public void setFetchSize(int param) throws SQLException {
        this.realStatement.setFetchSize(param);
    }
    
    public void setMaxFieldSize(int param) throws SQLException {
        this.realStatement.setMaxFieldSize(param);
    }
    
    public void setMaxRows(int param) throws SQLException {
        this.realStatement.setMaxRows(param);
    }
    
    public void setQueryTimeout(int param) throws SQLException {
        this.realStatement.setQueryTimeout(param);
    }

    /* jdk1.4 *********************************************************
     
    public int executeUpdate(String sql, int value) throws SQLException {
        String transformedSQL; 
                
        transformedSQL = this.transformSQL(sql, con.getUpdateTransformations());
        
        return this.realStatement.executeUpdate(transformedSQL, value);
    }
     
    public int executeUpdate(String sql, String[] columnNames) throws SQLException {
        String transformedSQL; 
                
        transformedSQL = this.transformSQL(sql, con.getUpdateTransformations());
        
        return this.realStatement.executeUpdate(transformedSQL, columnNames);
    }
    
    public int executeUpdate(String sql, int[] values) throws SQLException {
        String transformedSQL; 
                
        transformedSQL = this.transformSQL(sql, con.getUpdateTransformations());
        
        return this.realStatement.executeUpdate(transformedSQL, values);
    }
   
    public boolean getMoreResults(int value) throws SQLException {
        return this.realStatement.getMoreResults(value);
    }
    
    public ResultSet getGeneratedKeys() throws SQLException{
        return this.realStatement.getGeneratedKeys();
    }

    
    public int getResultSetHoldability() throws SQLException {
        return this.realStatement.getResultSetHoldability();
    }
    
    public void setHoldability(int value) throws SQLException {
        this.realStatement.setHoldability(value);
    }
    
    public boolean execute(String str, int param) throws java.sql.SQLException {
        return this.realStatement.execute(str, param);
    }
    
    public boolean execute(String str, String[] str1) throws java.sql.SQLException {
        return this.realStatement.execute(str, str1);
    }
    
    public boolean execute(String str, int[] values) throws java.sql.SQLException {
        return this.realStatement.execute(str, values);
    }
    
     ************************************************************ */
}
