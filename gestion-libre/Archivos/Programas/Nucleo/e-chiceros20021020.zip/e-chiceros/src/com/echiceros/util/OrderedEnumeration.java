package com.echiceros.util;

import java.util.*;

public class OrderedEnumeration implements Enumeration {
    int idx;
    Object[] elements;

    public OrderedEnumeration(Enumeration original) {
        Vector tmp;

        tmp = new Vector();
        while (original.hasMoreElements() == true) {
            tmp.addElement(original.nextElement());
        }

        this.idx = 0;
        this.elements = tmp.toArray();
        Arrays.sort(this.elements);
    }

    public OrderedEnumeration(Iterator original) {
        Vector tmp;

        tmp = new Vector();
        while (original.hasNext() == true) {
            tmp.addElement(original.next());
        }

        this.idx = 0;
        this.elements = tmp.toArray();
        Arrays.sort(this.elements);
    }
    
    public boolean hasMoreElements() {
        return (idx < elements.length);
    }

    public Object nextElement() {
        Object res;

        res = elements[idx];
        idx = idx +1;
        return res;
    }
    
}
