package com.echiceros.www.ui;


/*
 * JSGridDBLoader.java
 *
 * Created on 3 octubre de 2001, 10:32
 */
import java.util.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.echiceros.io.*;
import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/** 
 * Este servlet debe incluirse en la zona de creaci�n de datos
 * del grid. Cargar� el mismo con datos procedente de la bbdd.
 */
public class JsGridDBLoaderServlet extends HttpServlet {
   
    /** Initializes the servlet.
    */  
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

    }

    /** Destroys the servlet.
    */  
    public void destroy() {
    }

    protected Params checkParameters(HttpServletRequest request) 
    throws IllegalArgumentException {
        Params params;
        
        params = new Params();
        if (request.getParameter("divName") == null) {
            throw new IllegalArgumentException(this.getClass().getName() + 
                  "divName parameter cannot be null.");
        }
        params.divName = request.getParameter("divName");
        if (request.getParameter("columns") == null) {
            throw new IllegalArgumentException(this.getClass().getName() + 
                  "columns parameter cannot be null.");
        }
        params.setColumns(request.getParameter("columns"));
        if (request.getParameter("editable") != null) {
            params.editable = 
               (request.getParameter("editable").equalsIgnoreCase("true")) ?
               true : false;
        }
        
        if (request.getParameter("submitFunction") != null) {
            params.submitFunction = request.getParameter("submitFunction");
        }
        
        if (request.getParameter("transactionClassName") != null) {
            params.transactionClassName = request.getParameter("transactionClassName");
        }
        
        if (request.getParameter("trsxml") != null) {
            params.trsxml = request.getParameter("trsxml");
        }
        return params;
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, 
                                  HttpServletResponse response)
    throws ServletException, IOException {
        PrintStream out;
        Params params;
        TrsSQLSelect.Processor creator;
        Writer writer;
       
        writer = response.getWriter();
        out = new PrintStream(new OutputWriterStream(writer));
        try {
            params = this.checkParameters(request);
            creator = getGridCreatorProcessor(params);
            this.execute(params, out, creator);
        }
        catch (TrsException e) {
            throw new ServletException(this.getClass().getName() + ": " + 
                                       e.getMessage());
        }
        writer.flush();
    } 

    public void execute(Params params, PrintStream out,
                        TrsSQLSelect.Processor processor) 
    throws TrsException {
        TrsSQLSelect trs;

        try {
            trs = (TrsSQLSelect) 
                  Class.forName(params.transactionClassName).newInstance();
            trs.setDefinition(params.trsxml);
            trs.setOut(out);
            trs.setProcessor(processor);
            trs.execute();
        }
        catch(java.lang.ClassNotFoundException e) {
           throw new java.lang.IllegalStateException
             (getClass().getName() + ": " + e.toString() + ".");
        }
        catch(java.lang.IllegalAccessException e) {
           throw new java.lang.IllegalStateException
             (getClass().getName() + ": " + e.toString() + ".");
        }
        catch(java.lang.InstantiationException e) {
           throw new java.lang.IllegalStateException
             (getClass().getName() + ": " + e.toString() + ".");
        }
    }
        
    /** Retornar� la instancia del creador de grids que debe utilizarse. */
    protected TrsSQLSelect.Processor getGridCreatorProcessor(Params params) {
        return new JsGridDBLoaderProcessor(
                           params.divName, params.labels, params.columns, 
                           params.editable, params.submitFunction);
    }
    
    /** Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    } 

    /** Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processRequest(request, response);
    }

    /** Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Crear� el javascript necesario para cargar el grid " + 
               "con los datos de una bd.";
    }

    
    protected static class Params {
        public String divName;
        public String[] columns;
        public String[] labels;
        public String submitFunction = null;
        public boolean editable = false;
        public String transactionClassName = null;
        public String trsxml;
        
        public void setColumns(String columns) {
          StringTokenizer tk;
          Vector auxColumns;
          Vector auxLabels;
          String column;
          String label;
          
          tk = new StringTokenizer(columns, ",");
          auxColumns = new Vector();
          auxLabels = new Vector();
          while (tk.hasMoreTokens() == true) {
            column = tk.nextToken();
            if (column.indexOf('(') == -1) {
                label = column;
            }
            else {
                label = column.substring(column.indexOf('(')+1,      
                                         column.indexOf(')')).trim();
                column = column.substring(0, column.indexOf('(')).trim();
            }
            auxColumns.addElement(column);
            auxLabels.addElement(label);
          }
         
          this.columns = (String[]) auxColumns.toArray(new String[0]);
          this.labels = (String[]) auxLabels.toArray(new String[0]);
        }
    }
    
}
