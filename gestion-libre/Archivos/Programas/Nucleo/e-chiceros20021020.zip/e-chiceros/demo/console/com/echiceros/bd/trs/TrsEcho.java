/*
 * TrsEcho.java
 *
 * Created on 28 de septiembre de 2002, 21:06
 */

package com.echiceros.bd.trs;

import org.apache.log4j.*;

import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 * Esta clase es un ejemplo sencill�simo de Transacci�n. Al
 * invocarse recibe una definici�n de este estilo:
 *
 * <data>
 *    <message>HOLA MUNDO</message>
 * </data>
 *
 * Su comportamiento se limita a responder con un mensaje
 * de echo como el siguiente:
 *
 *   <serviceResponse>
 *     <type>success</type>
 *     <data>
 *        <message>ECHO: HOLA MUNDO</message>
 *     </data>
 *   </serviceResponse> 
 *
 * @author  jv
 */
public class TrsEcho extends com.echiceros.bd.trs.TrsAdapter {
    
    /** Creates a new instance of TrsEcho */
    public TrsEcho() {
        super();
    }
    
    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        String message;
        String data;
        String response;
        
        Logger.getInstance(getClass()).debug("Ejecutando transacci�n.");
        
        message = super.getParam("message");
        if (message == null) {
            throw new TrsException("Illegal Sintaxis.");
        }
        
        data = "<message>" + "ECHO: " + message + "</message>";
        response = TransactionEngine.createSuccessXML(data);
        
        super.write(response);
        
        Logger.getInstance(getClass()).debug("Transacci�n finalizada.");
    }
    
}
