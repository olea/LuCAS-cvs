from com.echiceros.bd import *
from com.echiceros.www.formproc import *

class FrmUpdate(FormProcessor):
        
    def cmdSearch_onClick(self, request, response) :
       #Inicio de la respuesta
       response.setContentType("text/html");
       print

       #Cabecera de javascript
       print self.init()

       #Preparamos la invocaci�n de la transacci�n de b�squeda.
       inv = TransactionInvoker();
       inv.setName("java:com.echiceros.echidemo.trs.client.TrsClientSearch");
       inv.addParam("name", "Javi");
       inv.execute();

       #Tratamos el resultado, recuperando los elementos "client"
       results = inv.getResultDefinition()       
       clients = results.getChild("data").getChildren("client").iterator()

       #Borramos la select en la que aparecer�n nombres encontrados.
       print self.clearSelect("clientSearch");
       #A�adimos cada elemento "client" a la select
       while clients.hasNext() :
           current = clients.next();
           id = current.getChildTextTrim("id")
           name = current.getChildTextTrim("surname") + ", " + current.getChildTextTrim("name")
           print self.addSelectValue("clientSearch", id, name);


       #Finalizamos el bloque html
       print self.done()

       print  "DEBUG: cmdSearch_onClick completado."

    # -------------------------------------------------------------------------


    def cmdUpdate_onClick(self, request, response) :
       #Inicio de la respuesta
       response.setContentType("text/html");
       print

       #Cabecera de javascript
       print self.init()

       #Una instrucci�n javascript (permite ver el gif de "cargando").
       print "alert('simulando lag de cargando...');"

       #Cambiamos el valor de un par de campos de texto
       print self.setFieldValue("clientSurname", \
                                request.getParameter("clientName"))
       print self.setFieldValue("clientName", \
                                request.getParameter("clientSurname"))
       

       #Finalizamos el bloque html
       print self.done()

       print  "DEBUG: cmdUpdate_onClick completado."

    # -------------------------------------------------------------------------

    def cmdLoadClient_onClick(self, request, response) :

       #Inicio de la respuesta
       response.setContentType("text/html");
       print

       #Cabecera de javascript
       print self.init()

       #Cargamos datos en el formulario
       print """
          form = top.main.document.forms.frmClientUpdate;

          form.clientName.value = "Patrick";
          form.clientSurname.value = "Stewart";
          form.clientMoreInfo.value = true;
          form.info.value = "Cargado desde el servidor.";
          form.clientSearch.options.length = 0;
       """

       #Finalizamos el bloque html
       print self.done()

       print  "DEBUG: cmdLoadClient_onClick completado."








