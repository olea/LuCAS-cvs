/** Almacena el estado (activado o desactivado) de todos
  * los componentes del formulario *antes* de que se ejecute
  * el bloqueo. Existir� una entrada en el array para cada form.
 */
var componentStatus = null;

/** Indica que la edici�n de un elemento ha sido desactivada.
  * En Mozilla bloquea el elemento f�sicamente. En Explorer
  * cambia su color de fondo.
 */
function lockElement(formName, elementName) {
   var current;

   if (formName == null) {
       formName = findFieldFormName(fieldName);
   }

   current = document.forms[formName].elements[elementName];
   if (document.all) {
      current.style.backgroundColor = '#C0C0C0';
   } else {
      current.disabled = true;
   }
}

/** Modifica el estilo del campo para permitir su edici�n.
  * En Mozilla desbloquea el elemento f�sicamente. En Explorer
  * cambia su color de fondo.
 */
function unlockElement(formName, elementName) {
   var current;
   var status;

   if (formName == null) {
       formName = findFieldFormName(fieldName);
   }

   current = document.forms[formName].elements[elementName];
   status = componentStatus[formName][elementName];

   if (document.all) {
      current.style.backgroundColor = status.backgroundColor;
   } else {
      current.disabled = false;
   }
}

/** Guarda en componentStatus el estado de cada elemento. 
 */
function saveStatus(formName) {
   var current;
   var status;

   if (componentStatus == null) {
      componentStatus = new Array();
   }
   if (componentStatus[formName] == null) {
      componentStatus[formName] = new Array();
   }

   for (var idx=0; idx < document.forms[formName].elements.length; idx++) {
       current = document.forms[formName].elements[idx];
       status = new Array();
       status['disabled'] = current.disabled;
       status['backgroundColor'] = current.style.backgroundColor;
       componentStatus[formName][current.name] = status;
   }
}

/** Fija el estado almacenado en componentStatus a los elementos
  * correspondientes. 
 */
function restoreElements(formName) {
   var current;
   var status;

   if ((componentStatus != null) && (componentStatus[formName] != null)) {
       for (var idx=0; idx < document.forms[formName].elements.length; idx++) {
           current = document.forms[formName].elements[idx];
           status = componentStatus[formName][current.name];
           if (status.disabled == false) {
              unlockElement(formName, current.name);
           } 
       }
   }

}

/** Bloquea el formulario de manera que no puede modificarse. 
 */
function formLock(formName) {
   if (!formName) {
       for (var i=0; i < document.forms.length; i++) {
           formName = document.forms[i].name;
           saveStatus(formName);
           for (var idx=0; idx < document.forms[formName].elements.length; idx++) {
               current = document.forms[formName].elements[idx];
               if ((current.disabled == false) && (current.name != "cmdFormUnlock")) {
                   lockElement(formName, current.name);
               }
           }
       }
   } else {
       saveStatus(formName);
       for (var idx=0; idx < document.forms[formName].elements.length; idx++) {
           current = document.forms[formName].elements[idx];
           if ((current.disabled == false) && (current.name != "cmdFormUnlock")) {
               lockElement(formName, current.name);
           }
       }
   }
}

/** Desbloquea el formulario indicado. */
function formUnlock(formName) {
   if (!formName) {
      for (var idx=0; idx < document.forms.length; idx++) {
           restoreElements(document.forms[idx].name);
      }
   } else {
       restoreElements(formName);
   }
}

/** Bloquea o desbloquea el formulario indicado. */
function setFormLock(formName, value) {
   if (value == true) {
      formLock(formName);
   } else {
      formUnlock(formName);
   }
}

// -------------------------------------------------------------

/** Activa el indicador de "cargando". */
function showLoading() {
     document.getElementById("imgLoading").style.visibility = "visible";
}

/** Desactiva el indicador de "cargando." */
function hideLoading() {
     document.getElementById("imgLoading").style.visibility = "hidden";
}

/** Activa o desactiva el indicador de cargando. */
function setLoading(value) {
   if (value == true) {
      showLoading();
   } else {
      hideLoading();
   }
}

// -------------------------------------------------------------

/** Busca el nombre del primer formulario que contiene el campo 
  * cuyo nombre se  especifica.
 */
function findFieldFormName(fieldName) {
   var res;
   var idx;

   idx = 0; 
   res = null;
   while ((res == null) && (idx < document.forms.length)) {
      if (document.forms[idx].elements[fieldName]) {
        res = document.forms[idx];
      }
      idx = idx + 1;
   }

   return (res == null) ? null : res.name;
}

function setFieldValue(formName, fieldName, value) {
    if (!formName) {
       formName = findFieldFormName(fieldName);
    }

    document.forms[formName].elements[fieldName].value = value;
}

function addSelectValue(formName, selectName, value, text) {
    var select;
    var option;

    if (!formName) {
       formName = findFieldFormName(selectName);
    }
    if (!text) {
       text = value;
    }

    option = new Option(text, value);
    select = document.forms[formName].elements[selectName];
    select.options[select.options.length]  = option;

    if (select.options.length == 1) {
       select.selectedIndex = 0;
    }
}

function clearSelect(formName, selectName) {
    var select;

    if (!formName) {
       formName = findFieldFormName(selectName);
    }
    select = document.forms[formName].elements[selectName];
    select.options.length = 0;
}


// -------------------------------------------------------------


function doSubmit(control, eventName) {
     var formName;
     var controlName;

     formName = (!control) ? document.forms[0].name : control.form.name;
     controlName = (!control) ? "form" : control.name;
     eventName = (!eventName) ? "Submit" : eventName;

     showLoading();

     control.form.formPrivateInfo.value = "METHOD:: " + controlName + "_on" + eventName + ";";

     control.form.method="GET";
     control.form.target="aux";
     control.form.submit();

     formLock(control.form.name);
}
