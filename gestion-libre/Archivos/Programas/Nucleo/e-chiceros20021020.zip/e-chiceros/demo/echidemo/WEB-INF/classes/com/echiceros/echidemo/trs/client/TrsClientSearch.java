/*
 * TrsClientSearch.java
 *
 * Created on 24 de septiembre de 2002, 16:24
 */

package com.echiceros.echidemo.trs.client;

import org.apache.log4j.*;

import com.echiceros.bd.*;
import com.echiceros.bd.trs.*;

/**
 * Dados los par�metros de b�squeda retorna todos los clientes
 * almacenados en la base de datos que los cumplen.
 *
 * Espera una definici�n como la siguiente:
 *
 *   <data>
 *      <reporttype>normal</reporttype>  (brief, normal, extended)
 *
 *      <id>EF834</id>
 *      <name>Javi</name>
 *      <surnames>More%</surnames>
 *      <state>Barcelona</state>
 *   </data>
 * 
 * Ninguno de los par�metros es obligatorio. Pueden utilizarse
 * comodines SQL para los alfanum�ricos.
 *
 * y retorna un documento de la forma
 *
 *    <serviceResponse>        
 *      <type>success</type>       
 *      <data>       
 *          <client>
 *            <id>EF834</id>
 *            <name>Javier</name>
 *            <surnames>Moreno</surnames>
 *          </client>
 *          <client>
 *            <id>D3434</id>
 *            <name>Javier</name>
 *            <surnames>Morera</surnames>
 *          </client>
 *      </data>        
 *    </serviceResponse>       
 *
 * El n�mero de campos proporcionado en el resultado depende
 * del tipo de report pedido.
 *
 * [ATENCI�N] Actualmente es solo una simulaci�n.
 *
 * @author  jv
 */
public class TrsClientSearch extends com.echiceros.bd.trs.TrsAdapter {
    
    /** Creates a new instance of TrsClientSearch */
    public TrsClientSearch() {
        super();
    }
    
    /** Ejecuta la transacci�n.  */
    public void execute() throws TrsException {
        StringBuffer data;
        String res;
        int howMany;
        
        howMany = (int) (Math.random()*10) + 1;
        data = new StringBuffer();
        for (int i=0; i < howMany; i++) {
            data.append("<client>\r\n");
            data.append("  <id>" + createRandomId() + "</id>\r\n");
            data.append("  <name>" + createRandomName() + "</name>\r\n");
            data.append("  <surname>" + createRandomSurname() + "</surname>\r\n");
            data.append("</client>\r\n");            
        }        
        
        res = TransactionEngine.createSuccessXML(data.toString());
        
        Category.getInstance(getClass()).debug(res);
        
        super.write(res);
    }
    
    String[] IDs = new String[] {"3DFX", "KJD3", "KJDFE", "C3PO"};
    private String createRandomId() {
        String res;
        
        if (super.getParam("id") != null) {
            res = super.getParam("id");
        } else {
            res = IDs[(int) (Math.random()*IDs.length)];
        }
        
        return res;
    }
    
    String[] NAMEs = new String[] {"Javi", "Glo", "Candi", "Isa"};
    private String createRandomName() {
        String res;
        
        if (super.getParam("name") != null) {
            res = super.getParam("name");
        } else {
            res = NAMEs[(int) (Math.random()*NAMEs.length)];
        }
        
        return res;
    }
    
    String[] SURNAMEs = new String[] {"Cruz", "Moreno", "Andi", "Garc�a"};
    private String createRandomSurname() {
        String res;
        
        if (super.getParam("surname") != null) {
            res = super.getParam("surname");
        } else {
            res = SURNAMEs[(int) (Math.random()*SURNAMEs.length)];
        }
        
        return res;
    }
    
}  
