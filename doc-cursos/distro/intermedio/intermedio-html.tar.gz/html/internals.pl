# LaTeX2HTML 99.2beta6 (1.42)
# Associate internals original text with physical files.


$key = q/fig:knode/;
$ref_files{$key} = "$dir".q|node185.html|; 
$noresave{$key} = "$nosave";

$key = q/UID/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/tab:permisos/;
$ref_files{$key} = "$dir".q|node50.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:leafnode.org/;
$ref_files{$key} = "$dir".q|node184.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-PantallaInicial/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:permisos/;
$ref_files{$key} = "$dir".q|node45.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Shell-RedireccionIO-Diagrama-Diccionario/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:EncriptandoDesdeClientesDeCorreo-ConfDelPine/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-IndiceDeMensajes/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Shell-RedireccionIO-Diagrama-Sort/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:CompilandoNucleo-Modulos/;
$ref_files{$key} = "$dir".q|node153.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-PantallaPrincipal/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-ComposicionDeMensaje/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/section:correo-intro/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:CompilandoNucleo-MakeMenuConfig/;
$ref_files{$key} = "$dir".q|node148.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vi/;
$ref_files{$key} = "$dir".q|node95.html|; 
$noresave{$key} = "$nosave";

$key = q/seccion:progbash/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-AgregarContacto/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/GID/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:CompilandoNucleo-MakeXConfig/;
$ref_files{$key} = "$dir".q|node148.html|; 
$noresave{$key} = "$nosave";

$key = q/subsection:tuberias/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-VistaDeEmail/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/subseccion:LILO/;
$ref_files{$key} = "$dir".q|node149.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-ListaDeCarpetas/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/seccion:gpg/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:redireccion/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:CompilandoNucleo-MakeConfig/;
$ref_files{$key} = "$dir".q|node148.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ClientesDeCorreo-Pine-NavegadorDeArchivos/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

1;

