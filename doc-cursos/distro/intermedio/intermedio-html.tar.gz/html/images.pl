# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/nomath_inline}fbox{ttI}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="\fbox{\tt I}">|; 

$key = q/nomath_inline}fbox{ttL}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="\fbox{\tt L}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashShell-RedireccionIO-Diagrama-Diccionario.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="437" HEIGHT="28" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/Shell-RedireccionIO-Diagrama-Diccionario.eps}">|; 

$key = q/nomath_inline}fbox{ttM}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="\fbox{\tt M}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashEncriptandoDesdeClientesDeCorreo-ConfDelPine.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="298" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/EncriptandoDesdeClientesDeCorreo-ConfDelPine.eps}">|; 

$key = q/nomath_inline}fbox{ttO}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="\fbox{\tt O}">|; 

$key = q/nomath_inline}fbox{ttReP�g}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\fbox{\tt ReP�g}">|; 

$key = q/nomath_inline}fbox{ttQ}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="\fbox{\tt Q}">|; 

$key = q/nomath_inline}fbox{ttR}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\fbox{\tt R}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-ComposicionDeMensaje.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-ComposicionDeMensaje.eps}">|; 

$key = q/nomath_inline}fbox{ttS}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\fbox{\tt S}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-PantallaPrincipal.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-PantallaPrincipal.eps}">|; 

$key = q/nomath_inline}fbox{ttCtrl-T}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="\fbox{\tt Ctrl-T}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-AgregarContacto.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-AgregarContacto.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCompilandoNucleo-MakeXConfig.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="204" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CompilandoNucleo-MakeXConfig.eps}">|; 

$key = q/nomath_inline}fbox{ttY}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\fbox{\tt Y}">|; 

$key = q/nomath_inline}fbox{ttCtrl-X}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="\fbox{\tt Ctrl-X}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-VistaDeEmail.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-VistaDeEmail.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-ListaDeCarpetas.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-ListaDeCarpetas.eps}">|; 

$key = q/nomath_inline}fbox{ttEnter}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="\fbox{\tt Enter}">|; 

$key = q/nomath_inline}fbox{ttENTER}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\fbox{\tt ENTER}">|; 

$key = q/nomath_inline}fbox{ttESPACIO}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\fbox{\tt ESPACIO}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashknode.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="313" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/knode.eps}">|; 

$key = q/nomath_inline}fbox{ttAlt-F1}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\fbox{\tt Alt-F1}">|; 

$key = q/nomath_inline}fbox{ttg}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\fbox{\tt g}">|; 

$key = q/nomath_inline}fbox{ttAlt-F6}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\fbox{\tt Alt-F6}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-PantallaInicial.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-PantallaInicial.eps}">|; 

$key = q/nomath_inline}fbox{ttn}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\fbox{\tt n}">|; 

$key = q/nomath_inline}fbox{ttAvP�g}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\fbox{\tt AvP�g}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-IndiceDeMensajes.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-IndiceDeMensajes.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashShell-RedireccionIO-Diagrama-Sort.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="224" HEIGHT="29" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/Shell-RedireccionIO-Diagrama-Sort.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCompilandoNucleo-Modulos.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CompilandoNucleo-Modulos.eps}">|; 

$key = q/nomath_inline}fbox{ttq}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\fbox{\tt q}">|; 

$key = q/nomath_inline}fbox{ttv}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\fbox{\tt v}">|; 

$key = q/rightarrow;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$\rightarrow$">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCompilandoNucleo-MakeMenuConfig.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CompilandoNucleo-MakeMenuConfig.eps}">|; 

$key = q/nomath_inline}fbox{ttTAB}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="\fbox{\tt TAB}">|; 

$key = q/nomath_inline}fbox{ttslash}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\fbox{\tt /}">|; 

$key = q/nomath_inline}fbox{tt?}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\fbox{\tt ?}">|; 

$key = q/nomath_inline}fbox{tt@}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="\fbox{\tt @}">|; 

$key = q/nomath_inline}fbox{ttA}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="\fbox{\tt A}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCompilandoNucleo-MakeConfig.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CompilandoNucleo-MakeConfig.eps}">|; 

$key = q/nomath_inline}fbox{ttC}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="\fbox{\tt C}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashClientesDeCorreo-Pine-NavegadorDeArchivos.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="271" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ClientesDeCorreo-Pine-NavegadorDeArchivos.eps}">|; 

$key = q/nomath_inline}fbox{ttE}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="\fbox{\tt E}">|; 

$key = q/nomath_inline}fbox{ttCtrl-C}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="\fbox{\tt Ctrl-C}">|; 

$key = q/nomath_inline}fbox{ttG}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\fbox{\tt G}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashleafnode.org.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="313" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/leafnode.org.eps}">|; 

1;

