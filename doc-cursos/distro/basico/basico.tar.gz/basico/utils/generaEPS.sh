#!/bin/sh
# Compila todos los gifs en el directorio imagenes/ y coloca los .eps en
# el directorio imagenes/eps
# Ejecutar desde el directorio "raiz"

#    Introducci�n al uso de GNU/Linux - Manual para el dictado de cursos
#    Copyright (C) 2000 Lucas Di Pentima, Nicol�s C�sar
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

# Chequeos varios
PS=`whereis gif2ps`
GIF2PS=`echo $PS | awk '{print $2}'`

PNM=`whereis pnmtops`
PNMTOPS=`echo $PNM | awk '{print $2}'`

PNG=`whereis pngtopnm`
PNGTOPNM=`echo $PNG | awk '{print $2}'`

EPS=`whereis ps2epsi`
PS2EPSI=`echo $EPS | awk '{print $2}'`

### ATENCION: Dejamos de soportar los GIFs, ya estamos c�modos con PNG ###

# Chequeo si las utilidades de conversi�n de im�genes est�n instaladas
# if [ ! $GIF2PS ]; then
# 	echo "ERROR: La utilidad gif2ps no existe en el sistema, por favor instalar"
# 	exit
# else
# 	if [ ! $PS2EPSI ]; then
# 		echo "ERROR: La utilidad ps2epsi no existe en el sistema, por favor instalar"
# 		exit
# 	fi
# fi

# Mas chequeos de las nuevas utilidades
if [ ! $PNGTOPNM ]; then
	echo "ERROR: La utilidad pngtopnm no existe en el sistema, por favor instalar"
	exit
else
	if [ ! $PNMTOPS ]; then
		echo "ERROR: La utilidad pnmtops no existe en el sistema, por favor instalar"
		exit
	fi
fi
echo "Generando archivos EPS desde las im�genes PNGs, por favor espera..."
for i in `ls imagenes/*.png`; 
do
	# Si el .eps correspondiente al .png existe, no lo genero...
	IMAGEN=`basename $i .png`
	if [ ! -e imagenes/eps/$IMAGEN.eps ]; then
		echo -n $i...
	        utils/png2eps.sh $i
	        mv $IMAGEN.eps imagenes/eps
	        echo Listo
	else
		if [ imagenes/eps/$IMAGEN.eps -ot imagenes/$IMAGEN.png ]; then
			echo -n $i...
			utils/png2eps.sh $i
			mv $IMAGEN.eps imagenes/eps
			echo Listo
		fi
	fi
done
	
# echo "Generando archivos EPS desde las im�genes GIFs, por favor espera..."
# for i in `ls imagenes/*.gif`; 
# do
# 	# Si el .eps correspondiente al .gif existe, no lo genero...
# 	IMAGEN=`basename $i .gif`
# 	if [ ! -e imagenes/eps/$IMAGEN.eps ]; then
# 		echo -n $i...
# 	        utils/gif2eps.sh $i
# 	        mv $IMAGEN.eps imagenes/eps
# 	        echo Listo
# 	else
# 		if [ imagenes/eps/$IMAGEN.eps -ot imagenes/$IMAGEN.gif ]; then
# 			echo -n $i...
# 			utils/gif2eps.sh $i
# 			mv $IMAGEN.eps imagenes/eps
# 			echo Listo
# 		fi
# 	fi
# done
echo "Listo! im�genes generadas, sigamos con la compilaci�n..."
