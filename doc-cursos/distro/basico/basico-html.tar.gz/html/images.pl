# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/nomath_inline}fbox{ttCrear}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img118.png"
 ALT="\fbox{\tt Crear}">|; 

$key = q/nomath_inline}fbox{ttConectar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img168.png"
 ALT="\fbox{\tt Conectar}">|; 

$key = q/nomath_inline}fbox{ttAbrir}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.png"
 ALT="\fbox{\tt Abrir}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-Busqueda.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="236" HEIGHT="143" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-Busqueda.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarChart.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img147.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarChart.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopArchivoNuevo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="184" HEIGHT="252" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img58.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopArchivoNuevo.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopArchivoNuevoPlantilla.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="259" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img59.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopArchivoNuevoPlantilla.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashnetscape-www.lunix.com.ar.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="352" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img172.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/netscape-www.lunix.com.ar.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-Seleccionado-App-MM-Xmms.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="329" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-Seleccionado-App-MM-Xmms.eps}">|; 

$key = q/nomath_inline}fbox{ttGrabar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img125.png"
 ALT="\fbox{\tt Grabar}">|; 

$key = q/nomath_inline}fbox{ttA~{n}adir...}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img177.png"
 ALT="\fbox{\tt A\&nbsp;{n}adir...}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkfm-www.lunix.com.ar.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="275" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img173.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kfm-www.lunix.com.ar.eps}">|; 

$key = q/nomath_inline}fbox{ttFiltro}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img123.png"
 ALT="\fbox{\tt Filtro}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-Inicial.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="329" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-Inicial.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlAplicaciones-Panel-Escritorios.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="398" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlAplicaciones-Panel-Escritorios.eps}">|; 

$key = q/nomath_inline}fbox{ttTab}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img142.png"
 ALT="\fbox{\tt Tab}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudaRespuesta.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="233" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img88.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudaRespuesta.eps}">|; 

$key = q/nomath_inline}fbox{ttCtrl+F2}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img113.png"
 ALT="\fbox{\tt Ctrl+F2}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCambioDeIdioma.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="412" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CambioDeIdioma.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashlynx-www.lunix.com.ar.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="327" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img174.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/lynx-www.lunix.com.ar.eps}">|; 

$key = q/nomath_inline}fbox{ttnegritas}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img91.png"
 ALT="\fbox{\tt negritas}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-ListaDeArchivos.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="398" HEIGHT="329" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-ListaDeArchivos.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopExplorerYBeamer.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="316" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopExplorerYBeamer.eps}">|; 

$key = q/nomath_inline}fbox{ttShift}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="\fbox{\tt Shift}">|; 

$key = q/nomath_inline}fbox{ttInstalar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="\fbox{\tt Instalar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-Examinar-Xmms.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="329" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-Examinar-Xmms.eps}">|; 

$key = q/nomath_inline}fbox{ttAceptar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img93.png"
 ALT="\fbox{\tt Aceptar}">|; 

$key = q/nomath_inline}fbox{ttOpciones}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img120.png"
 ALT="\fbox{\tt Opciones}">|; 

$key = q/{displaymath}=A1+A2+A3+A4+A5+A6+A7+A8+A9+A10+A11+A12{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="30" BORDER="0"
 SRC="|."$dir".q|img110.png"
 ALT="\begin{displaymath}=A1+A2+A3+A4+A5+A6+A7+A8+A9+A10+A11+A12\end{displaymath}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImagePlumas.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="30" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img155.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImagePlumas.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudante.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="158" HEIGHT="206" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img85.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudante.eps}">|; 

$key = q/nomath_inline}fbox{ttGuardar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="\fbox{\tt Guardar}">|; 

$key = q/nomath_inline}fbox{ttF10}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\fbox{\tt F10}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageColores.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="313" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img151.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageColores.eps}">|; 

$key = q/nomath_inline}fbox{ttSupr}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img141.png"
 ALT="\fbox{\tt Supr}">|; 

$key = q/nomath_inline}fbox{ttK}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\fbox{\tt K}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageRGB.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="372" HEIGHT="99" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img159.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageRGB.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcDiagramaGraficoCambioPropiedades.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="233" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img119.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcDiagramaGraficoCambioPropiedades.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlAplicaciones-Panel-Panel.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="398" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlAplicaciones-Panel-Panel.eps}">|; 

$key = q/nomath_inline}fbox{ttCtrl+N}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img104.png"
 ALT="\fbox{\tt Ctrl+N}">|; 

$key = q/nomath_inline}fbox{ttAsignar...}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img128.png"
 ALT="\fbox{\tt Asignar...}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Fondo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="398" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Fondo.eps}">|; 

$key = q/nomath_inline}fbox{ttRechazar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="\fbox{\tt Rechazar}">|; 

$key = q/nomath_inline}fbox{ttCtrl-O}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img90.png"
 ALT="\fbox{\tt Ctrl-O}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-Desinstalar.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="236" HEIGHT="174" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-Desinstalar.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkppp-Inicial.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="400" HEIGHT="182" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img162.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kppp-Inicial.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcMacroStop.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="33" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img126.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcMacroStop.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageEscala.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="32" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img154.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageEscala.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Estilo-otro.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="395" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Estilo-otro.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcBotones.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="34" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img101.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcBotones.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarSchedule.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img146.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarSchedule.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashUtilidadesDeRed-Ping.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="390" HEIGHT="252" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img181.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/UtilidadesDeRed-Ping.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyuda.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="313" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img77.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyuda.eps}">|; 

$key = q/nomath_inline}fbox{ttinstalar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="\fbox{\tt instalar}">|; 

$key = q/nomath_inline}fbox{tt!`Adelante!}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img180.png"
 ALT="\fbox{\tt !\lq Adelante!}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageNuevaImagen.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="328" HEIGHT="118" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img149.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageNuevaImagen.eps}">|; 

$key = q/nomath_inline}fbox{ttAlt}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\fbox{\tt Alt}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalc.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="348" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img100.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalc.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlVentanas-BarraDeTitulo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="368" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlVentanas-BarraDeTitulo.eps}">|; 

$key = q/nomath_inline}fbox{ttReflejar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img145.png"
 ALT="\fbox{\tt Reflejar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashksirc-Conectado.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="462" HEIGHT="359" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img184.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ksirc-Conectado.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlVentanas-Botones.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="368" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlVentanas-Botones.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlAplicaciones-Panel-NavegadorDeDisco.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="398" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlAplicaciones-Panel-NavegadorDeDisco.eps}">|; 

$key = q/nomath_inline}fbox{ttAdd...}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="\fbox{\tt Add...}">|; 

$key = q/nomath_inline}fbox{ttConfiguraci�n...}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="\fbox{\tt Configuraci�n...}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageFiltroMenu.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="230" HEIGHT="145" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img160.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageFiltroMenu.eps}">|; 

$key = q/nomath_inline}fbox{tt�rea}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="45" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img122.png"
 ALT="\fbox{\tt �rea}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopPerdidaFormato.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="378" HEIGHT="91" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img67.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopPerdidaFormato.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkppp-conectando.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="360" HEIGHT="83" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img169.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kppp-conectando.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudaExplorador.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="322" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img82.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudaExplorador.eps}">|; 

$key = q/nomath_inline}fbox{ttNo}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img99.png"
 ALT="\fbox{\tt No}">|; 

$key = q/nomath_inline}fbox{ttTres}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\fbox{\tt Tres}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageBrillo_y_Contraste.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="99" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img158.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageBrillo_y_Contraste.eps}">|; 

$key = q/nomath_inline}fbox{ttShift-Tab}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img143.png"
 ALT="\fbox{\tt Shift-Tab}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopPropiedadesDocumento.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="233" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img68.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopPropiedadesDocumento.eps}">|; 

$key = q/nomath_inline}fbox{ttPregunta}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img86.png"
 ALT="\fbox{\tt Pregunta}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Estilo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Estilo.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlDispositivoDeEntrada-TecladoInternacional-General.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlDispositivoDeEntrada-TecladoInternacional-General.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudanteConfiguracion.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="164" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img89.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudanteConfiguracion.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcFunciones.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="248" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img114.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcFunciones.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcDiagramaTitulos.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="201" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img117.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcDiagramaTitulos.eps}">|; 

$key = q/nomath_inline}fbox{ttConfiguraci�n}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img165.png"
 ALT="\fbox{\tt Configuraci�n}">|; 

$key = q/nomath_inline}fbox{ttArchivo}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img95.png"
 ALT="\fbox{\tt Archivo}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcDiagramaSeleccion.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="203" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img116.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcDiagramaSeleccion.eps}">|; 

$key = q/{displaymath}=3+6{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="30" BORDER="0"
 SRC="|."$dir".q|img109.png"
 ALT="\begin{displaymath}=3+6\end{displaymath}">|; 

$key = q/nomath_inline}fbox{ttCtrl+O}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img108.png"
 ALT="\fbox{\tt Ctrl+O}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudaBuscarTexto.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="297" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img81.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudaBuscarTexto.eps}">|; 

$key = q/nomath_inline}fbox{ttminimizar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img61.png"
 ALT="\fbox{\tt minimizar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-GestorDeTemas.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-GestorDeTemas.eps}">|; 

$key = q/nomath_inline}fbox{ttAccept}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img170.png"
 ALT="\fbox{\tt Accept}">|; 

$key = q/{displaymath}=SUMA(A1:A12){displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="165" HEIGHT="33" BORDER="0"
 SRC="|."$dir".q|img111.png"
 ALT="\begin{displaymath}=SUMA(A1:A12)\end{displaymath}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImpress.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img138.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImpress.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImage.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img148.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImage.eps}">|; 

$key = q/nomath_inline}fbox{ttmaximizar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.png"
 ALT="\fbox{\tt maximizar}">|; 

$key = q/nomath_inline}fbox{ttCtrl-P}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img94.png"
 ALT="\fbox{\tt Ctrl-P}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Fuentes.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Fuentes.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashksirc-Inicial.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="352" HEIGHT="174" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img182.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ksirc-Inicial.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopDialogoAbrir.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="259" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img70.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopDialogoAbrir.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcPracticas-1-1.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="263" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img129.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcPracticas-1-1.eps}">|; 

$key = q/nomath_inline}fbox{ttFormato}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img92.png"
 ALT="\fbox{\tt Formato}">|; 

$key = q/nomath_inline}fbox{ttDesinstalar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="\fbox{\tt Desinstalar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopGuardarComo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="260" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img71.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopGuardarComo.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkppp-completo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="400" HEIGHT="182" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img167.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kppp-completo.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkmail-ConfigurarCuenta.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="325" HEIGHT="300" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img178.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kmail-ConfigurarCuenta.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageModificarTam.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="335" HEIGHT="187" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img153.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageModificarTam.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudaPregunta.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="233" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img87.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudaPregunta.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcTrabajo.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="238" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img103.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcTrabajo.eps}">|; 

$key = q/{displaymath}X_{t}=T_{t}+S_{t}+I_{t}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="31" BORDER="0"
 SRC="|."$dir".q|img133.png"
 ALT="\begin{displaymath}X_{t}=T_{t}+S_{t}+I_{t}\end{displaymath}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageEscalaGrises.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="245" HEIGHT="199" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img152.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageEscalaGrises.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkmail-OpcionesRed.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="386" HEIGHT="415" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img179.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kmail-OpcionesRed.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAbrirPassword.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="354" HEIGHT="97" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img73.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAbrirPassword.eps}">|; 

$key = q/nomath_inline}fbox{ttShift-Alt}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img144.png"
 ALT="\fbox{\tt Shift-Alt}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkonsole-kedit.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="265" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/konsole-kedit.eps}">|; 

$key = q/nomath_inline}fbox{ttCuatro}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\fbox{\tt Cuatro}">|; 

$key = q/nomath_inline}fbox{ttN�meros}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img130.png"
 ALT="\fbox{\tt N�meros}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopGuardarComoPassword.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="354" HEIGHT="97" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img72.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopGuardarComoPassword.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashEscritorioInicial.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="348" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/EscritorioInicial.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcAbrir.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="254" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img107.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcAbrir.eps}">|; 

$key = q/nomath_inline}fbox{ttEliminar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\fbox{\tt Eliminar}">|; 

$key = q/(_t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img132.png"
 ALT="\(_t\)">|; 

$key = q/nomath_inline}fbox{ttA�adir}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\fbox{\tt A�adir}">|; 

$key = q/nomath_inline}fbox{ttAvanzar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img115.png"
 ALT="\fbox{\tt Avanzar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcMacro.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="204" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img124.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcMacro.eps}">|; 

$key = q/nomath_inline}fbox{ttExaminar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="\fbox{\tt Examinar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopBotonDePantallaCompleta.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="35" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopBotonDePantallaCompleta.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopTooltipExtendido.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="298" HEIGHT="102" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img76.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopTooltipExtendido.eps}">|; 

$key = q/nomath_inline}fbox{ttF1}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img83.png"
 ALT="\fbox{\tt F1}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Bordes.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Bordes.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcBotonesLaterales.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="291" HEIGHT="23" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img102.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcBotonesLaterales.eps}">|; 

$key = q/nomath_inline}fbox{ttCancelar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="\fbox{\tt Cancelar}">|; 

$key = q/nomath_inline}fbox{ttOK}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\fbox{\tt OK}">|; 

$key = q/nomath_inline}fbox{ttLogout}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\fbox{\tt Logout}">|; 

$key = q/nomath_inline}fbox{ttInicio}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="\fbox{\tt Inicio}">|; 

$key = q/nomath_inline}fbox{ttEsc}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img140.png"
 ALT="\fbox{\tt Esc}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDraw.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img139.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDraw.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkppp-NuevaConexion.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="440" HEIGHT="342" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img164.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kppp-NuevaConexion.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlAplicaciones-Panel-Opciones.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="398" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlAplicaciones-Panel-Opciones.eps}">|; 

$key = q/nomath_inline}fbox{ttcerrar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.png"
 ALT="\fbox{\tt cerrar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopDialogoSalir.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="263" HEIGHT="79" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopDialogoSalir.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageImagen.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="129" HEIGHT="30" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img156.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageImagen.eps}">|; 

$key = q/nomath_inline}fbox{ttDos}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\fbox{\tt Dos}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopPasswordErronea.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="315" HEIGHT="91" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img74.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopPasswordErronea.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlVentanas-Avanzado.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="368" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlVentanas-Avanzado.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopMenuVentana.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="172" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img65.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopMenuVentana.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageRotac.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="228" HEIGHT="159" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img157.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageRotac.eps}">|; 

$key = q/nomath_inline}fbox{ttOrdenar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img121.png"
 ALT="\fbox{\tt Ordenar}">|; 

$key = q/nomath_inline}fbox{ttMay�sculas}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img105.png"
 ALT="\fbox{\tt May�sculas}">|; 

$key = q/nomath_inline}fbox{ttCtrl+P}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img112.png"
 ALT="\fbox{\tt Ctrl+P}">|; 

$key = q/{displaymath}T_{t}=100+2_{t}{displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="107" HEIGHT="31" BORDER="0"
 SRC="|."$dir".q|img134.png"
 ALT="\begin{displaymath}T_{t}=100+2_{t}\end{displaymath}">|; 

$key = q/nomath_inline}fbox{ttCtrl-Q}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img97.png"
 ALT="\fbox{\tt Ctrl-Q}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopBarraHerramientas.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="183" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img66.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopBarraHerramientas.eps}">|; 

$key = q/nomath_inline}fbox{ttAyuda}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img84.png"
 ALT="\fbox{\tt Ayuda}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarOffice.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarOffice.eps}">|; 

$key = q/{displaymath}C(K,S,T-t,r,sigma)=S�N(d_{1})-K�e^{-r(T-t)}�N(d_{2}){displaymath};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="437" HEIGHT="33" BORDER="0"
 SRC="|."$dir".q|img131.png"
 ALT="\begin{displaymath}
C(K,S,T-t,r,\sigma)=S�N(d_{1})-K�e^{-r(T-t)}�N(d_{2})
\end{displaymath}">|; 

$key = q/nomath_inline}fbox{ttSi}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img98.png"
 ALT="\fbox{\tt Si}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-IconosDelEscritorio.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-IconosDelEscritorio.eps}">|; 

$key = q/nomath_inline}fbox{ttNueva}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img166.png"
 ALT="\fbox{\tt Nueva}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashksirc-Conexion.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="344" HEIGHT="129" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img183.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/ksirc-Conexion.eps}">|; 

$key = q/nomath_inline}fbox{ttBuscar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img78.png"
 ALT="\fbox{\tt Buscar}">|; 

$key = q/nomath_inline}fbox{ttControl}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img106.png"
 ALT="\fbox{\tt Control}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkonsole-xmms.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="452" HEIGHT="265" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/konsole-xmms.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkppp-Configuracion.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="344" HEIGHT="302" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img163.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kppp-Configuracion.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktop.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="465" HEIGHT="308" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktop.eps}">|; 

$key = q/nomath_inline}fbox{ttMostrar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img79.png"
 ALT="\fbox{\tt Mostrar}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkpackage-Seleccionado-New-Xmms.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="384" HEIGHT="329" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kpackage-Seleccionado-New-Xmms.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageNuevaImagenSin.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="451" HEIGHT="313" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img150.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageNuevaImagenSin.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Colores.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Colores.eps}">|; 

$key = q/(I_{t});MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img137.png"
 ALT="\(I_{t}\)">|; 

$key = q/nomath_inline}fbox{ttUno}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\fbox{\tt Uno}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopTooltip.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="44" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopTooltip.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkmail-PrimeraVez.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="174" HEIGHT="118" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img175.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kmail-PrimeraVez.eps}">|; 

$key = q/nomath_inline}fbox{ttDoNotAccept}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img171.png"
 ALT="\fbox{\tt Do Not
Accept}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarImageFiltros.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="65" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img161.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarImageFiltros.eps}">|; 

$key = q/nomath_inline}fbox{ttCtrl}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="\fbox{\tt Ctrl}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashkmail-OpcionesIdentidad.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="386" HEIGHT="415" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img176.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/kmail-OpcionesIdentidad.eps}">|; 

$key = q/nomath_inline}fbox{ttocultar}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img60.png"
 ALT="\fbox{\tt ocultar}">|; 

$key = q/nomath_inline}fbox{ttSalir}nomath_inline};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="39" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img96.png"
 ALT="\fbox{\tt Salir}">|; 

$key = q/(S_{t});MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img136.png"
 ALT="\(S_{t}\)">|; 

$key = q/(T_{t});MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img135.png"
 ALT="\(T_{t}\)">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlEscritorio-Salvapantalla.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="383" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlEscritorio-Salvapantalla.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarCalcBasic.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="317" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img127.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarCalcBasic.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashCentroDeControlVentanas-Propiedades.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="368" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/CentroDeControlVentanas-Propiedades.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopMultiplesVentanas.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="316" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img64.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopMultiplesVentanas.eps}">|; 

$key = q/includegraphics[scale=0.5]{imagenesslashepsslashStarDesktopAyudaBuscarIndice.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="297" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img80.png"
 ALT="\includegraphics[scale=0.5]{imagenes/eps/StarDesktopAyudaBuscarIndice.eps}">|; 

1;

