#ifndef _SUCK_ACTIVE_H
#define _SUCK_ACTIVE_H 1

int get_message_index_active(PMaster);
int connect_local(PMaster);

#endif /* _SUCK_ACTIVE_H */
