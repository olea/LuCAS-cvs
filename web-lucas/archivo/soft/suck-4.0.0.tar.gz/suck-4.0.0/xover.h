#ifndef SUCK_XOVER_H

/*-----------------------prototypes */
int do_group_xover(PMaster, char *, long);
void get_xoverview(PMaster);

#endif /* SUCK_XOVER_H */
