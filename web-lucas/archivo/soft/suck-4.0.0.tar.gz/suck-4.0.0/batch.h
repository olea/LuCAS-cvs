#ifndef _SUCK_BATCH_H
#define _SUCK_BATCH_H 1

int do_innbatch(PMaster);
int do_rnewsbatch(PMaster);
int do_localpost(PMaster);
void do_lmovebatch(PMaster);
void do_post_filter(PMaster);

#endif 	/* _SUCK_BATCH_H */
