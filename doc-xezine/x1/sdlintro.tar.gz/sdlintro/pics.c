#include <SDL.h>
#include <stdio.h>


main(){
  SDL_Surface *pantalla;
  SDL_Surface *imagen1, *imagen2, *imagen3; /* Las tres im�genes */
  SDL_Rect rect;
  Uint32 color;
  int terminar = 0;
  Uint8 *keys;
  int x = 100, y = 100;
  int xm,ym;
  int i,j;

  if(SDL_Init(SDL_INIT_VIDEO) == -1){
    printf("No se pudo iniciar el video: %s\n", SDL_GetError());
    exit(-1);
  }

  pantalla = SDL_SetVideoMode(640,480,16, SDL_ANYFORMAT | SDL_DOUBLEBUF
                                                         | SDL_FULLSCREEN);
  if(!pantalla){
    printf("No se pudo iniciar el modo de pantalla: %s\n", SDL_GetError());
    SDL_Quit();
    exit(-1);
  }

  /* Cargamos la im�gen de fondo */
  imagen1 = SDL_LoadBMP("imagen1.bmp");
  if(!imagen1){
    printf("No se pudo cargar imagen1.bmp\n");
    SDL_Quit();
    exit(-1);
  }

  /* Cargamos la im�gen del mu�eco */
  imagen2 = SDL_LoadBMP("imagen2.bmp");
  if(!imagen2){
    printf("No se pudo cargar imagen2.bmp\n");
    SDL_Quit();
    exit(-1);
  }
  /* Especificamos que el color negro indica transparencia */
  color = SDL_MapRGB(imagen1->format, 0,0,0);
  SDL_SetColorKey(imagen1, SDL_SRCCOLORKEY | SDL_RLEACCEL, color);

  /* Cargamos el cursor del rat�n */
  imagen3 = SDL_LoadBMP("cursor.bmp");
  if(!imagen2){
    printf("No se pudo cargar cursor.bmp\n");
    SDL_Quit();
    exit(-1);
  }
  /* Especificamos que el color negro indica transparencia */
  color = SDL_MapRGB(imagen3->format, 0,0,0);
  SDL_SetColorKey(imagen3, SDL_SRCCOLORKEY | SDL_RLEACCEL, color);

  /* No mostrar el cursor, pues vamos a dibujar el nuestro */
  SDL_ShowCursor(SDL_DISABLE);

  while( ! terminar ){  /* Bucle principal del programa */
    SDL_PollEvent(NULL);

    keys = SDL_GetKeyState(NULL);
    if( keys[SDLK_ESCAPE] ) terminar = 1;
    if( keys[SDLK_UP] )     y -= 2;
    if( keys[SDLK_DOWN] )   y += 2;
    if( keys[SDLK_LEFT] )   x -= 2;
    if( keys[SDLK_RIGHT] )  x += 2;

    if(SDL_GetMouseState(&xm, &ym) & SDL_BUTTON(1)){ x = xm; y = ym; }

    /* Dibujamos el fondo como un mosaico */
    for(i=0; i<40; i++){
      for(j=0; j<15; j++){
        rect = (SDL_Rect) {16*i,32*j, 0,0};
	SDL_BlitSurface(imagen2, NULL, pantalla, &rect);
      }
    }

    /* Dibujamos el mu�eco */
    rect = (SDL_Rect) {x,y, 0,0};
    SDL_BlitSurface(imagen1, NULL, pantalla, &rect);

    /* Dibujamos el cursor del rat�n */
    SDL_GetMouseState(&xm, &ym);
    rect = (SDL_Rect) {xm-16,ym-16, 0,0};
    SDL_BlitSurface(imagen3, NULL, pantalla, &rect);

    SDL_Flip(pantalla);

    SDL_Delay(50);
  }

  SDL_Quit();
}
