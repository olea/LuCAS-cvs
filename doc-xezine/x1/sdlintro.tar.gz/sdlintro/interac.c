#include <SDL.h>
#include <stdio.h>


main(){
  SDL_Surface *pantalla;
  SDL_Rect rect;
  Uint32 color;
  int terminar = 0;  /* 0 si no hemos terminado, 1 si es hora de acabar */
  Uint8 *keys;     /* Esto contendr� la informaci�n de las teclas */
  int x = 100, y = 100; /* Estas ser�n las coordenadas del cuadrado */
  int xm,ym;       /* Estas ser�n las coordenadas del cursor */

  if(SDL_Init(SDL_INIT_VIDEO) == -1){
    printf("No se pudo iniciar el video: %s\n", SDL_GetError());
    exit(-1);
  }

  pantalla = SDL_SetVideoMode(640,480,16, SDL_ANYFORMAT | SDL_DOUBLEBUF
                                                         | SDL_FULLSCREEN);
  if(!pantalla){
    printf("No se pudo iniciar el modo de pantalla: %s\n", SDL_GetError());
    SDL_Quit();
    exit(-1);
  }

  while( ! terminar ){  /* Bucle principal del programa */
    SDL_PollEvent(NULL);  /* Comprobamos los eventos del usuario */

    /* Comprobamos si el usuario est� presionando alguna tecla */
    /* Con ESC finaliza el programa, con las teclas de direcci�n se mueve el
       cuadrado */
    keys = SDL_GetKeyState(NULL);
    if( keys[SDLK_ESCAPE] ) terminar = 1;
    if( keys[SDLK_UP] )     y -= 2;
    if( keys[SDLK_DOWN] )   y += 2;
    if( keys[SDLK_LEFT] )   x -= 2;
    if( keys[SDLK_RIGHT] )  x += 2;

    /* Comprobamos si el usuario ha hecho click con el bot�n izquierdo del
       rat�n; de ser as�, mueve el cuadrado a donde est� el cursor */
    if(SDL_GetMouseState(&xm, &ym) & SDL_BUTTON(1)){ x = xm; y = ym; }

    /* Borramos la pantalla */
    color = SDL_MapRGB(pantalla->format, 0, 0, 255);
    rect = (SDL_Rect) {0,0,640,480};
    SDL_FillRect(pantalla, &rect, color);

    /* Dibujamos el cuadrado */
    color = SDL_MapRGB(pantalla->format, 255, 0, 0);
    rect = (SDL_Rect) {x,y,10,10};
    SDL_FillRect(pantalla, &rect, color);

    SDL_Flip(pantalla);

    SDL_Delay(50);
  }

  SDL_Quit();
}
