#include <SDL.h>   /* Insertamos la cabecera de SDL*/
#include <stdio.h>

main(){
  SDL_Surface *pantalla;  /* Esta variable representa la pantalla */
  SDL_Rect rect;  /* Esta otra representa un �rea rectangular en la pantalla */
  Uint32 color;  /* Y esta representa el color de un pixel en la pantalla */

  if(SDL_Init(SDL_INIT_VIDEO) == -1){  /* Inicializamos la libreria */
    printf("No se pudo iniciar el video: %s\n", SDL_GetError());
    exit(-1);
  }

  /* Ponemos el sistema en modo 640x480, pantalla completa */
  pantalla = SDL_SetVideoMode(640,480,16, SDL_ANYFORMAT | SDL_DOUBLEBUF
                                                             | SDL_FULLSCREEN);
  if(!pantalla){
    printf("No se pudo iniciar el modo de pantalla: %s\n", SDL_GetError());
    SDL_Quit();
    exit(-1);
  }

  /* Dibujamos un rect�ngulo de color rojo */
  color = SDL_MapRGB(pantalla->format, 255, 0, 0);
  rect = (SDL_Rect) {100,100,440,280};
  SDL_FillRect(pantalla, &rect, color);

  /* Dibujamos un rect�ngulo de color verde */
  color = SDL_MapRGB(pantalla->format, 0, 255, 0);
  rect = (SDL_Rect) {150,150,340,180};
  SDL_FillRect(pantalla, &rect, color);

  /* Dibujamos un rect�ngulo de color azul */
  color = SDL_MapRGB(pantalla->format, 0, 0, 255);
  rect = (SDL_Rect) {200,200,240,80};
  SDL_FillRect(pantalla, &rect, color);

  SDL_ShowCursor(SDL_DISABLE);

  SDL_Flip(pantalla); /* Refrescamos la pantalla */

  SDL_Delay(3000); /* Esperamos a que pasen 3 segundos */
  SDL_Quit();  /* Quitamos la imagen y desinicializamos la SDL */
}
